# Field Notebooks Bundle

Workspace of Jupyter notebooks + lightweight helpers for field teams. Each notebook walks through a workflow (init, client use cases, analytics) and relies on the shared `lib/` package shipped alongside.

## Contents
- `1-init_db/` – initialize spatial units and monitor ingestion jobs.
- `2-client_use_case/` – client inventory and use-case creation flows.
- `3-use_case_analytics/` – downstream analytics on exported artifacts.
- `4-analytics_scaffolder/` – helper notebook to scaffold new analytics tasks from OpenAPI/YAML.
- `lib/` – reusable helpers (auth, polling, downloads, analytics runner, task registry).
  - Examples: `lib/crop_mask.py`, `lib/emergence.py`, `lib/analytics/`.
- `config/` – shared assets (e.g., `crop_cycle.csv`).
- `requirements.txt` – dependencies for running the bundle.
- `analytics_tasks_guide.md` / `.html` – how to extend analytics tasks (bindings, registry wiring).

## Setup (fresh machine, Python 3.12)
1. Install Miniconda (if not already).
2. Create + activate an env:
   ```bash
   conda create -n field-notebooks python=3.12 -y
   conda activate field-notebooks
   ```
3. Install deps: `pip install -r requirements.txt`
4. Register the kernel for Jupyter:
   ```bash
   python -m ipykernel install --user --name field-notebooks --display-name "field-notebooks"
   ```
5. Copy `.env.template` to `.env` and fill:
   - `API_BASE_URL` (Sales Activator API, e.g., `https://yiokf3wlwxeppc6yui6kdev25e0vtqtr.lambda-url.us-east-1.on.aws`).
   - `EMERGENCE_BASE_URL` (Emergence detection host, e.g., `https://emergence-detection.aws-dev.geosys.com`).
   - Identity/Token settings used by the helper clients.
6. Launch Jupyter from this folder: `jupyter lab .`
7. In notebooks, pick the `field-notebooks` kernel and run the setup cells to load env vars and authenticate.

## Logging
- Notebook cells include a “Logging controls” section. By default, analytics loggers use the short names `analytics.<binding>` (e.g., `analytics.weather`, `analytics.crop_mask`, `analytics.emergence`).
- Adjust verbosity per task inside the notebook, for example:
  ```python
  import logging
  logging.getLogger("analytics.weather").setLevel(logging.INFO)  # or DEBUG/WARNING/ERROR
  logging.getLogger("analytics.crop_mask").setLevel(logging.DEBUG)
  ```
- The root logger is left at INFO in the notebooks; you can raise/lower it if you need less noise or more detail.

## Using the analytics runner
`lib/analytics/` exposes a common runner for tasks (generic vs notebook schemas). You can override field mappings/defaults, request checkpoints, and attach a reporter.
```python
import pandas as pd
from lib.analytics import BindingKey, AnalyticsRunReporter, run_task

reporter = AnalyticsRunReporter(
    enabled=True,
    html_path="tmp/analytics_run_report.html",
    include_map=True,
    map_geometry_column="geometry",
)

# df must contain either the notebook columns (spatial_unit_id, geohash5, centroid_wkt, planting_date, n_county)
# or the generic ones (id, geohash, centroid_wkt, planting_date, weather_region).
df_out, stats = run_task(
    df,
    binding_key=BindingKey.WEATHER,  # or "weather"
    task_params={"season_duration": 151},
    field_mapping_override={"geometry": "geom_wkt"},
    defaults_override={"data_source": "LR"},
    input_rules=[{"column": "sowingDate", "coerce": "datetime", "min_year": 1900, "skip_row": True}],
    checkpoint_path="tmp/weather_checkpoint.parquet",
    checkpoint_frequency=500,
    progress=True,
    progress_desc="Weather",
    error_csv_path="tmp/errors/weather_errors.csv",  # CSV of rows with *error* columns when failures occur
    reporter=reporter,  # bool also works to enable a lightweight reporter
)
print(stats.as_dict())
```

Notebook-friendly helper that also renders TaskStats and the final report:
```python
from lib.analytics import (
    BindingKey,
    AnalyticsRunReporter,
    run_task_with_reporting,
    render_final_report,
)

reporter = AnalyticsRunReporter(
    enabled=True,
    html_path="tmp/analytics_run_report.html",
    include_map=True,
    map_geometry_column="geometry",
)

df_out, stats = run_task_with_reporting(
    df,
    binding_key=BindingKey.WEATHER,
    reporter=reporter,
    error_csv_path="tmp/errors/weather_errors.csv",
)
report_html = render_final_report(reporter, show_inline=True)
```

To add a new task, see `analytics_tasks_guide.md` (or `.html`) and the scaffolder notebook under `4-analytics_scaffolder/`.

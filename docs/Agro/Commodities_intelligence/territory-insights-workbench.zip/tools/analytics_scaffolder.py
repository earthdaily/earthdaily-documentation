"""
Scaffold a new analytics task (client + task + registry wiring) from OpenAPI or YAML.

Examples:
  python tools/analytics_scaffolder.py --mode openapi --source openapi.json --task-name greenness_detection --path /launch --method post --use-crop-cycle --signature-cache
  python tools/analytics_scaffolder.py --mode yaml --source config.yaml --task-name my_task

Defaults to the analytics package next to this script (../lib/analytics); override with --target-root if needed.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


# ---------------------------- naming helpers ---------------------------- #


def snake(name: str) -> str:
    """Convert a user-provided name to snake_case, strip trailing `_task`."""
    name = re.sub(r"[\s\-]+", "_", name.strip())
    name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    name = re.sub(r"_task$", "", name)
    name = re.sub(r"_+", "_", name)
    return name.lower()


def title(name: str) -> str:
    """Convert a name to CamelCase."""
    return re.sub(r"[_\-]+", " ", name.strip()).title().replace(" ", "")


# ---------------------------- IO helpers ---------------------------- #


def load_yaml(path: Path) -> dict[str, Any]:
    try:
        import yaml  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise SystemExit("PyYAML is required for --mode yaml. Install with `pip install pyyaml`.") from exc
    return yaml.safe_load(path.read_text())


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def write_file(path: Path, content: str, force: bool) -> None:
    ensure_parent(path)
    if path.exists() and not force:
        raise SystemExit(f"Refusing to overwrite existing file: {path} (use --force to override)")
    path.write_text(content)


# ---------------------------- templating ---------------------------- #


def render_client(task: str, base_url: str, endpoint: str, method: str, *, binding_key: str) -> str:
    method = method.lower()
    env_base_var = f"{task.upper()}_BASE_URL"
    tpl = """import logging
import os
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from ..auth.token_manager import IdentityTokenManager


logger = logging.getLogger("analytics.{logger_key}")


class {ClassName}Client:
    def __init__(
        self,
        base_url: str,
        timeout: int = 300,
        token_manager: IdentityTokenManager | None = None,
        max_retries: int = 3,
        pool_size: int = 64,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.token_manager = token_manager or IdentityTokenManager.from_env()
        self.max_retries = max_retries
        self.pool_size = pool_size
        self._session: requests.Session | None = None

    @classmethod
    def from_env(cls):
        base_url = os.environ.get("{EnvVar}") or "{BaseUrl}"
        return cls(base_url=base_url, pool_size=64)

    def _headers(self) -> dict[str, str]:
        return {{
            "Authorization": f"Bearer {{self.token_manager.get_token()}}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }}

    def _http(self) -> requests.Session:
        if self._session is None:
            session = requests.Session()
            adapter = HTTPAdapter(
                max_retries=Retry(
                    total=self.max_retries,
                    backoff_factor=1,
                    status_forcelist=(429, 500, 502, 503, 504),
                    allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
                    raise_on_status=False,
                ),
                pool_connections=self.pool_size,
                pool_maxsize=self.pool_size,
                pool_block=True,
            )
            session.mount("https://", adapter)
            session.mount("http://", adapter)
            self._session = session
        return self._session

    def call(self, payload: dict, query: dict | None = None):
        url = f"{{self.base_url}}{Endpoint}"
        clean_body = {{k: v for k, v in (payload or {{}}).items() if v is not None}}
        clean_query = {{k: v for k, v in (query or {{}}).items() if v is not None}}
        logger.debug(
            "{ClassName} request url=%s method={Method_upper} payload=%s query=%s",
            url,
            clean_body,
            clean_query,
        )
        resp = self._http().{Method}(url, json=clean_body, params=clean_query, headers=self._headers(), timeout=self.timeout)
        try:
            body_preview = resp.json()
        except Exception:
            body_preview = resp.text
        logger.debug("{ClassName} response status=%s body=%s", resp.status_code, body_preview)
        try:
            resp.raise_for_status()
        except requests.HTTPError:
            logger.debug(
                "{ClassName} error status=%s body=%s payload=%s query=%s",
                resp.status_code,
                resp.text,
                clean_body,
                clean_query,
            )
            raise
        return resp.json()
"""
    return tpl.format(
        ClassName=title(task),
        BaseUrl=base_url,
        Endpoint=endpoint,
        Method=method,
        Method_upper=method.upper(),
        EnvVar=env_base_var,
        logger_key=binding_key,
    )


def _signature_block(signature_column: str, outputs: dict[str, str]) -> str:
    return (
        "            if signature_column in result.columns and result.at[idx, signature_column] == signature:\n"
        "                return ('skip', idx, None, signature, None, call_inputs)\n"
    )


def _crop_cycle_block(use_crop_cycle: bool) -> tuple[str, str, str]:
    if not use_crop_cycle:
        return "", "", ""
    imports = "from ...domain.crop_cycle import CropCycleCatalog\n"
    init = (
        "        catalog = self.crop_cycles or CropCycleCatalog.from_csv(\n"
        "            self.crop_cycle_csv_path or Path('../../params/crop_cycle.csv')\n"
        "        )\n"
    )
    logic = ""
    return imports, init, logic


def render_task(
    task: str,
    binding_key: str,
    inputs_body: dict[str, str],
    inputs_query: dict[str, str],
    outputs: dict[str, str],
    use_crop_cycle: bool,
    signature_cache: bool,
    extra_defaults: dict[str, Any] | None = None,
) -> str:
    class_name = title(task)
    signature_column = f"{binding_key}_signature"
    signature_logic = ""
    signature_import = "import hashlib\n" if signature_cache else ""

    def _indent_block(block: str, indent: str = " " * 20) -> str:
        """Indent a code block by a fixed prefix (used for insertion in f-string templates)."""
        return "\n".join(indent + line for line in block.splitlines())

    task_results_col = f"{task}_results"
    if outputs:
        lines: list[str] = []
        for col, remote in outputs.items():
            if remote == "data":
                lines.append(
                    "value = response.get('data') if isinstance(response, dict) else None\n"
                    "if isinstance(value, dict):\n"
                    f"    result.at[idx, '{task}_results'] = value\n"
                    "    for _k, _v in value.items():\n"
                    f"        col_name = f\"{task}.{{_k}}\"\n"
                    "        self._ensure_column(result, col_name)\n"
                    "        result.at[idx, col_name] = _v\n"
                    "else:\n"
                    f"    result.at[idx, '{task}_results'] = value\n"
                )
            else:
                target_col = f"{task}_response_id" if col == "id" else col
                lines.append(
                    f"value = response.get('{remote}') if isinstance(response, dict) else None\n"
                    "if value is None and isinstance(response, dict):\n"
                    "    data_part = response.get('data', {})\n"
                    "    if isinstance(data_part, dict):\n"
                    f"        value = data_part.get('{remote}')\n"
                    "if isinstance(value, (pd.Series, pd.DataFrame)):\n"
                    "    value = value.to_dict()\n"
                    f"result.at[idx, '{target_col}'] = value"
                )
        output_assignments = _indent_block("\n".join(lines))
    else:
        output_assignments = _indent_block(
            "if isinstance(response, dict):\n"
            "    data_part = response.get('data')\n"
            "    if isinstance(data_part, dict):\n"
            f"        result.at[idx, '{task_results_col}'] = data_part\n"
            "        for _k, _v in data_part.items():\n"
            "            val = _v\n"
            "            if isinstance(val, (pd.Series, pd.DataFrame)):\n"
            "                val = val.to_dict()\n"
            f"            col_name = f\"{task}.{{_k}}\"\n"
            "            self._ensure_column(result, col_name)\n"
            "            result.at[idx, col_name] = val\n"
            "    else:\n"
            f"        result.at[idx, '{task_results_col}'] = response\n"
            "else:\n"
            f"    result.at[idx, '{task_results_col}'] = response"
        )
    crop_imports, crop_init, crop_logic = _crop_cycle_block(use_crop_cycle)
    all_inputs = dict(inputs_body)
    all_inputs.update(inputs_query)
    defaults_map = dict(extra_defaults or {})
    if use_crop_cycle:
        for k in ("seasonDuration", "seasonStartDay", "seasonStartMonth"):
            defaults_map[k] = None
    for optional_field in ("crop", "sowingDate", "id"):
        if optional_field in all_inputs:
            defaults_map.setdefault(optional_field, None)
    include_sowing_support = "sowingDate" in all_inputs
    geometry_in_payload = "geometry" in all_inputs
    signature_prefill = ""
    if signature_cache:
        signature_col = f"{binding_key}_signature"
        signature_prefill = (
            "        _orig = kwargs.get('_original_df')\n"
            f"        if isinstance(_orig, pd.DataFrame) and '{signature_col}' in _orig.columns:\n"
            f"            result['{signature_col}'] = _orig['{signature_col}'].values\n"
        )
        geom_hash_block = (
            (
                "            if geom_normalized is not None:\n"
                "                signature_payload['geometry_hash'] = hashlib.sha256(str(geom_normalized).encode('utf-8')).hexdigest()\n"
            )
            if geometry_in_payload
            else ""
        )
        signature_logic = (
            f"{geom_hash_block}"
            "            signature = hashlib.sha256(json.dumps(signature_payload, sort_keys=True, default=str).encode('utf-8')).hexdigest()\n"
            f"            signature_column = '{signature_column}'\n" + _signature_block(signature_column, outputs)
        )
    override_signature = ""
    if signature_cache:
        override_signature = f'override_cols.append("{signature_column}")\n        '
    geometry_fetch = (
        (
            "            geom_val = row.get('geometry')\n"
            "            geom_normalized = None\n"
            "            if geom_val is not None:\n"
            "                try:\n"
            "                    geom_normalized = geom_val.wkt if hasattr(geom_val, 'wkt') else str(geom_val)\n"
            "                except Exception:\n"
            "                    geom_normalized = str(geom_val)\n"
        )
        if geometry_in_payload
        else ""
    )
    crop_runtime = ""
    if use_crop_cycle or "crop" in all_inputs:
        crop_runtime = "            crop_value = query_params.get('crop') or row.get('crop') or row.get('crop_code') or row.get('crop_type')\n"
        if use_crop_cycle:
            crop_runtime += (
                "            cycle = catalog.get(crop_value)\n"
                "            if query_params.get('seasonDuration') is None:\n"
                "                query_params['seasonDuration'] = self.season_duration or (cycle.season_duration if cycle else None)\n"
                "            if query_params.get('seasonStartDay') is None:\n"
                "                query_params['seasonStartDay'] = self.season_start_day or (cycle.season_start_day if cycle else None)\n"
                "            if query_params.get('seasonStartMonth') is None:\n"
                "                query_params['seasonStartMonth'] = self.season_start_month or (cycle.season_start_month if cycle else None)\n"
            )
    sowing_runtime = ""
    if include_sowing_support:
        sowing_runtime = (
            "            sowing_date_val = query_params.get('sowingDate')\n"
            "            # Normalize sowing date to YYYY-MM-DD if it's a date/datetime-like object.\n"
            "            if sowing_date_val is not None:\n"
            "                try:\n"
            "                    if hasattr(sowing_date_val, 'date'):\n"
            "                        sowing_date_val = sowing_date_val.date()\n"
            "                    if hasattr(sowing_date_val, 'isoformat'):\n"
            "                        sowing_date_val = sowing_date_val.isoformat()\n"
            "                except Exception:\n"
            "                    pass\n"
            "            if sowing_date_val is not None:\n"
            "                query_params['sowingDate'] = sowing_date_val\n"
        )
    path_import = "from pathlib import Path\n" if use_crop_cycle else ""
    crop_attr_block = ""
    if use_crop_cycle:
        crop_attr_block = (
            "    season_duration: int | None = None\n"
            "    season_start_day: int | None = None\n"
            "    season_start_month: int | None = None\n"
            "    crop_cycles: CropCycleCatalog | None = None\n"
            "    crop_cycle_csv_path: str | Path | None = Path('../../params/crop_cycle.csv')\n"
        )

    tpl = """from dataclasses import dataclass
from typing import ClassVar
{path_import}import pandas as pd
import json
import logging
{signature_import}from ..base import AnalyticsTask, TaskStats
from ...clients.{task}_client import {ClassName}Client
{crop_imports}


logger = logging.getLogger("analytics.{binding_key}")


def default_{task}_bindings():
    mapping = {all_inputs}
    defaults = {defaults_map}
    return {{"mapping": mapping, "defaults": defaults}}


@dataclass
class {ClassName}Task(AnalyticsTask):
    auto_context_update: ClassVar[bool] = False
    progress_desc: str = "{ClassName} analytics"
    checkpoint_path: str | None = None
    checkpoint_frequency: int = 200
    use_internal_progress: bool = False
    max_workers: int = 8
{crop_attr_block}    input_rules: tuple[dict, ...] = ()

    def execute(self, df: pd.DataFrame, **kwargs) -> tuple[pd.DataFrame, TaskStats]:
        if df.empty:
            return df.copy(), TaskStats(total=0, success=0, failed=0)

        checkpoint = kwargs.get("_checkpoint") or (lambda *a, **k: None)
        client = {ClassName}Client.from_env()
        result = df.copy()
        inputs_mapping = {all_inputs}
        inputs_body = {inputs_body}
        inputs_query = {inputs_query}
        call_inputs_col = "{task}_call_inputs"
        error_col = "{task}_error"
        errors_sample: list[str] = []
        success = 0
        failed = 0
        api_calls = 0
        cache_hits = 0
        logger.info(
            "{ClassName} task start rows=%s max_workers=%s checkpoint=%s",
            len(result),
            self.max_workers,
            bool(self.checkpoint_path),
        )
{signature_prefill}        for _col in {outputs_init}:
            if _col not in result.columns:
                result[_col] = pd.NA
        task_prefix = "{task}."
        orig = kwargs.get('_original_df')
        prefix_cols_orig = [c for c in getattr(orig, 'columns', []) if c.startswith(task_prefix)]
        for col in prefix_cols_orig:
            if col not in result.columns:
                result[col] = pd.NA
        override_cols = [c for c in result.columns if c.startswith(task_prefix)]
        override_cols.extend(
            [call_inputs_col, error_col, "{task}_results", "{task}_response_id"]
        )
        {override_signature}self._override_base_columns_runtime = set(override_cols)
{crop_init}        def _process(idx: int, row: pd.Series):
            signature = None
{geometry_fetch}            payload = {{k: row.get(v) for k, v in inputs_body.items()}}
            if 'id' in payload:
                payload['id'] = ""
            query_params = {{k: row.get(v) for k, v in inputs_query.items()}}
{crop_logic}{crop_runtime}{sowing_runtime}            if geom_normalized is not None and 'geometry' in payload:
                payload['geometry'] = geom_normalized
            call_inputs = {{"body": payload, "query": query_params}}
            signature_payload = {{k: row.get(v) for k, v in inputs_mapping.items()}}
            if geom_normalized is not None:
                signature_payload['geometry'] = geom_normalized
{signature_logic}            try:
                logger.debug("{ClassName} request idx=%s payload=%s query=%s", idx, payload, query_params)
                response = client.call(payload, query=query_params)
                logger.debug("{ClassName} response idx=%s body=%s", idx, response)
                return ("ok", idx, response, signature, None, call_inputs)
            except Exception as exc:
                err_msg = str(exc)
                resp = getattr(exc, "response", None)
                if resp is not None:
                    try:
                        body_text = resp.text
                    except Exception:
                        body_text = None
                    if body_text:
                        err_msg = f"status={{getattr(resp, 'status_code', '?')}} body={{body_text}} payload={{payload}} query={{query_params}}"
                return ("error", idx, None, signature, err_msg, call_inputs)

        from concurrent.futures import ThreadPoolExecutor, as_completed

        workers = min(max(1, self.max_workers), len(result))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {{executor.submit(_process, idx, row): idx for idx, row in result.iterrows()}}
            for future in as_completed(future_map):
                status, idx, response, signature, err, call_inputs = future.result()
                if status == "skip":
                    cache_hits += 1
                    if call_inputs is not None:
                        result.at[idx, call_inputs_col] = call_inputs
                    checkpoint(1, snapshot=result.loc[[idx]])
                    continue
                if status == "ok":
                    api_calls += 1
{output_assignments}
{assign_signature}                    result.at[idx, error_col] = None
                    if call_inputs is not None:
                        result.at[idx, call_inputs_col] = call_inputs
                    success += 1
                else:
                    failed += 1
                    result.at[idx, error_col] = err
                    if call_inputs is not None:
                        result.at[idx, call_inputs_col] = call_inputs
                    # Clear outputs on failure to avoid stale values.
                    for _col in [c for c in result.columns if c.startswith(f"{task}.")]:
                        result.at[idx, _col] = None
                    if f"{task}_results" in result.columns:
                        result.at[idx, f"{task}_results"] = None
                    if f"{task}_response_id" in result.columns:
                        result.at[idx, f"{task}_response_id"] = None
                    if err and len(errors_sample) < 5:
                        errors_sample.append(err)
                    if err:
                        logger.debug("{ClassName} row failed idx=%s error=%s", idx, err)
                checkpoint(1, snapshot=result.loc[[idx]])

        stats = TaskStats(
            total=len(df),
            success=success,
            failed=failed,
            api_calls=api_calls,
            cache_hits=cache_hits,
            errors_sample=errors_sample,
        )
        logger.info(
            "{ClassName} task done rows=%s success=%s failed=%s api_calls=%s cache_hits=%s",
            len(df),
            success,
            failed,
            api_calls,
            cache_hits,
        )
        return result, stats
"""
    return tpl.format(
        signature_import=signature_import,
        task=task,
        ClassName=class_name,
        crop_imports=crop_imports,
        all_inputs=all_inputs or {"id": "id"},
        inputs_body=inputs_body or {},
        inputs_query=inputs_query or {},
        crop_init=crop_init,
        crop_logic=crop_logic,
        signature_logic=signature_logic,
        output_assignments=output_assignments,
        defaults_map=defaults_map or {},
        assign_signature=f'                    result.at[idx, "{signature_column}"] = signature\n' if signature_cache else "",
        geometry_fetch=geometry_fetch,
        crop_runtime=crop_runtime,
        sowing_runtime=sowing_runtime,
        path_import=path_import,
        crop_attr_block=crop_attr_block,
        outputs_init=(
            [(f"{task}_response_id" if k == "id" else k) for k in outputs.keys() if k != "data"]
            + ([f"{task}_results"] if outputs else [f"{task}_results"])
            + [f"{task}_error", f"{task}_call_inputs"]
        ),
        signature_prefill=signature_prefill,
        override_signature=override_signature,
        binding_key=binding_key,
    )


def render_registry_block(task: str, binding_key: str, description: str, class_name: str) -> str:
    return f"""\n# Auto-generated scaffold for {binding_key}
try:  # pragma: no cover
    from .tasks import {class_name}Task, default_{task}_bindings
    from .params import {class_name}Params
    _{task} = default_{task}_bindings()
    register_binding(
        TaskBinding(
            key="{binding_key}",
            task_cls={class_name}Task,
            field_mapping=_{task}["mapping"],
            defaults=_{task}["defaults"],
            param_schema={class_name}Params,
            description="{description}",
        ),
    )
except Exception:
    logger.exception("Failed to register binding {binding_key}")
"""


# ---------------------------- utilities ---------------------------- #


def append_if_missing(path: Path, snippet: str) -> None:
    text = path.read_text()
    if snippet.strip() in text:
        return
    if not text.endswith("\n"):
        text += "\n"
    text += snippet
    path.write_text(text)


def add_to_all(path: Path, names: list[str]) -> None:
    """Ensure __all__ contains provided names."""
    text = path.read_text()
    match = re.search(r"__all__\s*=\s*(\[[^\]]*\])", text, flags=re.S)
    if not match:
        block = ",\n    ".join(f'"{n}"' for n in names)
        text = text.rstrip() + f'\n\n__all__ = [\n    {block},\n]\n'
    else:
        import ast

        try:
            current = list(ast.literal_eval(match.group(1)))
        except Exception:
            current = []
        for n in names:
            if n not in current:
                current.append(n)
        block = ",\n    ".join(f'"{n}"' for n in current)
        text = re.sub(r"__all__\s*=\s*\[[^\]]*\]", f"__all__ = [\n    {block},\n]", text, flags=re.S)
    path.write_text(text)


def ensure_import_before_all(path: Path, import_line: str) -> None:
    """Insert import_line before __all__ block if missing; fallback append."""
    text = path.read_text()
    if import_line.strip() in text:
        return
    pos = text.find("__all__")
    if pos != -1:
        text = text[:pos] + import_line + ("\n" if not import_line.endswith("\n") else "") + text[pos:]
    else:
        if not text.endswith("\n"):
            text += "\n"
        text += import_line + ("\n" if not import_line.endswith("\n") else "")
    path.write_text(text)


def add_binding_key_enum(registry_path: Path, binding_key: str) -> None:
    """Ensure BindingKey enum in registry.py contains the new key."""
    text = registry_path.read_text()
    entry = f'    {binding_key.upper()} = "{binding_key}"'
    if entry in text:
        return

    # Prefer inserting inside the existing BindingKey class block.
    pattern = r"(class BindingKey\([^)]*\):\n)([\s\S]*?)(\n(?=class\s|__all__|REGISTRY|#|$))"
    match = re.search(pattern, text)
    if match:
        body = match.group(2).rstrip("\n")
        lines = body.splitlines()
        while lines and lines[-1].strip() == "":
            lines.pop()
        lines.append(entry)
        new_body = "\n".join(lines) + "\n"
        text = text[: match.start(2)] + new_body + text[match.end(2) :]
        registry_path.write_text(text)
        return

    # Secondary fallback: if the class exists but regex failed, append inside that class via simple slicing.
    class_idx = text.find("class BindingKey")
    if class_idx != -1:
        next_class = text.find("\nclass ", class_idx + 1)
        block_end = next_class if next_class != -1 else len(text)
        block = text[class_idx:block_end]
        lines = block.splitlines()
        insert_at = len(lines)
        while insert_at > 0 and lines[insert_at - 1].strip() == "":
            insert_at -= 1
        lines.insert(insert_at, entry)
        new_block = "\n".join(lines)
        text = text[:class_idx] + new_block + text[block_end:]
        registry_path.write_text(text)
        return

    # No BindingKey class found: create one just before REGISTRY (or at end).
    insertion = f"\n\nclass BindingKey(StrEnum):\n{entry}\n\n"
    registry_idx = text.find("REGISTRY")
    if registry_idx != -1:
        text = text[:registry_idx] + insertion + text[registry_idx:]
    else:
        text = text.rstrip() + insertion

    registry_path.write_text(text)


def append_param_model(params_path: Path, class_name: str, input_types: dict[str, str]) -> None:
    import ast

    type_map = {
        "int": "int",
        "integer": "int",
        "float": "float",
        "double": "float",
        "number": "float",
        "bool": "bool",
        "boolean": "bool",
        "str": "str",
        "string": "str",
        "wkt": "str",
    }
    fields = []
    for field, ftype in input_types.items():
        py_type = type_map.get(str(ftype).lower(), "str")
        fields.append(f"    {field}: {py_type} | None = None")
    extra = "\n".join(fields) if fields else "    pass"
    stub = f"""\n\nclass {class_name}Params(AnalyticsParams):\n    \"\"\"Scaffolded params (extend as needed).\"\"\"\n{extra}\n"""
    text = params_path.read_text()
    if f"class {class_name}Params" not in text:
        text = text.rstrip() + stub
    # update __all__ robustly
    all_match = re.search(r"__all__\s*=\s*(\[[^\]]*\])", text, flags=re.S)
    if all_match:
        try:
            current = ast.literal_eval(all_match.group(1))
            if f"{class_name}Params" not in current:
                current.append(f"{class_name}Params")
            entries = ",\n    ".join(f'"{v}"' for v in current)
            replacement = f"__all__ = [\n    {entries},\n]"
            text = re.sub(r"__all__\s*=\s*\[[^\]]*\]", replacement, text, flags=re.S)
        except Exception:
            if f'"{class_name}Params"' not in text:
                text += f'\n__all__ = ["{class_name}Params"]\n'
    else:
        text += f'\n\n__all__ = ["{class_name}Params"]\n'
    params_path.write_text(text)


def parse_fields(data: dict[str, Any]) -> tuple[dict[str, str], dict[str, str]]:
    """Accepts either {col: remote} or {col: {field: remote, type: python_type}}."""
    mapping: dict[str, str] = {}
    types: dict[str, str] = {}
    for key, val in (data or {}).items():
        if isinstance(val, dict):
            field_name = val.get("field") or key
            mapping[key] = field_name
            if "type" in val:
                types[key] = str(val["type"])
        else:
            mapping[key] = str(val)
    return mapping, types


def build_context_from_yaml(path: Path) -> tuple[dict[str, str], dict[str, str], dict[str, str], dict[str, Any]]:
    data = load_yaml(path) or {}
    inputs_body, body_types = parse_fields(data.get("body") or data.get("inputs") or {})
    inputs_query, query_types = parse_fields(data.get("query") or {})
    outputs, output_types = parse_fields(data.get("outputs") or {})
    input_types = {**body_types, **query_types}
    meta = {
        "base_url": data.get("base_url", "https://api.example.com"),
        "endpoint": data.get("endpoint", "/path"),
        "method": data.get("method", "post"),
        "description": data.get("description", "Analytics task scaffolded from YAML"),
        "input_types": input_types,
        "output_types": output_types,
        "defaults": data.get("defaults", {}),
    }
    return inputs_body, inputs_query, outputs, meta


def build_context_from_openapi(
    spec_path: Path, path_hint: str | None, method: str | None, operation_id: str | None
) -> tuple[dict[str, str], dict[str, str], dict[str, str], dict[str, Any]]:
    # Be tolerant to non-UTF8 symbols (e.g., emojis) in the spec.
    spec = json.loads(spec_path.read_bytes().decode("utf-8", errors="replace"))
    paths = spec.get("paths") or {}
    target_path = path_hint
    target_method = (method or "post").lower()
    operation = None

    def _resolve_ref(schema: dict[str, Any]) -> dict[str, Any]:
        """Resolve a local $ref within the OpenAPI spec (shallow)."""
        if not isinstance(schema, dict):
            return {}
        ref = schema.get("$ref")
        if not ref or not isinstance(ref, str) or not ref.startswith("#/"):
            return schema
        target: Any = spec
        for part in ref.lstrip("#/").split("/"):
            if isinstance(target, dict):
                target = target.get(part)
            else:
                target = {}
                break
        return target if isinstance(target, dict) else {}

    if operation_id:
        for p, defs in paths.items():
            for m, detail in defs.items():
                if detail.get("operationId") == operation_id:
                    target_path, target_method, operation = p, m, detail
                    break
    if target_path and not operation:
        operation = (paths.get(target_path) or {}).get(target_method)
    if not operation:
        raise SystemExit("Could not find operation in OpenAPI spec; specify --path/--method or --operation-id.")
    base_url = spec.get("servers", [{}])[0].get("url", "https://api.example.com")
    request_schema = _resolve_ref((((operation.get("requestBody") or {}).get("content") or {}).get("application/json") or {}).get("schema") or {})
    response_schema = _resolve_ref(
        (((operation.get("responses") or {}).get("200", {}).get("content") or {}).get("application/json") or {}).get("schema") or {}
    )

    def props(schema: dict[str, Any]) -> dict[str, Any]:
        return (schema.get("properties") or {}) if isinstance(schema, dict) else {}

    def _schema_type(schema: dict[str, Any]) -> str:
        """Best-effort extraction of a primitive type from OpenAPI schema (handles anyOf/nullable)."""
        schema = _resolve_ref(schema)
        if not isinstance(schema, dict):
            return "string"
        if "type" in schema:
            t = schema.get("type")
            if isinstance(t, list):
                t = next((x for x in t if x != "null"), t[0] if t else "string")
            if t and t != "null":
                return str(t)
        for key in ("anyOf", "oneOf", "allOf"):
            options = schema.get(key)
            if isinstance(options, list):
                for opt in options:
                    t = _schema_type(opt)
                    if t != "null":
                        return t
        return "string"

    # Body schema
    input_props = props(request_schema)
    output_props = props(response_schema)
    input_required = set(request_schema.get("required", [])) if isinstance(request_schema, dict) else set()
    inputs = {k: k for k in input_props.keys()}
    outputs = {k: k for k in output_props.keys()}
    input_types = {k: _schema_type(v) for k, v in input_props.items() if isinstance(v, dict)}
    output_types = {k: _schema_type(v) for k, v in output_props.items() if isinstance(v, dict)}
    defaults: dict[str, Any] = {k: None for k in input_props.keys() if k not in input_required}

    # Query parameters
    params = list(operation.get("parameters") or []) + list(paths.get(target_path, {}).get("parameters") or [])
    query_inputs: dict[str, str] = {}
    for p in params:
        if p.get("in") == "query":
            name = p.get("name")
            if not name:
                continue
            query_inputs[name] = name
            schema_def = p.get("schema") or {}
            if isinstance(schema_def, dict):
                input_types[name] = _schema_type(schema_def)
            if not p.get("required", False):
                defaults[name] = None

    meta = {
        "base_url": base_url,
        "endpoint": target_path or "/path",
        "method": target_method,
        "description": operation.get("summary", "Analytics task scaffolded from OpenAPI"),
        "input_types": input_types,
        "output_types": output_types,
        "defaults": defaults,
    }
    return inputs, query_inputs, outputs, meta


# ---------------------------- main ---------------------------- #


def main() -> None:
    parser = argparse.ArgumentParser(description="Scaffold a new analytics task (client + task + registry wiring).")
    parser.add_argument("--mode", choices=["openapi", "yaml"], required=True, help="Input mode.")
    parser.add_argument("--source", required=True, help="Path to openapi.json or YAML config.")
    parser.add_argument("--task-name", required=True, help="snake_case task name, e.g., crop_mask_v2 (without _task suffix).")
    parser.add_argument("--binding-key", help="Override binding key (default: task-name).")
    parser.add_argument(
        "--target-root",
        default=None,
        help="Analytics package root (default: ../lib/analytics relative to this script).",
    )
    parser.add_argument("--path", dest="api_path", help="OpenAPI path (e.g., /v1/predict).")
    parser.add_argument("--method", dest="api_method", default="post", help="HTTP method for OpenAPI mode.")
    parser.add_argument("--operation-id", help="OpenAPI operationId to pick the endpoint.")
    parser.add_argument("--use-crop-cycle", action="store_true", help="Include crop cycle handling (season duration/start from crop_cycle.csv).")
    parser.add_argument("--signature-cache", action="store_true", help="Generate a signature column to skip reprocessing identical inputs.")
    parser.add_argument("--force", action="store_true", help="Overwrite existing files.")
    args = parser.parse_args()

    task = snake(args.task_name)
    class_name = title(task)
    binding_key = args.binding_key or task
    default_root = Path(__file__).resolve().parents[1] / "lib" / "analytics"
    analytics_root = Path(args.target_root) if args.target_root else default_root
    tasks_dir = analytics_root / "tasks"
    registry_path = analytics_root / "registry.py"
    tasks_init = tasks_dir / "__init__.py"
    analytics_init = analytics_root / "__init__.py"
    clients_dir = analytics_root.parent / "clients"
    registry_text = registry_path.read_text()
    if re.search(rf'key=["\\\']{re.escape(binding_key)}["\\\']', registry_text):
        raise SystemExit(f"Binding key '{binding_key}' already present in registry.py; aborting to avoid duplicates.")

    source_path = Path(args.source)
    if not source_path.exists():
        raise SystemExit(f"Source file not found: {source_path}")

    if args.mode == "yaml":
        inputs_body, inputs_query, outputs, meta = build_context_from_yaml(source_path)
    else:
        inputs_body, inputs_query, outputs, meta = build_context_from_openapi(source_path, args.api_path, args.api_method, args.operation_id)

    client_code = render_client(task, meta["base_url"], meta["endpoint"], meta["method"], binding_key=binding_key)
    task_code = render_task(
        task,
        binding_key,
        inputs_body,
        inputs_query,
        outputs,
        args.use_crop_cycle,
        args.signature_cache,
        extra_defaults=meta.get("defaults") or {},
    )
    register_block = render_registry_block(task, binding_key, meta["description"], class_name)

    client_path = clients_dir / f"{task}_client.py"
    task_path = tasks_dir / f"{task}_task.py"
    params_path = analytics_root / "params.py"
    # guard against existing files without --force
    for p in (client_path, task_path):
        if p.exists() and not args.force:
            raise SystemExit(f"File already exists: {p}. Use --force to overwrite.")

    write_file(client_path, client_code, args.force)
    write_file(task_path, task_code, args.force)

    import_line_task = f"from .{task}_task import {class_name}Task, default_{task}_bindings  # noqa: F401"
    ensure_import_before_all(tasks_init, import_line_task)
    add_to_all(tasks_init, [f"{class_name}Task", f"default_{task}_bindings"])

    import_line_analytics_task = f"from .tasks import {class_name}Task, default_{task}_bindings  # scaffold import"
    import_line_analytics_params = f"from .params import {class_name}Params  # scaffold import"
    ensure_import_before_all(analytics_init, import_line_analytics_task)
    ensure_import_before_all(analytics_init, import_line_analytics_params)
    add_to_all(analytics_init, [f"{class_name}Task", f"default_{task}_bindings", f"{class_name}Params"])
    append_param_model(params_path, class_name, meta.get("input_types") or {})
    append_if_missing(registry_path, register_block)
    add_binding_key_enum(registry_path, binding_key)

    sys.stdout.write(f"Generated client at {client_path}\n")
    sys.stdout.write(f"Generated task at {task_path}\n")
    sys.stdout.write(f"Updated params at {params_path}\n")
    sys.stdout.write(f"Updated registry at {registry_path}\n")
    sys.stdout.write("Review TODOs in generated files before committing.\n")


if __name__ == "__main__":
    main()

"""Folium-based visualization helpers for quick notebook previews."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

import folium
import pandas as pd
from folium.plugins import MarkerCluster
from shapely import wkb as shapely_wkb, wkt as shapely_wkt
from shapely.geometry import box, Point, shape
from shapely.geometry.base import BaseGeometry


def _to_geometry(value: object) -> BaseGeometry:
    """Convert WKT/geo-interface objects to shapely geometries."""
    if isinstance(value, BaseGeometry):
        return value
    if isinstance(value, (bytes, memoryview)):
        return shapely_wkb.loads(value)
    if isinstance(value, str):
        return shapely_wkt.loads(value)
    if hasattr(value, "__geo_interface__"):
        return shape(value.__geo_interface__)  # type: ignore[arg-type]
    raise TypeError("Geometry values must be WKT strings or shapely-compatible objects.")


def _estimate_zoom(span_degrees: float) -> int:
    """Pick a reasonable zoom level given the data extent."""
    if span_degrees <= 0.05:
        return 14
    if span_degrees <= 0.2:
        return 12
    if span_degrees <= 0.5:
        return 10
    if span_degrees <= 1.5:
        return 9
    if span_degrees <= 3:
        return 8
    if span_degrees <= 6:
        return 7
    if span_degrees <= 12:
        return 6
    return 5


def _format_popup(properties: Mapping[str, object], columns: Sequence[str]) -> folium.Popup | None:
    if not columns:
        return None
    rows = []
    for column in columns:
        value = properties.get(column, "")
        try:
            # Normalize pandas/NumPy timestamps to ISO strings to avoid JSON serialization errors.
            if hasattr(value, "isoformat"):
                value = value.isoformat()
        except Exception:
            pass
        rows.append(f"<strong>{column}</strong>: {value}")
    html = "<br>".join(rows)
    return folium.Popup(html, max_width=450)


def items_to_geoms(items: Sequence[Mapping[str, object]]) -> list[BaseGeometry]:
    """Convert API items (point/wkt/bbox) to shapely geometries."""
    geoms: list[BaseGeometry] = []
    for item in items:
        if not isinstance(item, Mapping):
            continue
        t = str(item.get("type") or "").lower()
        if t == "wkt":
            value = item.get("value")
            if isinstance(value, str):
                try:
                    geoms.append(shapely_wkt.loads(value))
                except Exception:
                    continue
        elif t == "point":
            lon = item.get("lon") or item.get("lng")
            lat = item.get("lat")
            if lon is None or lat is None:
                continue
            try:
                pt = Point(float(lon), float(lat))
                radius_m = item.get("radius_m") or item.get("radius")
                if radius_m and isinstance(radius_m, (int, float)):
                    # Approximate buffer in degrees (~111_320 m per deg lat)
                    deg_per_meter = 1 / 111_320
                    geoms.append(pt.buffer(float(radius_m) * deg_per_meter))
                else:
                    geoms.append(pt)
            except Exception:
                continue
        elif t == "bbox":
            try:
                geoms.append(
                    box(
                        float(item["min_lon"]),
                        float(item["min_lat"]),
                        float(item["max_lon"]),
                        float(item["max_lat"]),
                    )
                )
            except Exception:
                continue
    return geoms


def preview_geometries_map(
    df: pd.DataFrame | None = None,
    geometries: Sequence[object] | None = None,
    *,
    geometry_column: str = "geometry_wkt",
    popup_columns: Sequence[str] | None = None,
    tooltip_columns: Sequence[str] | None = None,
    base_tiles: str = "CartoDB positron",
    add_osm_layer: bool = True,
    add_satellite_layers: bool = True,
    zoom_start: int | None = None,
    max_features: int = 500,
    simplify_tolerance: float | None = None,
    add_layer_control: bool = True,
    render_mode: str = "geometry",  # geometry | centroid
    cluster_points: bool = False,
) -> folium.Map:
    """Return an interactive folium.Map showing the given geometries.

    The popup displays every column except the geometry by default so that adding new
    fields to the parquet automatically enriches the map. Multiple base layers are
    available so users can switch between OpenStreetMap and satellite imagery.
    """
    if df is None and geometries is None:
        raise ValueError("Provide either a dataframe (df) or a sequence of geometries.")
    if df is not None and df.empty:
        raise ValueError("Cannot render map for an empty DataFrame.")
    if df is not None and geometry_column not in df.columns:
        raise KeyError(f"Missing geometry column '{geometry_column}'.")

    popup_columns = (
        list(popup_columns) if popup_columns is not None else ([col for col in df.columns if col != geometry_column] if df is not None else [])
    )
    tooltip_columns = list(tooltip_columns) if tooltip_columns is not None else []
    if not tooltip_columns and df is not None:
        tooltip_columns = [col for col in ("spatial_unit_id", "geohash5", "n_county") if col in df.columns]

    properties_list: list[dict[str, object]] = []

    def _safe_value(val: object) -> object:
        """Coerce numpy/array types to JSON-serializable basics."""
        try:
            import numpy as np  # type: ignore
        except Exception:
            np = None  # type: ignore

        if np is not None:
            if isinstance(val, (np.generic,)):
                return val.item()
            if isinstance(val, np.ndarray):
                return val.tolist()
        try:
            if hasattr(val, "isoformat"):
                return val.isoformat()
        except Exception:
            pass
        return val

    geom_list: list[BaseGeometry] = []
    if geometries is not None:
        for geom in list(geometries):
            geom_list.append(_to_geometry(geom))
            properties_list.append({})
    elif df is not None:
        for _, row in df.iterrows():
            geometry = _to_geometry(row[geometry_column])
            geom_list.append(geometry)
            properties_list.append({col: _safe_value(row[col]) for col in df.columns if col != geometry_column})

    if len(geom_list) > max_features:
        geom_list = geom_list[:max_features]
        properties_list = properties_list[:max_features]

    if not geom_list:
        raise ValueError("No geometries to render.")

    bounds = geom_list[0].bounds
    minx, miny, maxx, maxy = bounds
    for geom in geom_list[1:]:
        gminx, gminy, gmaxx, gmaxy = geom.bounds
        minx = min(minx, gminx)
        miny = min(miny, gminy)
        maxx = max(maxx, gmaxx)
        maxy = max(maxy, gmaxy)

    center_lat = (miny + maxy) / 2
    center_lon = (minx + maxx) / 2
    span = max(maxx - minx, maxy - miny)
    map_zoom = zoom_start if zoom_start is not None else _estimate_zoom(span)
    fmap = folium.Map(location=[center_lat, center_lon], zoom_start=map_zoom, tiles=None)
    folium.TileLayer(base_tiles, name="Base map", control=True).add_to(fmap)
    if add_osm_layer and base_tiles != "OpenStreetMap":
        folium.TileLayer("OpenStreetMap", name="OpenStreetMap", control=True).add_to(fmap)
    if add_satellite_layers:
        folium.TileLayer(
            tiles="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
            attr="Esri",
            name="Esri Satellite",
            overlay=False,
            control=True,
        ).add_to(fmap)
        folium.TileLayer(
            tiles="https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",
            attr="Google",
            name="Google Satellite",
            overlay=False,
            control=True,
        ).add_to(fmap)

    # When rendering many points, clustering reduces browser load.
    marker_cluster = MarkerCluster() if cluster_points and render_mode == "centroid" else None

    for geometry, props in zip(geom_list, properties_list, strict=False):
        if simplify_tolerance is not None and simplify_tolerance > 0:
            try:
                geometry = geometry.simplify(simplify_tolerance, preserve_topology=True)
            except Exception:
                pass
        draw_geom = geometry
        if render_mode == "centroid":
            try:
                draw_geom = geometry.centroid
            except Exception:
                draw_geom = geometry

        feature = {
            "type": "Feature",
            "geometry": draw_geom.__geo_interface__,
            "properties": props,
        }
        if marker_cluster is not None:
            tooltip_text = ", ".join(f"{col}: {props.get(col, '')}" for col in tooltip_columns if col in props) if tooltip_columns else None
            popup = _format_popup(props, popup_columns)
            folium.Marker(
                location=[draw_geom.y, draw_geom.x],
                tooltip=tooltip_text,
                popup=popup,
            ).add_to(marker_cluster)
        else:
            geo_json = folium.GeoJson(
                feature,
                style_function=lambda _: {
                    "color": "#2a81cb",
                    "weight": 1,
                    "fillColor": "#3388ff",
                    "fillOpacity": 0.3,
                },
            )
            tooltip_fields = [col for col in tooltip_columns if col in props]
            if tooltip_fields:
                geo_json.add_child(
                    folium.GeoJsonTooltip(
                        fields=tooltip_fields,
                        aliases=[f"{field}: " for field in tooltip_fields],
                        sticky=False,
                    )
                )
            popup = _format_popup(props, popup_columns)
            if popup:
                geo_json.add_child(popup)
            geo_json.add_to(fmap)

    if marker_cluster is not None:
        marker_cluster.add_to(fmap)

    if add_layer_control:
        folium.LayerControl().add_to(fmap)
    return fmap


__all__ = ["preview_geometries_map", "items_to_geoms"]

"""Helpers for working with parquet artifacts referenced in the notebooks."""

from __future__ import annotations

import io
import logging
import shutil
import tempfile
import warnings
from pathlib import Path
from typing import BinaryIO
from urllib.parse import urlsplit

import geopandas as gpd
import pandas as pd
import pyarrow.parquet as pq
import requests

from .jobs import wait_for_job


logger = logging.getLogger(__name__)


def _ensure_geometry_series(series: pd.Series) -> gpd.GeoSeries:
    """Best-effort conversion of a Series to a GeoSeries (WKB/WKT/shapely)."""
    not_null = series.dropna()
    sample = not_null.iloc[0] if not not_null.empty else None

    # Attempt direct conversion first
    try:
        return gpd.GeoSeries(series, crs="EPSG:4326")
    except Exception:
        pass

    # WKB input
    if isinstance(sample, (bytes, bytearray, memoryview)):
        try:
            return gpd.GeoSeries.from_wkb(series, crs="EPSG:4326")
        except Exception:
            pass

    # WKT input
    if isinstance(sample, str):
        try:
            return gpd.GeoSeries.from_wkt(series, crs="EPSG:4326")
        except Exception:
            pass

    # Fallback: keep as-is
    return gpd.GeoSeries(series, crs="EPSG:4326")


def _coerce_dataframe_to_geodf(df: pd.DataFrame) -> gpd.GeoDataFrame:
    """Ensure ``df`` is returned as a GeoDataFrame when geometry columns are present."""
    if isinstance(df, gpd.GeoDataFrame):
        return df

    if "geometry" in df.columns:
        col = df["geometry"]

        def _to_bytes(val: object) -> object:
            if isinstance(val, bytes):
                return val
            if isinstance(val, memoryview):
                return bytes(val)
            if isinstance(val, str):
                try:
                    return val.encode("latin1")
                except Exception:
                    return val
            return val

        col_bytes = col.apply(_to_bytes)

        try:
            geometry = gpd.GeoSeries.from_wkb(col_bytes)
        except Exception:
            try:
                geometry = gpd.GeoSeries.from_wkt(col_bytes)
            except Exception:
                geometry = gpd.GeoSeries(col_bytes)
        return gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:4326")

    if "geometry_wkt" in df.columns:
        geometry = gpd.GeoSeries.from_wkt(df.pop("geometry_wkt"))
        return gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:4326")

    if "wkt" in df.columns:
        return gpd.GeoDataFrame(df, geometry=gpd.GeoSeries.from_wkt(df["wkt"]), crs="EPSG:4326")

    return gpd.GeoDataFrame(df)


def _normalize_list_columns(df: pd.DataFrame, cols: tuple[str, ...] = ("crop_history_years_list",)) -> pd.DataFrame:
    """Ensure specified columns are plain Python lists (not numpy arrays) for JSON safety."""
    try:
        import numpy as np
    except Exception:  # pragma: no cover
        np = None  # type: ignore

    for col in cols:
        if col in df.columns:

            def _to_list(val):
                if val is None or (isinstance(val, float) and pd.isna(val)):
                    return []
                if np is not None and isinstance(val, np.ndarray):
                    return [int(x) for x in val]
                if isinstance(val, (list, tuple)):
                    return [int(x) for x in val]
                try:
                    return [int(val)]
                except Exception:
                    return []

            df[col] = df[col].apply(_to_list)
    return df


def _read_parquet_buffer(buffer: BinaryIO) -> gpd.GeoDataFrame:
    """Read a parquet buffer (bytes) and return a GeoDataFrame when possible."""
    try:
        buffer.seek(0)
        return gpd.read_parquet(buffer)
    except Exception:
        buffer.seek(0)
        table = pq.read_table(buffer)
        df = table.to_pandas()
        return _coerce_dataframe_to_geodf(df)


def download_parquet_to_df(url: str) -> gpd.GeoDataFrame:
    """Download a parquet file exposed via a signed URL and convert it to a GeoDataFrame."""
    resp = requests.get(url, timeout=60)
    resp.raise_for_status()
    buffer = io.BytesIO(resp.content)
    df = _read_parquet_buffer(buffer)
    # Normalize list-like columns that may be rehydrated as numpy arrays by pyarrow.
    df = _normalize_list_columns(df)
    return df


def load_local_parquet(path: str | Path) -> gpd.GeoDataFrame:
    """Load a parquet artifact from disk and return a GeoDataFrame with consistent geometry handling."""
    resolved = Path(path).expanduser()
    try:
        df = gpd.read_parquet(resolved)
    except Exception:
        table = pq.read_table(resolved)
        df = table.to_pandas()
        df = _coerce_dataframe_to_geodf(df)
    return _normalize_list_columns(df)


def write_geo_parquet(df: gpd.GeoDataFrame, path: str) -> None:
    """
    Persist a GeoDataFrame/DataFrame to parquet, handling geometry safely.

    - If a geometry column exists (GeoDataFrame or column named 'geometry'/'geometry_wkt'),
      coerce to a GeoSeries then convert to WKB before writing to avoid Arrow type errors.
    - Otherwise, fall back to plain DataFrame parquet.
    """
    geom_name = None
    if isinstance(df, gpd.GeoDataFrame):
        geom_name = df.geometry.name or "geometry"
    elif "geometry" in df.columns:
        geom_name = "geometry"
    elif "geometry_wkt" in df.columns:
        geom_name = "geometry_wkt"

    if geom_name:
        gdf = df.copy()
        if geom_name == "geometry_wkt":
            gdf["geometry"] = gpd.GeoSeries.from_wkt(gdf["geometry_wkt"], crs="EPSG:4326")
            geom_name = "geometry"
        if geom_name in gdf.columns:
            geom_series = _ensure_geometry_series(gdf[geom_name])
            # If already bytes-like (WKB) skip conversion to avoid warnings
            if isinstance(geom_series.iloc[0] if not geom_series.empty else None, (bytes, bytearray, memoryview)):
                pass
            else:
                try:
                    with warnings.catch_warnings():
                        warnings.filterwarnings("ignore", "Geometry column does not contain geometry.")
                        gdf[geom_name] = geom_series.to_wkb()
                except Exception:
                    # Fallback: leave geometry untouched if conversion fails
                    pass
        gdf.to_parquet(path, engine="pyarrow", index=False)
    else:
        df.to_parquet(path, engine="pyarrow", index=False)


def publish_group_artifact(
    session,
    group_code: str,
    file_path: str | Path | None = None,
    *,
    df: pd.DataFrame | gpd.GeoDataFrame | None = None,
    filename: str | None = None,
    description: str | None = None,
    persist_path: str | Path | None = None,
    wait_job: bool = True,
    poll_seconds: float = 5.0,
    timeout_seconds: float = 900.0,
) -> dict:
    """
    Upload a parquet file as a new artifact for the given group.

    Steps:
      1. Request a presigned upload URL from the API.
      2. PUT the file to S3 using that URL.
      3. Confirm the upload so the artifact is registered in the database.

    You can pass either an existing parquet path (`file_path`) or a dataframe (`df`).
    When a dataframe is provided, it is written to a temporary parquet before upload.
    Optionally persist a local copy via `persist_path`.
    """
    if file_path is None and df is None:
        raise ValueError("Provide either file_path or df for publish_group_artifact")

    temp_dir: tempfile.TemporaryDirectory[str] | None = None
    try:
        if file_path is None:
            filename = filename or "data.parquet"
            temp_dir = tempfile.TemporaryDirectory()
            file_path = Path(temp_dir.name) / filename
            write_geo_parquet(df, file_path)
            logger.info("Temporary parquet written for upload: %s", file_path)
            if persist_path:
                persist_path = Path(persist_path)
                persist_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(file_path, persist_path)
                logger.info("Local copy persisted at %s", persist_path)
        else:
            file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(file_path)

        logger.info("Step 1/3: requesting presigned upload URL for %s", file_path.name)
        presign = session.get(
            f"/v1/groups/{group_code}/presign-upload",
            params={"filename": file_path.name},
        )
        version = presign["version"]
        expires_in = presign.get("expires_in")
        logger.info(
            "Presigned URL received%s. Assigned version: v%s",
            f" (TTL {expires_in}s)" if expires_in else "",
            version,
        )
        try:
            parsed = urlsplit(presign.get("url", ""))
            host = parsed.netloc
            path = parsed.path
            if host:
                logger.info("Upload target host: %s", host)
            if path:
                logger.info("Upload target key (from URL path): %s", path.lstrip("/"))
        except Exception:
            pass

        if not presign.get("url"):
            raise ValueError("Presign response missing 'url'")

        logger.info(
            "Step 2/3: uploading file to storage… (size=%s bytes, method=%s)",
            file_path.stat().st_size,
            "POST" if presign.get("fields") else "PUT",
        )
        try:
            payload = file_path.read_bytes()
            extra_headers = presign.get("headers") or {}
            headers = {"Content-Type": "application/octet-stream", **extra_headers}
            headers.setdefault("Content-Length", str(len(payload)))

            if presign.get("fields"):  # S3 presigned POST
                fields = presign["fields"]
                files = {"file": (file_path.name, payload, headers.get("Content-Type", "application/octet-stream"))}
                response = requests.post(
                    presign["url"],
                    data=fields,
                    files=files,
                    timeout=300,
                )
            else:  # Presigned PUT
                response = requests.put(
                    presign["url"],
                    data=payload,
                    headers=headers,
                    timeout=300,
                )
        except Exception:
            logger.exception("Upload failed before reaching server")
            raise

        if not response.ok:
            # Surface more details to ease debugging signature/permission errors
            body_preview = response.text[:500] if response.text else response.content[:500]
            logger.error(
                "Upload failed: status=%s, reason=%s, body=%s",
                response.status_code,
                response.reason,
                body_preview,
            )
            response.raise_for_status()
        logger.info("Upload complete.")

        logger.info("Step 3/3: confirming upload with the API…")
        confirm_payload = {"filename": file_path.name, "version": version}
        if description:
            confirm_payload["description"] = description
        confirmation = session.post(
            f"/v1/groups/{group_code}/confirm-upload",
            json=confirm_payload,
        )
        logger.info("Confirmation requested.")
        logger.info(f"confirmation > {confirmation}")
        job_id = confirmation.get("job_id") or confirmation.get("upload_id")
        if wait_job and job_id:
            logger.info("Polling job %s until completion…", job_id)

            def _fetch_status(sess, jid):
                return sess.get(f"/v1/jobs/{jid}")

            job_result = wait_for_job(
                session,
                job_id,
                _fetch_status,
                poll_seconds=poll_seconds,
                timeout_seconds=timeout_seconds,
                include_raw=True,
                human_readable=False,
            )
            confirmation["job_status"] = job_result

        return confirmation
    finally:
        if temp_dir is not None:
            temp_dir.cleanup()

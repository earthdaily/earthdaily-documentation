"""Job monitoring utilities with notebook-friendly summary."""

from __future__ import annotations

import html
import time
from collections.abc import Callable
from typing import Any

from ..clients.api_client import ApiSession


_TERMINAL_STATES = {"SUCCEEDED", "FAILED", "ERROR", "COMPLETED"}
_STATUS_BADGES = {
    "COMPLETED": ("#DCFCE7", "#166534"),  # bg, fg (vert)
    "SUCCEEDED": ("#DCFCE7", "#166534"),
    "FAILED": ("#FEE2E2", "#7F1D1D"),  # rouge
    "ERROR": ("#FEF3C7", "#78350F"),  # ambre
    "RUNNING": ("#DBEAFE", "#1E3A8A"),  # bleu
    "UNKNOWN": ("#E5E7EB", "#111827"),  # gris
}


def _extract_state(payload: dict[str, Any]) -> tuple[str | None, str | None]:
    """Return the job state (uppercased) and any accompanying message."""
    raw_state = payload.get("status") or payload.get("state")
    state: Any = None
    message: Any = payload.get("message")

    def _to_upper(value: Any) -> str | None:
        if isinstance(value, str):
            return value.upper()
        if value is not None:
            return str(value).upper()
        return None

    def _to_text(value: Any) -> str | None:
        if isinstance(value, str):
            return value
        if value is not None:
            return str(value)
        return None

    if isinstance(raw_state, dict):
        # Handle nested shapes such as {"status": {"status": "completed", "message": "..."}}
        for key in ("status", "state", "name", "value", "code"):
            nested_state = raw_state.get(key)
            if isinstance(nested_state, str):
                state = nested_state
                break
            if nested_state is not None:
                state = nested_state
                break
        else:
            state = None
        message = raw_state.get("message", message)
    else:
        state = raw_state

    return _to_upper(state), _to_text(message)


def _format_result(progress: dict[str, Any] | None) -> dict[str, int]:
    """Normalize backend progress keys into explicit domains."""
    progress = progress or {}
    total = int(progress.get("total", 0))
    valid = int(progress.get("valid", 0))
    invalid = int(progress.get("invalid", 0))
    persisted = int(progress.get("persisted", 0))
    reused = int(progress.get("reused", 0))

    return {
        # Input items (what you POSTed to the endpoint)
        "input_total_items": total,  # count of input items
        "input_valid_items": valid,  # valid input items
        "input_invalid_items": invalid,  # invalid input items
        # Spatial units impact (DB effects), across **all** input items
        "spatial_units_persisted": persisted,  # newly inserted
        "spatial_units_reused": reused,  # already existing
        "spatial_units_total": persisted + reused,  # total touched/returned
    }


def _plural(n: int, singular: str, plural: str | None = None) -> str:
    if n == 1:
        return f"1 {singular}"
    return f"{n} {plural or singular + 's'}"


def _badge(text: str, bg: str, fg: str) -> str:
    return (
        f'<span style="display:inline-block;padding:2px 8px;'
        f'border-radius:999px;background:{bg};color:{fg};'
        f'font-weight:700;font-size:0.85em;">{html.escape(text)}</span>'
    )


def _render_summary(state: str, message: str, result: dict) -> str:
    items_total = result["input_total_items"]
    items_valid = result["input_valid_items"]
    items_invalid = result["input_invalid_items"]
    persisted = result["spatial_units_persisted"]
    reused = result["spatial_units_reused"]
    su_total = result["spatial_units_total"]

    # couleurs simples
    green = "#059669"  # valid
    red = "#DC2626"  # invalid
    blue = "#2563EB"  # totals SU/persisted/reused

    # badge d'état
    bg, fg = _STATUS_BADGES.get((state or "UNKNOWN").upper(), _STATUS_BADGES["UNKNOWN"])
    state_badge = _badge(state or "UNKNOWN", bg, fg)

    # texte (Markdown + HTML inline)
    lines = [
        '<br>',
        f'<div><strong>State:</strong> {state_badge} — <em>{html.escape(message) if message else "No message provided."}</em></div>',
        "",
        "### Input",
        (
            f'- Items: <strong>{items_total}</strong> '
            f'(<span style="color:{green};"><strong>valid: {items_valid}</strong></span>, '
            f'<span style="color:{red};"><strong>invalid: {items_invalid}</strong></span>)'
        ),
        "",
        "### Spatial units",
        (
            f'- Total: <span style="color:{blue};"><strong>{su_total}</strong></span> '
            f'(persisted/new: <span style="color:{blue};"><strong>{persisted}</strong></span>, '
            f'reused/existing: <span style="color:{blue};"><strong>{reused}</strong></span>)'
        ),
    ]

    # phrase récap
    noun = "item" if items_total == 1 else "items"
    lines.append(
        f'\nThis job processed <strong>{items_total}</strong> {noun} and resulted in '
        f'<strong>{su_total}</strong> spatial unit(s): '
        f'<span style="color:{blue};"><strong>{persisted}</strong></span> new, '
        f'<span style="color:{blue};"><strong>{reused}</strong></span> existing.'
    )

    return "\n".join(lines)


def wait_for_job(
    session: ApiSession,
    job_id: str,
    fetch_status: Callable[[ApiSession, str], dict[str, Any]],
    *,
    poll_seconds: float = 5.0,
    timeout_seconds: float = 600.0,
    include_raw: bool = False,
    human_readable: bool = True,
) -> dict[str, Any]:
    """
    Poll `fetch_status` until terminal or timeout.

    Returns a structured payload suitable for notebooks:

        {
          "job_id": "...",
          "state": "COMPLETED" | "FAILED" | "ERROR" | "SUCCEEDED" | "UNKNOWN",
          "message": "...",
          "result": {
            "input_total_items": ...,
            "input_valid_items": ...,
            "input_invalid_items": ...,
            "spatial_units_persisted": ...,
            "spatial_units_reused": ...,
            "spatial_units_total": ...
          },
          "summary": "...",  # Markdown-ish text, if human_readable=True
          # optionally:
          "raw": {...}       # if include_raw=True
        }
    """
    deadline = time.time() + timeout_seconds
    last_status: dict[str, Any] = {}

    while time.time() < deadline:
        last_status = fetch_status(session, job_id)
        state, status_message = _extract_state(last_status)

        if state in _TERMINAL_STATES:
            result = _format_result(last_status.get("progress"))
            summary = _render_summary(state or "UNKNOWN", status_message or "", result) if human_readable else None

            out: dict[str, Any] = {
                "job_id": last_status.get("job_id", job_id),
                "state": state or "UNKNOWN",
                "message": status_message or "No message provided",
                "result": result,
            }
            if human_readable:
                out["summary"] = summary
            if include_raw:
                out["raw"] = last_status
            return out

        # Non-terminal: keep current behavior (log & wait)
        display_state = state or "UNKNOWN"
        display_message = status_message or "No message provided"
        print(f"[wait_for_job] Job {job_id} status={display_state} message={display_message}")
        time.sleep(poll_seconds)

    raise TimeoutError(f"Job {job_id} did not complete within {timeout_seconds} seconds. Last status: {last_status}")

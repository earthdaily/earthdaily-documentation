"""Geometry utilities shared across notebooks."""

from __future__ import annotations

from typing import Any

from shapely import wkb as shapely_wkb
from shapely.geometry import shape
from shapely.geometry.base import BaseGeometry


def to_wkt(value: Any) -> str:
    """Return a WKT string from various geometry representations."""
    if isinstance(value, str):
        return value
    if isinstance(value, (bytes, memoryview)):
        return shapely_wkb.loads(value).wkt
    if isinstance(value, BaseGeometry):
        return value.wkt
    if hasattr(value, "__geo_interface__"):
        return shape(value.__geo_interface__).wkt  # type: ignore[arg-type]
    raise TypeError("Geometry column must contain WKT or shapely-compatible objects")


__all__ = ["to_wkt"]

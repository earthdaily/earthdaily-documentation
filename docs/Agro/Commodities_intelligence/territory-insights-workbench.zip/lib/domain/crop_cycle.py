"""Crop cycle configuration loader used by analytics notebooks."""

from __future__ import annotations

import csv
import datetime as _dt
import math
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CropCycleConfig:
    """Normalized crop cycle parameters consumed by processors."""

    crop: str
    season_duration: int
    season_start_day: int
    season_start_month: int
    threshold: float
    threshold_inseason: float
    scope: str = "default"  # e.g. default/state/county
    state: str | None = None
    county: str | None = None


DEFAULT_CYCLE = CropCycleConfig(
    crop="DEFAULT",
    season_duration=300,
    season_start_day=15,
    season_start_month=1,
    threshold=20.0,
    threshold_inseason=0.7,
)


class CropCycleCatalog:
    """In-memory catalog backed by CSV files with hierarchical overrides."""

    def __init__(
        self,
        crop_defaults: dict[str, CropCycleConfig],
        *,
        state_overrides: dict[tuple[str, str], CropCycleConfig] | None = None,
        county_overrides: dict[tuple[str, str, str], CropCycleConfig] | None = None,
        default: CropCycleConfig = DEFAULT_CYCLE,
    ) -> None:
        self._crop_defaults = crop_defaults
        self._state_overrides = state_overrides or {}
        self._county_overrides = county_overrides or {}
        self._default = default

    @classmethod
    def from_csv(
        cls,
        path: str | None = None,
        *,
        state_timewindows_path: str | None = None,
        county_timewindows_path: str | None = None,
        default_crop_for_timewindows: str = "CORN",
        override_threshold: float = 20.0,
        override_threshold_inseason: float = 0.67,
    ) -> CropCycleCatalog:
        """Load crop cycles and optional state/county overrides from CSV files."""
        base_dir = Path(__file__).resolve().parents[2]
        # Prefer the package-level config directory if it exists, else fall back to lib/config
        default_config_dir = base_dir / "config"
        if not default_config_dir.exists():
            default_config_dir = Path(__file__).resolve().parents[1] / "config"

        config_dir = Path(path).parent if path else default_config_dir
        csv_path = Path(path) if path else config_dir / "crop_cycle.csv"
        if not csv_path.exists():
            raise FileNotFoundError(f"Crop cycle CSV not found at {csv_path}")

        crop_defaults: dict[str, CropCycleConfig] = {}
        with csv_path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            required = {
                "crop",
                "season_duration_max",
                "season_start_day",
                "season_start_month",
                "threshold",
                "threshold_inseason",
            }
            missing = required - set(reader.fieldnames or [])
            if missing:
                raise ValueError(f"Missing columns in crop cycle CSV: {', '.join(sorted(missing))}")

            for row in reader:
                crop_name = (row.get("crop") or "").strip().upper()
                if not crop_name:
                    continue
                crop_defaults[crop_name] = CropCycleConfig(
                    crop=crop_name,
                    season_duration=int(float(row["season_duration_max"])),
                    season_start_day=int(float(row["season_start_day"])),
                    season_start_month=int(float(row["season_start_month"])),
                    threshold=float(row["threshold"]),
                    threshold_inseason=float(row["threshold_inseason"]),
                )
        if not crop_defaults:
            raise ValueError("Crop cycle CSV did not contain any rows")

        state_path = Path(state_timewindows_path) if state_timewindows_path else config_dir / "state_level_timewindows.csv"
        county_path = Path(county_timewindows_path) if county_timewindows_path else config_dir / "county_level_timewindows.csv"

        state_overrides = cls._load_timewindow_overrides(
            state_path,
            level="state",
            default_crop=default_crop_for_timewindows,
            threshold=override_threshold,
            threshold_inseason=override_threshold_inseason,
        )
        county_overrides = cls._load_timewindow_overrides(
            county_path,
            level="county",
            default_crop=default_crop_for_timewindows,
            threshold=override_threshold,
            threshold_inseason=override_threshold_inseason,
        )

        return cls(
            crop_defaults,
            state_overrides=state_overrides,
            county_overrides=county_overrides,
        )

    def get(self, crop: str, *, state: str | None = None, county: str | None = None) -> CropCycleConfig:
        """Return the config for ``crop`` with optional state/county overrides."""
        crop_key = (crop or "").upper()
        state_key = _normalize_state(state)
        county_key = _normalize_county(county)

        if state_key and county_key:
            county_override = self._county_overrides.get((state_key, county_key, crop_key))
            if county_override:
                return county_override

        if state_key:
            state_override = self._state_overrides.get((state_key, crop_key))
            if state_override:
                return state_override

        return self._crop_defaults.get(crop_key, self._default)

    @staticmethod
    def _load_timewindow_overrides(
        csv_path: Path,
        *,
        level: str,
        default_crop: str,
        threshold: float,
        threshold_inseason: float,
    ) -> dict[tuple[str, ...], CropCycleConfig]:
        """Convert state/county time-window CSV into CropCycleConfig overrides."""
        overrides: dict[tuple[str, ...], CropCycleConfig] = {}
        if not csv_path.exists():
            return overrides

        with csv_path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            required = {"start_day_of_year", "end_day_of_year", "state"}
            if level == "county":
                required.add("county")
            missing = required - set(reader.fieldnames or [])
            if missing:
                raise ValueError(f"Missing columns in {csv_path.name}: {', '.join(sorted(missing))}")

            for row in reader:
                state_code = _normalize_state(row.get("state"))
                if not state_code:
                    continue
                county_value = row.get("county") if level == "county" else None
                county_code = _normalize_county(county_value)
                start_doy = _safe_int(row.get("start_day_of_year"))
                end_doy = _safe_int(row.get("end_day_of_year"))
                if end_doy <= start_doy:
                    continue
                season_duration = end_doy - start_doy
                start_day, start_month = _doy_to_day_month(start_doy)
                crop_name = (row.get("crop") or default_crop).strip().upper()
                config = CropCycleConfig(
                    crop=crop_name,
                    season_duration=season_duration,
                    season_start_day=start_day,
                    season_start_month=start_month,
                    threshold=threshold,
                    threshold_inseason=threshold_inseason,
                    scope=level,
                    state=state_code,
                    county=county_code,
                )
                if level == "county":
                    overrides[(state_code, county_code, crop_name)] = config
                else:
                    overrides[(state_code, crop_name)] = config
        return overrides


def parse_state_county(value: str | None) -> tuple[str | None, str | None]:
    """Split values like ``MN_Brown`` into ``('MN', 'BROWN')``."""
    if value is None:
        return None, None
    if isinstance(value, (int, float)):
        if isinstance(value, float) and math.isnan(value):
            return None, None
        token = str(value)
    else:
        token = str(value)
    token = token.strip()
    if not token:
        return None, None
    parts = token.split("_", 1)
    state_part = parts[0]
    county_part = parts[1] if len(parts) > 1 else None
    return _normalize_state(state_part), _normalize_county(county_part)


def _normalize_state(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = "".join(ch for ch in str(value).strip().upper() if ch.isalpha())
    return cleaned or None


def _normalize_county(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = str(value).strip().replace("-", "_").replace(" ", "_").upper()
    return cleaned or None


def _safe_int(value: str | int | float | None) -> int:
    if value is None or value == "":
        raise ValueError("Missing numeric value in timewindow CSV")
    return int(float(value))


def _doy_to_day_month(day_of_year: int) -> tuple[int, int]:
    reference = _dt.date(2001, 1, 1) + _dt.timedelta(days=day_of_year - 1)
    return reference.day, reference.month


__all__ = ["CropCycleConfig", "CropCycleCatalog", "DEFAULT_CYCLE", "parse_state_county"]

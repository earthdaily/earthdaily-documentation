"""Parameter schemas for analytics tasks (pydantic models for validation/display)."""

from __future__ import annotations

from datetime import date
from pathlib import Path

from pydantic import BaseModel, Field


class AnalyticsParams(BaseModel):
    max_workers: int = Field(8, ge=1, description="Thread pool size")
    max_concurrency_cap: int = Field(32, ge=1, description="Upper bound on concurrent workers")
    max_qps: int = Field(0, ge=0, description="Max QPS (0 to disable throttling)")
    checkpoint_path: str | None = Field(None, description="Optional checkpoint parquet path")
    checkpoint_frequency: int = Field(0, ge=0, description="Rows to process between checkpoints (0 to disable)")
    progress: bool = Field(True, description="Enable progress bar")
    progress_desc: str = Field("", description="Progress bar label")


class CropMaskParams(AnalyticsParams):
    start_year: int = Field(2020, description="Begin year for crop history queries")
    end_year: int = Field(2024, description="End year for crop history queries")
    min_percent: int = Field(50, ge=0, le=100, description="Minimum crop mask percentage")
    limit_nb_crop: int = Field(1, ge=1, description="Maximum number of crops per year")
    products: list[str] = Field(default_factory=lambda: ["EndSeason"], description="Crop mask products to query")
    target_crop: str | None = Field(None, description="Crop code filter (None = keep all)")


class WeatherParams(AnalyticsParams):
    provider: str = Field("global1", description="Weather provider name")
    lower_threshold: float = Field(50, description="Lower threshold for GDD")
    upper_threshold: float = Field(86, description="Upper threshold for GDD")
    rainfall_context_days: int = Field(10, ge=0, description="Rolling rainfall context days")
    average_years: int = Field(5, ge=1, description="Years of history for averages")
    default_region: str = Field("Dodge", description="Fallback weather region")
    max_workers: int = Field(4, ge=1, description="Thread pool size")
    stage_whitelist: list[str] = Field(default_factory=lambda: ["tasseling", "r3", "black_layer"], description="Stages to compute")


class EmergenceParams(AnalyticsParams):
    emergence_type: str = Field("INSEASON", description="Emergence processing type")
    season_duration: int | None = Field(None, description="Season duration override (days)")
    season_start_day: int | None = Field(None, ge=1, le=31, description="Season start day")
    season_start_month: int | None = Field(None, ge=1, le=12, description="Season start month")
    year: int | None = Field(None, description="Crop/cycle year override")
    data_source: str | None = Field(None, description="Emergence data source")
    force_lri_cache: bool = Field(False, description="Force use of LRI cache")
    skip_confirmed: bool = Field(True, description="Skip rows already confirmed")
    region_column: str | None = Field("region", description="Column name for region grouping")
    default_crop: str | None = Field("CORN", description="Default crop code when missing")
    crop_cycle_csv_path: Path | None = Field(None, description="Optional path to crop_cycle.csv (otherwise from config)")


class LriParams(AnalyticsParams):
    window_days: int = Field(20, ge=1, description="Number of days in sliding window")
    end_date: date | None = Field(None, description="Window end date (defaults to today UTC)")
    indicator: str = Field("ndvi", description="Indicator to request")
    smoother: str = Field("WEIGHTED_WHITTAKER", description="Smoother parameter for LRI")
    is_coverage_extended: bool = Field(False, description="LRI coverage flag")
    use_pixel_cold_db: bool = Field(True, description="Use pixel cold DB")
    geometry_wkt_param: bool = Field(False, description="Use geometryWkt param")
    years_column: str = Field("crop_history_years", description="Column with years list")
    history_column: str = Field("crop_history", description="Column with crop history")
    batch_size: int = Field(25, ge=1, description="Geometries per batch request")


__all__ = [
    "CropMaskParams",
    "WeatherParams",
    "EmergenceParams",
    "LriParams",
    "InseasonPotentialScoreParams",
    "GreennessDetectionParams",
]


class InseasonPotentialScoreParams(AnalyticsParams):
    """Scaffolded params (extend as needed)."""

    id: str | None = None
    geometry: str | None = None
    historicalSeasons: str | None = None
    seasonDuration: int | None = None
    seasonStartDay: int | None = None
    seasonStartMonth: int | None = None
    sowingDate: str | None = None
    numberHistoricalYears: int | None = None
    threshold: float | None = None
    dataSource: str | None = None
    endDate: str | None = None
    crop: str | None = None


class GreennessDetectionParams(AnalyticsParams):
    """Scaffolded params (extend as needed)."""

    id: str | None = None
    geometry: str | None = None
    seasonDuration: int | None = None
    seasonStartDay: int | None = None
    seasonStartMonth: int | None = None
    year: int | None = None
    sowingDate: str | None = None
    crop: str | None = None
    dataSource: str | None = None

"""Lightweight run reporting helpers for analytics notebooks."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class TaskRun:
    binding_key: str
    task_name: str
    params: dict[str, Any]
    field_mapping: dict[str, Any]
    defaults: dict[str, Any]
    stats: dict[str, Any]
    input_rows: int
    output_rows: int
    added_columns: list[str] = field(default_factory=list)
    input_rules: list[dict[str, Any]] = field(default_factory=list)
    started_at: datetime | None = None
    finished_at: datetime | None = None
    notes: str | None = None


class AnalyticsRunReporter:
    """Capture per-task stats and render an HTML/markdown report."""

    def __init__(
        self,
        *,
        enabled: bool = True,
        html_path: str | None = None,
        pdf_path: str | None = None,
        include_map: bool = False,
        map_geometry_column: str = "geometry",
        map_max_features: int = 500,
        map_simplify_tolerance: float | None = None,
        pdf_base_url: str | None = None,
        dedupe_by_binding: bool = True,
        map_zoom_bias: float = 0.1,
    ) -> None:
        self.enabled = enabled
        self.html_path = html_path
        self.pdf_path = pdf_path
        self.include_map = include_map
        self.map_geometry_column = map_geometry_column
        self.map_max_features = map_max_features
        self.map_simplify_tolerance = map_simplify_tolerance
        self.pdf_base_url = pdf_base_url
        self.dedupe_by_binding = dedupe_by_binding
        self.map_zoom_bias = max(0.0, min(map_zoom_bias, 0.45))  # tighten bounds a bit without clipping
        self.run_context: dict[str, Any] = {}
        self.task_runs: list[TaskRun] = []
        self.dataset_snapshot: pd.DataFrame | None = None
        self.map_data: pd.DataFrame | None = None

    def set_run_context(
        self,
        *,
        group_id: str | None = None,
        parquet_version: str | None = None,
        manifest: dict[str, Any] | None = None,
        parquet_path: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        if not self.enabled:
            return
        self.run_context = {
            "group_id": group_id,
            "parquet_version": parquet_version,
            "parquet_path": parquet_path,
            "manifest": manifest or {},
            "timestamp": datetime.utcnow().isoformat() + "Z",
        }
        if extra:
            self.run_context.update(extra)

    def capture_dataset(self, df: pd.DataFrame, *, sample_rows: int = 50, use_for_map: bool = True) -> None:
        if not self.enabled or df is None:
            return
        try:
            self.dataset_snapshot = df.head(sample_rows).copy()
            if use_for_map:
                self.map_data = df
        except Exception as exc:
            logger.warning("Reporter failed to capture dataset snapshot: %s", exc)

    def add_task_run(
        self,
        *,
        binding_key: str,
        task_name: str,
        params: dict[str, Any],
        field_mapping: dict[str, Any],
        defaults: dict[str, Any],
        stats: dict[str, Any],
        input_rows: int,
        output_rows: int,
        added_columns: list[str] | None = None,
        input_rules: list[dict[str, Any]] | None = None,
        started_at: datetime | None = None,
        finished_at: datetime | None = None,
        notes: str | None = None,
    ) -> None:
        if not self.enabled:
            return
        if self.dedupe_by_binding:
            self.task_runs = [t for t in self.task_runs if t.binding_key != binding_key]
        record = TaskRun(
            binding_key=binding_key,
            task_name=task_name,
            params=dict(params or {}),
            field_mapping=dict(field_mapping or {}),
            defaults=dict(defaults or {}),
            stats=dict(stats or {}),
            input_rows=int(input_rows),
            output_rows=int(output_rows),
            added_columns=sorted(set(added_columns or [])),
            input_rules=list(input_rules or []),
            started_at=started_at,
            finished_at=finished_at,
            notes=notes,
        )
        self.task_runs.append(record)

    def _render_task_html(self, task: TaskRun) -> str:
        stats = task.stats or {}
        duration = stats.get("duration_seconds")
        errors = [err for err in (stats.get("errors_sample") or []) if err]
        filtered_out = stats.get("filtered_out")
        meta = stats.get("meta") or {}
        parts: list[str] = []
        parts.append("<div class='task-card'>")
        parts.append(
            f"<div class='task-header'><div><div class='task-key'>{task.binding_key}</div>"
            f"<div class='task-name'>{task.task_name}</div></div>"
        )
        if duration is not None:
            parts.append(f"<div class='pill pill-time'>⏱ {duration:.2f}s</div>")
        parts.append("</div>")  # header
        parts.append("<div class='task-body'>")
        parts.append("<ul class='kv'>")
        parts.append(f"<li><span>Input rows</span><strong>{task.input_rows}</strong></li>")
        parts.append(f"<li><span>Output rows</span><strong>{task.output_rows}</strong></li>")
        if filtered_out is not None:
            parts.append(f"<li><span>Skipped/filtered</span><strong>{filtered_out}</strong></li>")
        if stats.get("success") is not None:
            parts.append(f"<li><span>Success</span><strong>{stats.get('success')}</strong></li>")
        if stats.get("failed") is not None:
            parts.append(f"<li><span>Failed</span><strong>{stats.get('failed')}</strong></li>")
        if stats.get("api_calls") is not None:
            parts.append(f"<li><span>API calls</span><strong>{stats.get('api_calls')}</strong></li>")
        if stats.get("cache_hits") is not None:
            parts.append(f"<li><span>Cache hits</span><strong>{stats.get('cache_hits')}</strong></li>")
        parts.append("</ul>")
        if task.added_columns:
            parts.append("<details class='details-block'><summary>Added columns</summary>")
            parts.append("<div class='chips'>")
            for col in task.added_columns:
                parts.append(f"<span class='chip'>{col}</span>")
            parts.append("</div></details>")
        if meta:
            meta_json = json.dumps(meta, indent=2, default=str)
            parts.append("<details class='details-block'><summary>Extra metadata</summary>")
            parts.append(f"<pre>{meta_json}</pre></details>")
        if task.input_rules:
            parts.append("<details class='details-block'><summary>Input rules</summary><pre>")
            parts.append(json.dumps(task.input_rules, indent=2, default=str))
            parts.append("</pre></details>")
        if errors:
            parts.append("<div class='errors'><div class='errors-title'>Errors sample</div>")
            parts.append("<ul>")
            for err in errors:
                parts.append(f"<li>{err}</li>")
            parts.append("</ul></div>")
        parts.append("<details class='params'><summary>Parameters</summary>")
        params_json = json.dumps(task.params, indent=2, default=str)
        mapping_json = json.dumps(task.field_mapping, indent=2, default=str)
        defaults_json = json.dumps(task.defaults, indent=2, default=str)
        parts.append(f"<pre><strong>task_params</strong> = {params_json}</pre>")
        parts.append(f"<pre><strong>field_mapping</strong> = {mapping_json}</pre>")
        parts.append(f"<pre><strong>defaults</strong> = {defaults_json}</pre>")
        parts.append("</details>")
        if task.notes:
            parts.append(f"<div class='note'>{task.notes}</div>")
        parts.append("</div></div>")  # body + card
        return "\n".join(parts)

    def _build_map_html(self) -> str | None:
        if not self.include_map or self.map_data is None:
            # Try bbox-only render if available in context.
            manifest = self.run_context.get("manifest", {}) if isinstance(self.run_context, dict) else {}
            bbox = manifest.get("stats", {}).get("bbox") if isinstance(manifest, dict) else None
            if bbox and len(bbox) == 4:
                try:
                    import folium  # type: ignore
                except Exception:
                    return None
                minx, miny, maxx, maxy = bbox
                center = [(miny + maxy) / 2, (minx + maxx) / 2]
                fmap = folium.Map(location=center, zoom_start=8, tiles="OpenStreetMap")
                fmap.fit_bounds([[miny, minx], [maxy, maxx]])
                folium.Rectangle(bounds=[[miny, minx], [maxy, maxx]], color="#2563eb", fill=False).add_to(fmap)
                return fmap._repr_html_()
            return None
        try:
            import folium  # type: ignore
            from shapely import wkb, wkt  # type: ignore
        except Exception as exc:  # pragma: no cover - optional
            logger.info("Reporter map skipped (folium/shapely unavailable): %s", exc)
            return None
        try:
            manifest = self.run_context.get("manifest", {}) if isinstance(self.run_context, dict) else {}
            bbox_ctx = manifest.get("stats", {}).get("bbox") if isinstance(manifest, dict) else None
            df = self.map_data
            if self.map_geometry_column not in df.columns:
                if bbox_ctx and len(bbox_ctx) == 4:
                    minx, miny, maxx, maxy = bbox_ctx
                    center = [(miny + maxy) / 2, (minx + maxx) / 2]
                    fmap = folium.Map(location=center, zoom_start=8, tiles="OpenStreetMap")
                    fmap.fit_bounds([[miny, minx], [maxy, maxx]])
                    folium.Rectangle(bounds=[[miny, minx], [maxy, maxx]], color="#2563eb", fill=False).add_to(fmap)
                    return fmap._repr_html_()
                return None
            series = df[self.map_geometry_column].dropna().head(self.map_max_features)
            if series.empty:
                if bbox_ctx and len(bbox_ctx) == 4:
                    minx, miny, maxx, maxy = bbox_ctx
                    center = [(miny + maxy) / 2, (minx + maxx) / 2]
                    fmap = folium.Map(location=center, zoom_start=8, tiles="OpenStreetMap")
                    fmap.fit_bounds([[miny, minx], [maxy, maxx]])
                    folium.Rectangle(bounds=[[miny, minx], [maxy, maxx]], color="#2563eb", fill=False).add_to(fmap)
                    return fmap._repr_html_()
                return None
            geometries = []
            for val in series:
                try:
                    if isinstance(val, (bytes, bytearray)):
                        geom = wkb.loads(val)
                    else:
                        geom = wkt.loads(str(val))
                    geometries.append(geom)
                except Exception:
                    continue
            bounds: list[float] | None = None
            if geometries:
                xs = [g.bounds[0] for g in geometries] + [g.bounds[2] for g in geometries]
                ys = [g.bounds[1] for g in geometries] + [g.bounds[3] for g in geometries]
                minx, maxx = min(xs), max(xs)
                miny, maxy = min(ys), max(ys)
                pad_x = (maxx - minx) * self.map_zoom_bias
                pad_y = (maxy - miny) * self.map_zoom_bias
                bounds = [minx + pad_x, miny + pad_y, maxx - pad_x, maxy - pad_y]
            elif bbox_ctx and len(bbox_ctx) == 4:
                bx0, by0, bx1, by1 = bbox_ctx
                pad_x = (bx1 - bx0) * self.map_zoom_bias
                pad_y = (by1 - by0) * self.map_zoom_bias
                bounds = [bx0 + pad_x, by0 + pad_y, bx1 - pad_x, by1 - pad_y]
            if not geometries and not bounds:
                return None
            # Center map on bounds (geom or bbox), fallback to first centroid.
            if bounds and len(bounds) == 4:
                minx, miny, maxx, maxy = bounds
                center = [(miny + maxy) / 2, (minx + maxx) / 2]
            else:
                centroid = geometries[0].centroid
                center = [centroid.y, centroid.x]
            fmap = folium.Map(location=center, zoom_start=8, tiles="OpenStreetMap")
            if bounds and len(bounds) == 4:
                minx, miny, maxx, maxy = bounds
                fmap.fit_bounds([[miny, minx], [maxy, maxx]])
            for geom in geometries:
                try:
                    geojson = geom.__geo_interface__
                    if self.map_simplify_tolerance:
                        geojson = geom.simplify(self.map_simplify_tolerance, preserve_topology=True).__geo_interface__
                    folium.GeoJson(geojson).add_to(fmap)
                except Exception:
                    continue
            return fmap._repr_html_()
        except Exception as exc:  # pragma: no cover - best effort
            logger.warning("Reporter map generation failed: %s", exc)
            return None

    def render_summary_markdown(self) -> str:
        if not self.enabled:
            return "Reporter disabled."
        lines: list[str] = []
        ctx = self.run_context or {}
        group_id = ctx.get("group_id") or "<unknown>"
        lines.append(f"**Group:** `{group_id}`")
        for task in self.task_runs:
            stats = task.stats or {}
            duration = stats.get("duration_seconds")
            cache_hits = stats.get("cache_hits")
            desc = (
                f"- `{task.binding_key}` ({task.task_name}): "
                f"{stats.get('success', 0)} ok / {stats.get('failed', 0)} failed, "
                f"filtered={stats.get('filtered_out', 0)}, rows={task.output_rows}"
            )
            if cache_hits is not None:
                desc += f", cache_hits={cache_hits}"
            if duration is not None:
                desc += f", {duration:.2f}s"
            lines.append(desc)
        return "\n".join(lines)

    def render_html(self) -> str:
        if not self.enabled:
            return "<p>Reporter disabled.</p>"
        ctx = self.run_context or {}
        manifest = ctx.get("manifest") or {}
        schema = manifest.get("schema") or []
        row_count = manifest.get("row_count") or ""
        parquet_path = ctx.get("parquet_path") or ""
        style = """
        <style>
        .report {font-family: 'Inter', 'Helvetica Neue', Arial, sans-serif; color:#0f172a; background:#f8fafc; padding:18px;}
        .container {max-width:1200px; margin:0 auto;}
        .hero {background:linear-gradient(135deg, #e0f2fe, #d1fae5); color:#0f172a; border-radius:16px; padding:14px 16px; box-shadow:0 12px 28px rgba(15,23,42,0.08); margin-bottom:16px;}
        .hero h2 {margin:0 0 6px 0; font-size:22px; color:#0b1727;}
        .hero-meta {display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:10px;}
        .meta-card {background:#fff; border-radius:12px; padding:10px 12px; border:1px solid rgba(255,255,255,0.4); box-shadow:0 8px 20px rgba(15,23,42,0.06);}
        .meta-card .label {color:#475569; font-size:12px; text-transform:uppercase; letter-spacing:0.05em;}
        .meta-card .value {font-weight:700; font-size:13px; color:#0f172a; word-break:break-all;}
        .pill {background:#e2e8f0; padding:4px 8px; border-radius:12px; font-size:12px; color:#1e293b;}
        .pill-time {background:#0ea5e9; color:#0b1727;}
        .task-grid {display:grid; grid-template-columns:repeat(auto-fit,minmax(340px,1fr)); gap:12px;}
        .task-card, .map-card {border:1px solid #e2e8f0; border-radius:14px; padding:12px; background:#fff; box-shadow:0 8px 20px rgba(15,23,42,0.05);}
        .task-header {display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:10px;}
        .task-key {font-weight:700; font-size:12px; color:#475569; text-transform:uppercase; letter-spacing:0.05em;}
        .task-name {font-weight:700; font-size:16px;}
        .task-body {font-size:13px; color:#0f172a;}
        .kv {list-style:none; padding:0; margin:0 0 10px 0; display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:6px 12px;}
        .kv li {display:flex; justify-content:space-between; border-bottom:1px dashed #e2e8f0; padding:4px 0;}
        .kv span {color:#64748b;}
        .details-block summary {cursor:pointer; color:#2563eb; font-weight:600;}
        pre {background:#f8fafc; padding:8px; border-radius:8px; overflow:auto;}
        .errors {margin-top:8px; color:#b91c1c;}
        .errors-title {font-weight:700; margin-bottom:4px;}
        .note {margin-top:6px; font-style:italic; color:#0f172a;}
        .map-card {max-width:900px; margin:0 auto 16px auto;}
        .chips {display:flex; flex-wrap:wrap; gap:6px;}
        .chip {background:#e2e8f0; border-radius:10px; padding:4px 8px; font-size:12px; color:#334155;}
        </style>
        """
        parts: list[str] = [style, "<div class='report'><div class='container'>"]
        parts.append("<div class='hero'>")
        parts.append("<h2>Analytics Run Report</h2>")
        parts.append("<div class='hero-meta'>")
        parts.append(f"<div class='meta-card'><div class='label'>Group</div><div class='value'>{ctx.get('group_id', '<unknown>')}</div></div>")
        parts.append(f"<div class='meta-card'><div class='label'>Parquet version</div><div class='value'>{ctx.get('parquet_version', '<unknown>')}</div></div>")
        parts.append(f"<div class='meta-card'><div class='label'>Rows (manifest)</div><div class='value'>{row_count or 'n/a'}</div></div>")
        if parquet_path:
            parts.append(f"<div class='meta-card'><div class='label'>Parquet path</div><div class='value'>{parquet_path}</div></div>")
        ts = ctx.get("timestamp")
        if ts:
            parts.append(f"<div class='meta-card'><div class='label'>Generated at (UTC)</div><div class='value'>{ts}</div></div>")
        parts.append("</div>")  # hero-meta
        if schema:
            parts.append("<details><summary>Manifest schema (pre-run)</summary><pre>")
            parts.append(json.dumps(schema, indent=2))
            parts.append("</pre></details>")
        parts.append("</div>")  # hero

        if self.include_map:
            map_html = self._build_map_html()
            if map_html:
                parts.append("<div class='map-card'>")
                parts.append(map_html)
                parts.append("</div>")
        parts.append("<div class='task-grid'>")
        for task in self.task_runs:
            parts.append(self._render_task_html(task))
        parts.append("</div>")  # task-grid
        parts.append("</div></div>")  # container + report
        html_out = "\n".join(parts)
        if self.html_path:
            try:
                path = Path(self.html_path)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(html_out, encoding="utf-8")
                logger.info("Reporter wrote HTML report to %s", path)
            except Exception as exc:
                logger.warning("Reporter failed to write HTML report: %s", exc)
        # Auto-generate PDF if requested.
        if self.pdf_path:
            try:
                self.render_pdf(html_out)
            except Exception:
                logger.warning("Reporter failed to render PDF", exc_info=True)
        return html_out

    def render_pdf(self, html: str | None = None, *, pdf_path: str | None = None) -> str | None:
        """Render the report to PDF (requires WeasyPrint)."""
        if not self.enabled:
            return None
        target = pdf_path or self.pdf_path
        if not target:
            return None
        try:
            from weasyprint import HTML as _HTML  # type: ignore
        except Exception as exc:  # pragma: no cover - optional dep
            logger.warning("WeasyPrint is required for PDF rendering: %s", exc)
            return None
        html_str = html if html is not None else self.render_html()
        path = Path(target)
        if path.suffix.lower() != ".pdf":
            path = path.with_suffix(".pdf")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            base_url = self.pdf_base_url or (Path(self.html_path).parent.as_posix() if self.html_path else ".")
            _HTML(string=html_str, base_url=base_url).write_pdf(path)
            logger.info("Reporter wrote PDF report to %s", path)
            return str(path)
        except Exception as exc:  # pragma: no cover - best effort
            logger.warning("Reporter failed to write PDF: %s", exc)
            return None


__all__ = ["AnalyticsRunReporter", "TaskRun"]

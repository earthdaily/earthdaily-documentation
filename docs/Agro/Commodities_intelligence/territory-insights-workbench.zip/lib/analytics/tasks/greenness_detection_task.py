import hashlib
import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

import pandas as pd

from ...clients.greenness_detection_client import GreennessDetectionClient
from ...domain.crop_cycle import CropCycleCatalog
from ..base import AnalyticsTask, TaskStats


logger = logging.getLogger("analytics.greenness_detection")


def default_greenness_detection_bindings():
    """Default dataframe mapping for greenness detection."""
    mapping = {
        'id': 'id',
        'geometry': 'geometry',
        'seasonDuration': 'seasonDuration',
        'seasonStartDay': 'seasonStartDay',
        'seasonStartMonth': 'seasonStartMonth',
        'year': 'year',
        'sowingDate': 'sowingDate',
        'crop': 'crop',
        'dataSource': 'dataSource',
    }
    defaults = {'id': None, 'seasonDuration': None, 'seasonStartDay': None, 'seasonStartMonth': None, 'crop': None, 'sowingDate': None}
    return {"mapping": mapping, "defaults": defaults}


@dataclass
class GreennessDetectionTask(AnalyticsTask):
    """Call greenness detection per geometry using crop-cycle hints to fill missing params."""
    auto_context_update: ClassVar[bool] = False
    progress_desc: str = "GreennessDetection analytics"
    checkpoint_path: str | None = None
    checkpoint_frequency: int = 200
    use_internal_progress: bool = False
    max_workers: int = 8
    season_duration: int | None = None
    season_start_day: int | None = None
    season_start_month: int | None = None
    crop_cycles: CropCycleCatalog | None = None
    crop_cycle_csv_path: str | Path | None = Path("../../params/crop_cycle.csv")
    input_rules: tuple[dict, ...] = (
        {
            "column": "sowingDate",
            "coerce": "datetime",
            "min_year": 1900,
            "invalid_values": ["0001-01-01"],
            "skip_row": True,
        },
    )

    def execute(self, df: pd.DataFrame, **kwargs) -> tuple[pd.DataFrame, TaskStats]:
        if df.empty:
            return df.copy(), TaskStats(total=0, success=0, failed=0)

        checkpoint = kwargs.get("_checkpoint") or (lambda *a, **k: None)
        client = GreennessDetectionClient.from_env()
        result = df.copy()
        inputs_mapping = {
            'id': 'id',
            'geometry': 'geometry',
            'seasonDuration': 'seasonDuration',
            'seasonStartDay': 'seasonStartDay',
            'seasonStartMonth': 'seasonStartMonth',
            'year': 'year',
            'sowingDate': 'sowingDate',
            'crop': 'crop',
            'dataSource': 'dataSource',
        }
        inputs_body = {'id': 'id', 'geometry': 'geometry'}
        inputs_query = {
            'seasonDuration': 'seasonDuration',
            'seasonStartDay': 'seasonStartDay',
            'seasonStartMonth': 'seasonStartMonth',
            'year': 'year',
            'sowingDate': 'sowingDate',
            'crop': 'crop',
            'dataSource': 'dataSource',
        }
        errors_sample: list[str] = []
        success = 0
        failed = 0
        api_calls = 0
        cache_hits = 0
        _orig = kwargs.get('_original_df')
        if isinstance(_orig, pd.DataFrame) and 'greenness_detection_signature' in _orig.columns:
            result['greenness_detection_signature'] = _orig['greenness_detection_signature'].values
        logger.info(
            "Greenness detection task start rows=%s max_workers=%s season_defaults=%s/%s/%s",
            len(result),
            self.max_workers,
            self.season_duration,
            self.season_start_day,
            self.season_start_month,
        )
        for _col in ['id', 'greenness_detection_results', 'greenness_detection_error', 'greenness_detection_call_inputs']:
            if _col not in result.columns:
                result[_col] = pd.NA
        task_prefix = "greenness_detection."
        orig = kwargs.get('_original_df')
        prefix_cols_orig = [c for c in getattr(orig, 'columns', []) if c.startswith(task_prefix)]
        for col in prefix_cols_orig:
            if col not in result.columns:
                result[col] = pd.NA
        override_cols = [c for c in result.columns if c.startswith(task_prefix)]
        override_cols.extend([
            "greenness_detection_call_inputs",
            "greenness_detection_error",
            "greenness_detection_results",
            "greenness_detection_signature",
        ])
        self._override_base_columns_runtime = set(override_cols)
        catalog = self.crop_cycles or CropCycleCatalog.from_csv(self.crop_cycle_csv_path or Path('../../params/crop_cycle.csv'))

        def _process(idx: int, row: pd.Series):
            signature = None
            geom_val = row.get('geometry')
            geom_normalized = None
            if geom_val is not None:
                try:
                    geom_normalized = geom_val.wkt if hasattr(geom_val, 'wkt') else str(geom_val)
                except Exception:
                    geom_normalized = str(geom_val)
            payload = {k: row.get(v) for k, v in inputs_body.items()}
            if 'id' in payload:
                payload['id'] = ""
            query_params = {k: row.get(v) for k, v in inputs_query.items()}
            crop_value = query_params.get('crop') or row.get('crop') or row.get('crop_code') or row.get('crop_type')
            cycle = catalog.get(crop_value)
            if query_params.get('seasonDuration') is None:
                query_params['seasonDuration'] = self.season_duration or (cycle.season_duration if cycle else None)
            if query_params.get('seasonStartDay') is None:
                query_params['seasonStartDay'] = self.season_start_day or (cycle.season_start_day if cycle else None)
            if query_params.get('seasonStartMonth') is None:
                query_params['seasonStartMonth'] = self.season_start_month or (cycle.season_start_month if cycle else None)
            sowing_date_val = query_params.get('sowingDate')
            # Normalize sowing date to YYYY-MM-DD if it's a date/datetime-like object.
            if sowing_date_val is not None:
                try:
                    if hasattr(sowing_date_val, 'date'):
                        sowing_date_val = sowing_date_val.date()
                    if hasattr(sowing_date_val, 'isoformat'):
                        sowing_date_val = sowing_date_val.isoformat()
                except Exception:
                    pass
            if sowing_date_val is not None:
                query_params['sowingDate'] = sowing_date_val
            if geom_normalized is not None and 'geometry' in payload:
                payload['geometry'] = geom_normalized
            call_inputs = {"body": payload, "query": query_params}
            signature_payload = {k: row.get(v) for k, v in inputs_mapping.items()}
            if geom_normalized is not None:
                signature_payload['geometry'] = geom_normalized
            if geom_normalized is not None:
                signature_payload['geometry_hash'] = hashlib.sha256(str(geom_normalized).encode('utf-8')).hexdigest()
            signature = hashlib.sha256(json.dumps(signature_payload, sort_keys=True, default=str).encode('utf-8')).hexdigest()
            signature_column = 'greenness_detection_signature'
            if signature_column in result.columns and result.at[idx, signature_column] == signature:
                return ('skip', idx, None, signature, None, call_inputs)
            try:
                response = client.call(payload, query=query_params)
                return ("ok", idx, response, signature, None, call_inputs)
            except Exception as exc:
                err_msg = str(exc)
                resp = getattr(exc, "response", None)
                if resp is not None:
                    try:
                        body_text = resp.text
                    except Exception:
                        body_text = None
                    if body_text:
                        err_msg = f"status={getattr(resp, 'status_code', '?')} body={body_text}"
                return ("error", idx, None, signature, err_msg, call_inputs)

        from concurrent.futures import as_completed, ThreadPoolExecutor

        workers = min(max(1, self.max_workers), len(result))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(_process, idx, row): idx for idx, row in result.iterrows()}
            for future in as_completed(future_map):
                status, idx, response, signature, err, call_inputs = future.result()
                if status == "skip":
                    cache_hits += 1
                    result.at[idx, 'greenness_detection_call_inputs'] = call_inputs
                    checkpoint(1, snapshot=result.loc[[idx]])
                    continue
                if status == "ok":
                    api_calls += 1
                    value = response.get('data') if isinstance(response, dict) else None
                    if isinstance(value, dict):
                        result.at[idx, 'greenness_detection_results'] = value
                        for _k, _v in value.items():
                            result.at[idx, f"greenness_detection.{_k}"] = _v
                    else:
                        result.at[idx, 'greenness_detection_results'] = value
                    result.at[idx, "greenness_detection_signature"] = signature
                    result.at[idx, "greenness_detection_error"] = None
                    result.at[idx, 'greenness_detection_call_inputs'] = call_inputs
                    success += 1
                else:
                    failed += 1
                    result.at[idx, "greenness_detection_error"] = err
                    result.at[idx, 'greenness_detection_call_inputs'] = call_inputs
                    result.at[idx, 'greenness_detection_results'] = None
                    # Clear any flattened outputs from previous runs.
                    for _col in [c for c in result.columns if c.startswith("greenness_detection.")]:
                        result.at[idx, _col] = None
                    if err and len(errors_sample) < 5:
                        errors_sample.append(err)
                    if err:
                        logger.debug("Greenness detection row failed idx=%s error=%s", idx, err)
                checkpoint(1, snapshot=result.loc[[idx]])

        stats = TaskStats(
            total=len(df),
            success=success,
            failed=failed,
            api_calls=api_calls,
            cache_hits=cache_hits,
            errors_sample=errors_sample,
        )
        logger.info(
            "Greenness detection task done rows=%s success=%s failed=%s api_calls=%s cache_hits=%s",
            len(df),
            success,
            failed,
            api_calls,
            cache_hits,
        )
        return result, stats

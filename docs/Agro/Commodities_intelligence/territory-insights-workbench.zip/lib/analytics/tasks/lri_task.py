"""LRI NDVI accumulation task aligned with scaffolder-style orchestration."""

from __future__ import annotations

import logging
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import date, datetime, timedelta, UTC
from typing import Any, ClassVar

import pandas as pd

from ...clients.lri import LriClient
from ...utils.geometry import to_wkt
from ..base import AnalyticsTask, TaskStats


logger = logging.getLogger("analytics.lri")


def _today_date() -> date:
    """Return today's date in UTC."""
    return datetime.now(UTC).date()


def _parse_years(src: Any) -> list[int]:
    """Normalize various representations of years into a sorted int list."""
    if src is None:
        return []
    if isinstance(src, str):
        parts = [p.strip() for p in src.split("-") if p.strip()]
        years = []
        for p in parts:
            try:
                years.append(int(p))
            except Exception:
                continue
        return sorted(set(years))
    if isinstance(src, Iterable):
        years = []
        for item in src:
            if isinstance(item, Mapping) and "year" in item:
                try:
                    years.append(int(item["year"]))
                except Exception:
                    continue
            elif isinstance(item, int):
                years.append(item)
        return sorted(set(years))
    return []


def _accumulate_ndvi(rows: list[dict[str, Any]], years: Iterable[int], end_date_template: date, window_days: int) -> list[dict[str, Any]]:
    """Aggregate NDVI per year over a sliding window ending at the template date."""
    by_year: dict[int, list[dict[str, Any]]] = {y: [] for y in years}
    for row in rows:
        try:
            d = datetime.strptime(row.get("date"), "%Y-%m-%d").date()
        except Exception:
            continue
        if d.year in by_year:
            by_year[d.year].append(row)

    results: list[dict[str, Any]] = []
    delta = timedelta(days=max(1, window_days) - 1)
    for y in sorted(by_year):
        end_d = date(y, end_date_template.month, end_date_template.day)
        start_d = end_d - delta
        window_sum = 0.0
        for row in by_year[y]:
            try:
                d = datetime.strptime(row.get("date"), "%Y-%m-%d").date()
            except Exception:
                continue
            if start_d <= d <= end_d:
                try:
                    val = float(row.get("ndvi"))
                except Exception:
                    continue
                window_sum += val
        results.append(
            {
                "start_date": start_d.isoformat(),
                "end_date": end_d.isoformat(),
                "accumulated": window_sum,
            }
        )
    return results


@dataclass
class LriNdviTask(AnalyticsTask):
    """Warm up or fetch NDVI metrics from LRI for each geometry."""
    """
    Fetch NDVI time series from LRI and compute per-year accumulations over a sliding window.

    Usage: pass `window_days` and optionally `end_date` (defaults to today UTC).
    Years are inferred from `crop_history_years` (hyphen-separated string) or a
    list of dicts in `crop_history` (looking for a `year` field).
    """

    auto_context_update: ClassVar[bool] = False
    window_days: int = 20
    end_date: date | None = None
    max_workers: int = 16
    max_qps: int = 0
    max_concurrency_cap: int = 32
    indicator: str = "ndvi"
    smoother: str = "WEIGHTED_WHITTAKER"
    is_coverage_extended: bool = False
    use_pixel_cold_db: bool = True
    geometry_wkt_param: bool = False
    years_column: str = "crop_history_years"
    history_column: str = "crop_history"
    batch_size: int = 25
    checkpoint_path: str | None = None
    checkpoint_frequency: int = 0
    progress: bool = True
    progress_desc: str = "LRI NDVI"

    def execute(self, df: pd.DataFrame, **kwargs: Any) -> tuple[pd.DataFrame, TaskStats]:
        if df.empty:
            return df.copy(), TaskStats(total=0, success=0, failed=0)

        client = LriClient.from_env()
        logger.info(
            "LRI task start rows=%s window_days=%s indicator=%s batch_size=%s",
            len(df),
            self.window_days,
            self.indicator,
            self.batch_size,
        )
        end_date_template = self.end_date or _today_date()

        enriched = df.reset_index(drop=True).copy()
        original_df = kwargs.get("_original_df")
        if isinstance(original_df, pd.DataFrame) and len(original_df) == len(enriched):
            for col in original_df.columns:
                if col not in enriched.columns:
                    enriched[col] = original_df[col].values
        if "lri_accumulation" not in enriched.columns:
            enriched["lri_accumulation"] = None
        if "lri_error" not in enriched.columns:
            enriched["lri_error"] = None

        entries: list[dict[str, Any]] = []
        id_to_idx: dict[Any, int] = {}
        for idx, series in enriched.iterrows():
            years = _parse_years(series.get(self.years_column)) or _parse_years(series.get(self.history_column))
            if not years:
                continue
            start = date(min(years), end_date_template.month, end_date_template.day) - timedelta(days=max(1, self.window_days) - 1)
            end = date(max(years), end_date_template.month, end_date_template.day)
            entries.append(
                {
                    "idx": idx,
                    "id": series.get("id", idx),
                    "geometry": series["geometry"],
                    "years": years,
                    "start": start,
                    "end": end,
                }
            )
            id_to_idx[entries[-1]["id"]] = idx

        if not entries:
            return enriched, TaskStats(total=len(df), success=0, failed=0)

        checkpoint = kwargs.get("_checkpoint") or (lambda *a, **k: None)

        failures: list[Any] = []
        success = 0
        api_calls = 0

        from concurrent.futures import as_completed, ThreadPoolExecutor

        chunk_size = max(1, self.batch_size)
        chunks = [entries[i : i + chunk_size] for i in range(0, len(entries), chunk_size)]
        chunk_workers = min(len(chunks), max(1, self.max_workers), self.max_concurrency_cap)

        def _process_chunk(chunk: list[dict[str, Any]]):
            chunk_start = min(item["start"] for item in chunk)
            chunk_end = max(item["end"] for item in chunk)
            payload_dicts = []
            id_index_map: dict[int, str | Any] = {}
            for idx_local, item in enumerate(chunk):
                payload_dicts.append({"identifier": idx_local, "wkt": to_wkt(item["geometry"])})
                id_index_map[idx_local] = item["id"]

            if kwargs.get("trace", False):
                try:
                    preview = [
                        {
                            "identifier": d["identifier"],
                            "wkt": (d["wkt"][:120] + "...") if isinstance(d.get("wkt"), str) and len(d["wkt"]) > 120 else d.get("wkt"),
                        }
                        for d in payload_dicts
                    ]
                    logger.debug("[LRI-task] batch payload preview (int identifiers): %s", preview)
                except Exception:
                    logger.debug("[LRI-task] unable to preview payload wkt strings")

            api_calls_local = 0
            results: list[tuple[int, list[dict[str, Any]], list[int]]] = []
            failures_local: list[Any] = []

            try:
                resp = client.fetch_ndvi_batch(
                    payload_dicts,
                    start_date=chunk_start,
                    end_date=chunk_end,
                    indicator=self.indicator,
                    smoother=self.smoother,
                    is_coverage_extended=self.is_coverage_extended,
                    use_pixel_cold_db=self.use_pixel_cold_db,
                    geometry_wkt_param=self.geometry_wkt_param,
                    trace=kwargs.get("trace", False),
                )
                api_calls_local += 1
                for idx_local, item in enumerate(chunk):
                    rows = resp.get(idx_local, [])
                    results.append((item["idx"], rows, item["years"]))
            except Exception as exc:
                logger.warning("LRI NDVI batch failed for %s items: %s", len(chunk), exc)
                logger.warning("payload identifiers=%s", [item["id"] for item in chunk])

                for item in chunk:
                    try:
                        single_rows = client.fetch_ndvi(
                            item["geometry"],
                            start_date=item["start"],
                            end_date=item["end"],
                            indicator=self.indicator,
                            smoother=self.smoother,
                            is_coverage_extended=self.is_coverage_extended,
                            use_pixel_cold_db=self.use_pixel_cold_db,
                            geometry_wkt_param=self.geometry_wkt_param,
                            trace=kwargs.get("trace", False),
                        )
                        api_calls_local += 1
                        results.append((item["idx"], single_rows, item["years"]))
                    except Exception as exc_single:
                        failures_local.append(item["id"])
                        logger.debug("LRI NDVI single failed for %s: %s", item["id"], exc_single)

            return results, failures_local, api_calls_local

        with ThreadPoolExecutor(max_workers=chunk_workers) as executor:
            future_map = {executor.submit(_process_chunk, chunk): chunk for chunk in chunks}
            for future in as_completed(future_map):
                try:
                    results, failed_ids, api_calls_chunk = future.result()
                except Exception as exc_future:
                    logger.warning("LRI NDVI chunk execution failed: %s", exc_future)
                    failures.append("chunk_execution")
                    continue

                api_calls += api_calls_chunk
                failures.extend(failed_ids)

                for idx_row, rows, years in results:
                    accum = _accumulate_ndvi(rows, years=years, end_date_template=end_date_template, window_days=self.window_days)
                    enriched.at[idx_row, "lri_accumulation"] = accum
                    enriched.at[idx_row, "lri_error"] = None
                    success += 1

                if failed_ids:
                    for fid in failed_ids:
                        idx_fail = id_to_idx.get(fid)
                        if idx_fail is None:
                            continue
                        enriched.at[idx_fail, "lri_accumulation"] = None
                        enriched.at[idx_fail, "lri_error"] = "fetch_failed"

                processed = len(results) + len(failed_ids)
                if processed:
                    snapshot_rows = enriched.loc[[r[0] for r in results]] if results else None
                    checkpoint(processed, snapshot=snapshot_rows)

        stats = TaskStats(
            total=len(df),
            success=success,
            failed=len(failures),
            api_calls=api_calls,
            cache_hits=0,
            errors_sample=[str(failures[:3]) if failures else ""],
            kept=success,
            filtered_out=0,
        )

        logger.info(
            "LRI task done rows=%s success=%s failed=%s api_calls=%s",
            len(df),
            success,
            len(failures),
            api_calls,
        )
        return enriched, stats


def default_lri_bindings() -> Mapping[str, Any]:
    """Default dataframe mapping for LRI NDVI enrichment."""
    mapping = {
        "id": "spatial_unit_id",
        "geometry": "geometry",
        "crop_history_years": "crop_history_years",
        "crop_history": "crop_history",
    }
    defaults: Mapping[str, Any] = {}
    return {"mapping": mapping, "defaults": defaults}


__all__ = ["LriNdviTask", "default_lri_bindings"]

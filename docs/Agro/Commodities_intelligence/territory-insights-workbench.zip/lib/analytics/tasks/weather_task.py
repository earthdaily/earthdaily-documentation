"""Weather analytics task aligned with scaffolder-style orchestration."""

from __future__ import annotations

import logging
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, ClassVar

import pandas as pd

from ...clients.weather import (
    _geometry_to_point_wkt,  # type: ignore
    assign_weather_regions,
    derive_planting_dates,
    get_stage_offsets_for_region,
    WeatherApiClient,
)
from ..base import AnalyticsTask, TaskStats


logger = logging.getLogger("analytics.weather")

NUMERIC_METRIC_COLUMNS = {
    "gdd_to_date",
    "rainfall_to_date",
    "historical_rainfall",
    "historical_gdd",
}


@dataclass
class WeatherTask(AnalyticsTask):
    """Compute weather metrics per parcel using geohash/planting date context."""
    # Uses explicit context updates; let base provide context but skip auto-update.
    auto_context_update: ClassVar[bool] = False
    # Keep derived planting_date in outputs even if missing from input.
    preserve_base_columns: ClassVar[set[str]] = {"planting_date"}
    provider: str = "global1"
    lower_threshold: float = 50
    upper_threshold: float = 86
    rainfall_context_days: int = 10
    average_years: int = 5
    default_region: str = "Dodge"
    max_workers: int | None = None
    stage_whitelist: tuple[str, ...] = ("tasseling", "r3", "black_layer")
    input_rules: tuple[dict[str, Any], ...] = (
        {
            "column": "emergence_date",
            "coerce": "datetime",
            "min_year": 1900,
            "invalid_values": ["0001-01-01"],
            "skip_row": True,
        },
        {
            "column": "emergence_status",
            "invalid_values": ["no_emergence", "false"],
            "skip_row": True,
            "clear_value": False,
        },
        {
            "column": "emergence_confirmation_status",
            "invalid_values": ["false", "no_emergence"],
            "skip_row": True,
            "clear_value": False,
        },
        {
            "column": "planting_date",
            "coerce": "datetime",
            "min_year": 1900,
            "invalid_values": ["0001-01-01"],
            "skip_row": True,
        },
    )
    checkpoint_path: str | None = None
    checkpoint_frequency: int = 0
    progress: bool = True
    progress_desc: str = "Weather"

    def execute(self, df: pd.DataFrame, **kwargs: Any) -> tuple[pd.DataFrame, TaskStats]:
        """
        Execute weather analytics on a normalized dataframe containing:
        - planting_date
        - geohash
        - centroid_wkt
        - (optional) weather_region
        - (optional) emergence_date (to backfill planting_date)
        """
        if df.empty:
            return df.copy(), TaskStats(total=0, success=0, failed=0)

        work = df.copy()
        logger.info(
            "Weather task start rows=%s provider=%s rainfall_context_days=%s",
            len(work),
            self.provider,
            self.rainfall_context_days,
        )

        # Region resolution (fallback to default region)
        if "weather_region" not in work.columns:
            work["weather_region"] = self.default_region
        work["weather_region"] = assign_weather_regions(
            work,
            label_column="weather_region",
            default_region=self.default_region,
        )

        # Derive planting date from emergence; keep it in sync on every run when emergence_date is present.
        if "planting_date" not in work.columns:
            work["planting_date"] = pd.NaT
        if "emergence_date" in work.columns:
            derived = derive_planting_dates(
                work,
                planting_column="planting_date",
                emergence_column="emergence_date",
                region_column="weather_region",
                default_region=self.default_region,
                override_existing=True,
            )
            work["planting_date"] = derived
        stage_prefixes = tuple(f"{stage.lower()}_" for stage in self.stage_whitelist)
        # If planting_date is still missing (e.g., emergence absent), clear prior outputs now.
        planting_missing = work["planting_date"].isna()
        if "weather_error" not in work.columns:
            work["weather_error"] = pd.NA
        if planting_missing.any():
            metric_columns = [
                "gdd_to_date",
                "rainfall_to_date",
                "historical_rainfall",
                "historical_gdd",
                f"rainfall_last_{self.rainfall_context_days}",
                f"rainfall_next_{self.rainfall_context_days}",
            ]
            stage_cols_existing = [c for c in work.columns if c.endswith("_date") and c.startswith(stage_prefixes)]
            # Ensure columns exist so they can be overridden on merge.
            for col in metric_columns:
                if col not in work.columns:
                    work[col] = pd.NA
                work.loc[planting_missing, col] = pd.NA
            stage_overrides = stage_cols_existing
            if not stage_overrides:
                # Build stage columns from whitelist to cover cases where previous run added them.
                stage_overrides = []
                for stage in (s.lower() for s in self.stage_whitelist):
                    stage_overrides.extend([f"{stage}_early_date", f"{stage}_average_date", f"{stage}_late_date"])
            for col in stage_overrides:
                if col not in work.columns:
                    work[col] = pd.NaT
                work.loc[planting_missing, col] = pd.NaT
            work.loc[planting_missing, "weather_error"] = "missing_planting_date"

        client = WeatherApiClient.from_env()
        allowed_stages = {stage.lower() for stage in self.stage_whitelist}
        base_progress_desc = kwargs.get("progress_desc", self.progress_desc)
        checkpoint = kwargs.get("_checkpoint") or (lambda *a, **k: None)

        enriched = work.copy()
        # Normalize planting_date to datetime (keeps parity avec ancien comportement)
        enriched["planting_date"] = pd.to_datetime(enriched["planting_date"], errors="coerce")

        region_counts = enriched["weather_region"].value_counts(dropna=False)
        if not region_counts.empty:
            top_regions = ", ".join(f"{region}:{count}" for region, count in region_counts.head(5).items())
            logger.info(
                "Weather task: %d rows grouped into %d regions (top entries: %s%s)",
                len(enriched),
                len(region_counts),
                top_regions,
                "..." if len(region_counts) > 5 else "",
            )

        def _stage_columns(stage_offsets: Mapping[str, Any]) -> list[str]:
            cols: list[str] = []
            for stage in stage_offsets:
                norm = stage.lower()
                cols.extend([f"{norm}_early_date", f"{norm}_average_date", f"{norm}_late_date"])
            return cols

        rainfall_last_col = f"rainfall_last_{self.rainfall_context_days}"
        rainfall_next_col = f"rainfall_next_{self.rainfall_context_days}"
        metric_columns = [
            "gdd_to_date",
            "rainfall_to_date",
            "historical_rainfall",
            "historical_gdd",
            rainfall_last_col,
            rainfall_next_col,
        ]

        def _ensure_columns(df_target: pd.DataFrame, stage_cols: list[str]) -> None:
            for col in stage_cols:
                if col not in df_target.columns:
                    df_target[col] = pd.NaT
            for col in metric_columns:
                if col not in df_target.columns:
                    df_target[col] = pd.NA

        # Force overriding of derived columns (planting_date + weather outputs) when merging back.
        stage_override_cols = [
            f"{stage}_early_date"
            for stage in (s.lower() for s in self.stage_whitelist)
        ] + [
            f"{stage}_average_date"
            for stage in (s.lower() for s in self.stage_whitelist)
        ] + [
            f"{stage}_late_date"
            for stage in (s.lower() for s in self.stage_whitelist)
        ]
        self._override_base_columns_runtime = set(metric_columns + stage_override_cols + ["planting_date", "weather_error"])

        errors_sample: list[str] = []
        api_calls = 0
        cache_hits = 0
        success_groups = 0
        failed_groups = 0
        failed_rows = 0

        # Build location per geohash
        location_by_geohash: dict[str, str] = {}
        for geohash, group in enriched.groupby("geohash"):
            if not geohash or pd.isna(geohash):
                continue
            centroid_series = group["centroid_wkt"].dropna()
            for centroid_value in centroid_series:
                try:
                    location_by_geohash[str(geohash)] = _geometry_to_point_wkt(centroid_value)
                    break
                except Exception as exc:
                    logger.warning("Invalid centroid for geohash %s: %s", geohash, exc)
            if str(geohash) not in location_by_geohash:
                logger.warning("No valid centroid for geohash %s; rows will be skipped", geohash)

        # Group by geohash + planting_date (as date) to minimize API calls
        rows_to_process = enriched[
            enriched["geohash"].notna() & enriched["planting_date"].notna() & enriched["geohash"].isin(location_by_geohash)
        ].copy()
        rows_to_process["planting_date_group"] = pd.to_datetime(rows_to_process["planting_date"], errors="coerce").dt.date
        grouped = rows_to_process.groupby(["geohash", "planting_date_group"])
        group_items: list[tuple[tuple[Any, Any], pd.Index, str]] = []
        skipped_groups = 0
        for key, subset in grouped:
            geohash, planting_date_group = key
            location = location_by_geohash.get(str(geohash))
            if not location:
                skipped_groups += 1
                continue
            group_items.append(((geohash, planting_date_group), subset.index, location))

        total_groups = len(group_items)
        total_rows = len(rows_to_process)
        ratio = (total_rows / max(1, total_groups)) if total_groups else 0
        ctx = kwargs.get("_context")
        if ctx and hasattr(ctx, "reset_total"):
            try:
                ctx.reset_total(total_rows, reset_n=True)
            except Exception:
                pass
        logger.info(
            "Weather analytics: %d rows -> %d unique (geohash, planting_date) combos (%.2fx rows/call); skipped=%d",
            total_rows,
            total_groups,
            ratio,
            skipped_groups,
        )

        metrics_cache: dict[tuple[str, Any], dict[str, Any]] = {}
        cache_lock = threading.Lock()

        def _compute_metrics(location_wkt: str, planting_date: Any, stage_offsets: Mapping[str, Any]) -> dict[str, Any]:
            planting_ts = pd.to_datetime(planting_date, errors="coerce")
            planting_dt: date = planting_ts.date()
            now = pd.Timestamp.now(tz="UTC").date()
            historical_end = now - timedelta(days=1)
            rainfall_last_start = now - timedelta(days=self.rainfall_context_days)
            forecast_start = now + timedelta(days=1)
            rainfall_next_end = now + timedelta(days=self.rainfall_context_days)
            forecast_cap = now + timedelta(days=9)
            if rainfall_next_end > forecast_cap:
                rainfall_next_end = forecast_cap
            results: dict[str, Any] = {}
            try:
                stages = client.get_stage_offsets(
                    location_wkt=location_wkt,
                    planting_date=planting_dt,
                    provider=self.provider,
                    lower_threshold=self.lower_threshold,
                    upper_threshold=self.upper_threshold,
                    stage_offsets=stage_offsets,
                )
                for stage, offsets in stage_offsets.items():
                    sorted_dates = stages.get(stage, [])
                    norm = stage.lower()
                    labels = ["early", "average", "late"]
                    for idx, label in enumerate(labels):
                        column = f"{norm}_{label}_date"
                        results[column] = pd.NaT
                        if idx < len(sorted_dates):
                            results[column] = pd.Timestamp(sorted_dates[idx])

                gdd_current = client.get_gdd_accumulation(
                    location_wkt=location_wkt,
                    provider=self.provider,
                    lower_threshold=self.lower_threshold,
                    upper_threshold=self.upper_threshold,
                    start_date=planting_dt,
                    end_date=historical_end,
                )
                results["gdd_to_date"] = gdd_current

                rainfall_to_date = client.get_rainfall_accumulation(
                    location_wkt=location_wkt,
                    provider=self.provider,
                    weather_type="HISTORICAL_DAILY",
                    start_date=planting_dt,
                    end_date=historical_end,
                )
                results["rainfall_to_date"] = rainfall_to_date

                rainfall_last = client.get_rainfall_accumulation(
                    location_wkt=location_wkt,
                    provider=self.provider,
                    weather_type="HISTORICAL_DAILY",
                    start_date=rainfall_last_start,
                    end_date=historical_end,
                )
                results[rainfall_last_col] = rainfall_last

                rainfall_next = None
                if forecast_start <= rainfall_next_end:
                    rainfall_next = client.get_rainfall_accumulation(
                        location_wkt=location_wkt,
                        provider=self.provider,
                        weather_type="FORECAST_DAILY",
                        start_date=forecast_start,
                        end_date=rainfall_next_end,
                    )
                results[rainfall_next_col] = rainfall_next

                rainfall_hist = client.get_avg_rainfall_accumulation(
                    location_wkt=location_wkt,
                    provider=self.provider,
                    start_date=planting_dt,
                    end_date=historical_end,
                    average_years=self.average_years,
                )
                results["historical_rainfall"] = rainfall_hist

                gdd_hist = client.get_avg_gdd_accumulation(
                    location_wkt=location_wkt,
                    provider=self.provider,
                    lower_threshold=self.lower_threshold,
                    upper_threshold=self.upper_threshold,
                    start_date=planting_dt,
                    end_date=historical_end,
                    average_years=self.average_years,
                )
                results["historical_gdd"] = gdd_hist
            except Exception:
                raise
            return results

        def process_group(item: tuple[tuple[Any, Any], pd.Index, str]):
            (geohash, planting_date), indices, location = item
            planting_date = pd.to_datetime(planting_date, errors="coerce")
            cache_key = (str(geohash), planting_date)
            with cache_lock:
                cached = metrics_cache.get(cache_key)
                if cached is not None:
                    return indices, cached, True, None
            region = enriched.loc[indices[0], "weather_region"] if len(indices) else self.default_region
            try:
                stage_config = get_stage_offsets_for_region(region)
            except KeyError:
                return indices, None, False, f"no stage offsets for region {region}"
            filtered_offsets = {name: offsets for name, offsets in stage_config.items() if name.lower() in allowed_stages}
            if not filtered_offsets:
                return indices, None, False, f"unsupported stages for region {region}"
            metrics = _compute_metrics(location, planting_date, filtered_offsets)
            with cache_lock:
                metrics_cache[cache_key] = metrics
            return indices, metrics, False, None

        from concurrent.futures import as_completed, ThreadPoolExecutor

        workers = min(max(1, self.max_workers or len(group_items)), len(group_items)) if group_items else 1
        if workers > 1:
            logger.info("Weather analytics: processing with %d parallel workers", workers)

        for col in metric_columns:
            if col not in enriched.columns:
                enriched[col] = pd.NA
        if "weather_error" not in enriched.columns:
            enriched["weather_error"] = pd.NA

        # stage columns will be created per region based on filtered_offsets inside process_group

        stage_columns_seen: set[str] = set()

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = [executor.submit(process_group, item) for item in group_items]
            for future in as_completed(futures):
                indices, metrics, from_cache, err = future.result()
                if err is not None or metrics is None:
                    failed_groups += 1
                    failed_rows += len(indices)
                    if len(indices):
                        enriched.loc[indices, metric_columns] = pd.NA
                        if stage_columns_seen:
                            cols_to_clear = [c for c in stage_columns_seen if c in enriched.columns]
                            if cols_to_clear:
                                enriched.loc[indices, cols_to_clear] = pd.NA
                        enriched.loc[indices, "weather_error"] = err
                    if err and len(errors_sample) < 5:
                        errors_sample.append(err)
                else:
                    # Ensure columns exist
                    stage_cols = [c for c in metrics.keys() if c.endswith("_date")]
                    _ensure_columns(enriched, stage_cols)
                    stage_columns_seen.update(stage_cols)
                    for col, val in metrics.items():
                        if col not in enriched.columns:
                            if col.endswith("_date") and not col.endswith("_to_date"):
                                enriched[col] = pd.NaT
                            else:
                                enriched[col] = pd.NA
                        if col.endswith("_date") and not col.endswith("_to_date"):
                            enriched.loc[indices, col] = pd.to_datetime(val, errors="coerce")
                        else:
                            enriched.loc[indices, col] = val
                    enriched.loc[indices, "weather_error"] = pd.NA
                    success_groups += 1
                    if from_cache:
                        cache_hits += 1
                    else:
                        api_calls += 1
                checkpoint(len(indices), snapshot=enriched.loc[indices] if len(indices) else None)

        # Final guard: if planting_date is NaT, blank weather outputs to avoid stale values.
        planting_missing_final = enriched["planting_date"].isna()
        missing_count = int(planting_missing_final.sum())
        if planting_missing_final.any():
            metric_columns = [
                "gdd_to_date",
                "rainfall_to_date",
                "historical_rainfall",
                "historical_gdd",
                f"rainfall_last_{self.rainfall_context_days}",
                f"rainfall_next_{self.rainfall_context_days}",
            ]
            for col in metric_columns:
                if col not in enriched.columns:
                    enriched[col] = pd.NA
                enriched.loc[planting_missing_final, col] = pd.NA
            stage_cols = [c for c in enriched.columns if c.endswith("_date") and c.startswith(stage_prefixes)]
            if not stage_cols:
                for stage in (s.lower() for s in self.stage_whitelist):
                    stage_cols.extend([f"{stage}_early_date", f"{stage}_average_date", f"{stage}_late_date"])
            for col in stage_cols:
                if col not in enriched.columns:
                    enriched[col] = pd.NaT
                enriched.loc[planting_missing_final, col] = pd.NaT
            if "weather_error" not in enriched.columns:
                enriched["weather_error"] = pd.NA
            enriched.loc[planting_missing_final, "weather_error"] = "missing_planting_date"
            try:
                logger.info("Weather task: %s rows missing planting_date (skipped)", missing_count)
            except Exception:
                pass

        skipped_rows = len(enriched) - len(rows_to_process)
        stats = TaskStats(
            total=len(df),
            success=max(0, len(rows_to_process) - failed_rows),
            failed=failed_rows,
            filtered_out=skipped_rows,
            api_calls=api_calls,
            cache_hits=cache_hits,
            errors_sample=errors_sample,
            meta={
                "rows_to_process": len(rows_to_process),
                "unique_location_groups": total_groups,
                "rows_per_group_ratio": ratio,
                "skipped_groups_missing_location": skipped_groups,
                "missing_planting_date": missing_count,
            },
        )
        logger.info(
            "Weather task done groups=%s rows=%s success=%s failed_rows=%s api_calls=%s cache_hits=%s skipped_rows=%s",
            total_groups,
            len(df),
            stats.success,
            failed_rows,
            api_calls,
            cache_hits,
            skipped_rows,
        )
        return enriched, stats


def default_weather_bindings() -> Mapping[str, Any]:
    """Provide the standard field mapping for weather tasks."""
    mapping = {
        "id": "spatial_unit_id",
        "geohash": "geohash5",
        "centroid_wkt": "centroid_wkt",
        "planting_date": "planting_date",
        "weather_region": "n_county",
        "emergence_date": "emergence_date",
    }
    defaults = {"weather_region": "Dodge", "planting_date": pd.NaT}
    return {"mapping": mapping, "defaults": defaults}


__all__ = ["WeatherTask", "default_weather_bindings"]

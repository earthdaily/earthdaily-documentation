"""Emergence task aligned with scaffolder-style orchestration."""

from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar

import pandas as pd

from ...clients.emergence import EmergenceProcessor
from ...domain.crop_cycle import CropCycleCatalog, parse_state_county
from ...utils.geometry import to_wkt
from ..base import AnalyticsTask, TaskStats


logger = logging.getLogger("analytics.emergence")


@dataclass
class EmergenceTask(AnalyticsTask):
    """Run emergence computation per geometry and manage caching via signatures."""
    # Orchestration handled here (scaffolder-like).
    use_internal_progress: ClassVar[bool] = False
    auto_context_update: ClassVar[bool] = False
    emergence_type: str = "INSEASON"
    season_duration: int | None = None
    season_start_day: int | None = None
    season_start_month: int | None = None
    year: int | None = None
    data_source: str | None = None
    force_lri_cache: bool = False
    max_workers: int = 8
    skip_confirmed: bool = True
    region_column: str | None = "region"
    default_crop: str | None = "CORN"
    crop_cycles: CropCycleCatalog | None = None
    crop_cycle_csv_path: str | Path | None = None
    checkpoint_path: str | None = None
    checkpoint_frequency: int = 0
    progress: bool = True
    progress_desc: str = "Emergence"
    _output_columns: ClassVar[list[str]] = [
        "emergence_result",
        "emergence_date",
        "emergence_status",
        "emergence_confirmation_status",
        "emergence_error",
        "emergence_signature",
    ]

    def run(self, df, **kwargs):  # type: ignore[override]
        # Drop emergence output columns from the snapshot passed to merge_new_columns
        # so that refreshed values from execute are merged back (instead of keeping stale values).
        prev_outputs = None
        if hasattr(df, "loc"):
            cols_present = [c for c in self._output_columns if c in df.columns]
            if cols_present:
                prev_outputs = df.loc[:, cols_present].copy()
        cleaned_df = df.drop(columns=self._output_columns, errors="ignore") if hasattr(df, "drop") else df
        kwargs["_previous_outputs"] = prev_outputs
        return super().run(cleaned_df, **kwargs)

    def execute(self, df: pd.DataFrame, **kwargs: Any) -> tuple[pd.DataFrame, TaskStats]:
        """
        Execute emergence enrichment on a normalized dataframe.

        Expected columns:
        - id
        - geometry
        - crop (or uses default_crop)
        - year (or season_year)
        - optional region (state/county)
        - optional season_duration/season_start_day/season_start_month overrides
        """
        if df.empty:
            return df.copy(), TaskStats(total=0, success=0, failed=0)

        client = EmergenceProcessor.from_env()
        catalog = self.crop_cycles or CropCycleCatalog.from_csv(self.crop_cycle_csv_path)
        checkpoint = kwargs.get("_checkpoint") or (lambda *a, **k: None)
        original_df = kwargs.get("_original_df")
        logger.info(
            "Emergence task start rows=%s season_duration=%s season_start=%s/%s year=%s data_source=%s",
            len(df),
            self.season_duration,
            self.season_start_day,
            self.season_start_month,
            self.year,
            self.data_source,
        )

        result = df.reset_index(drop=True).copy()
        previous_outputs = kwargs.get("_previous_outputs")
        # Preserve passthrough columns when execute() est appelé directement.
        if isinstance(original_df, pd.DataFrame) and len(original_df) == len(result):
            for col in original_df.columns:
                if col not in result.columns:
                    result[col] = original_df[col].values

        for col in [*self._output_columns, "emergence_call_inputs"]:
            if col in result.columns:
                continue
            if isinstance(previous_outputs, pd.DataFrame) and col in previous_outputs.columns:
                result[col] = previous_outputs[col].reset_index(drop=True)
            else:
                result[col] = None
        # Use object dtype for output columns to avoid pandas warnings when setting None/pd.NA.
        for col in self._output_columns:
            try:
                result[col] = result[col].astype("object")
            except Exception:
                pass

        errors_sample: list[str] = []
        success = 0
        failed = 0
        api_calls = 0
        cache_hits = 0
        trace = kwargs.get("trace", False)

        def _resolve_year(row: pd.Series) -> int:
            if self.year is not None:
                return int(self.year)
            for candidate in (row.get("year"), row.get("season_year")):
                if candidate is None:
                    continue
                try:
                    return int(candidate)
                except Exception:
                    continue
            raise ValueError("Year must be provided (column 'year' or 'season_year' or task param 'year').")

        def _should_skip(row: pd.Series, signature: str) -> bool:
            if not self.skip_confirmed:
                return False
            status = row.get("emergence_status")
            confirmation = (row.get("emergence_confirmation_status") or "").lower()
            previous_signature = row.get("emergence_signature")
            return bool(status and confirmation == "confirmed" and previous_signature == signature)

        def _build_signature(payload: dict[str, Any]) -> str:
            as_text = json.dumps(payload, sort_keys=True, ensure_ascii=False)
            return hashlib.sha256(as_text.encode("utf-8")).hexdigest()

        def _process(idx: int, row: pd.Series):
            geometry_wkt = to_wkt(row.get("geometry"))
            crop_value = (row.get("crop") or self.default_crop or "").upper()
            if not crop_value:
                raise ValueError("Crop value missing: provide 'default_crop' or a dataframe column with values.")
            current_year = _resolve_year(row)

            state_code = county_name = None
            region_val = row.get(self.region_column) if self.region_column else None
            if region_val is not None:
                try:
                    state_code, county_name = parse_state_county(region_val)
                except Exception:
                    state_code = county_name = None

            cycle = catalog.get(crop_value, state=state_code, county=county_name)
            row_season_duration = row.get("season_duration")
            row_start_day = row.get("season_start_day")
            row_start_month = row.get("season_start_month")

            resolved_duration = (
                row_season_duration
                if row_season_duration is not None
                else self.season_duration
                if self.season_duration is not None
                else cycle.season_duration
            )
            resolved_start_day = (
                row_start_day if row_start_day is not None else self.season_start_day if self.season_start_day is not None else cycle.season_start_day
            )
            resolved_start_month = (
                row_start_month
                if row_start_month is not None
                else self.season_start_month
                if self.season_start_month is not None
                else cycle.season_start_month
            )

            signature_payload = {
                "geometry": geometry_wkt,
                "geometry_hash": hashlib.sha256(str(geometry_wkt).encode("utf-8")).hexdigest(),
                "spatial_unit_id": row.get("spatial_unit_id") or row.get("id"),
                "emergence_type": self.emergence_type,
                "crop": crop_value,
                "season_duration": resolved_duration,
                "season_start_day": resolved_start_day,
                "season_start_month": resolved_start_month,
                "year": current_year,
                "data_source": self.data_source,
                "force_lri_cache": self.force_lri_cache,
            }
            signature = _build_signature(signature_payload)
            if _should_skip(row, signature):
                return ("skip", idx, None, signature, None, signature_payload)

            try:
                resp = client.compute_inseason(
                    geometry_wkt=geometry_wkt,
                    crop=crop_value,
                    season_duration=resolved_duration,
                    season_start_day=resolved_start_day,
                    season_start_month=resolved_start_month,
                    year=current_year,
                    data_source=self.data_source,
                    force_lri_cache=self.force_lri_cache,
                    emergence_type=self.emergence_type,
                )
                logger.debug("Emergence response idx=%s payload=%s", idx, resp)
                return ("ok", idx, resp, signature, None, signature_payload)
            except Exception as exc:
                return ("error", idx, None, signature, str(exc), signature_payload)

        from concurrent.futures import as_completed, ThreadPoolExecutor

        workers = min(max(1, self.max_workers), len(result))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(_process, idx, row): idx for idx, row in result.iterrows()}
            for future in as_completed(future_map):
                status, idx, response, signature, err, payload = future.result()
                if status == "skip":
                    cache_hits += 1
                    if payload is not None:
                        result.at[idx, "emergence_call_inputs"] = payload
                    result.at[idx, "emergence_signature"] = signature
                    checkpoint(1, snapshot=result.loc[[idx]])
                    continue
                if status == "ok":
                    api_calls += 1
                    data = response.get("data", response) if isinstance(response, dict) else response
                    result.at[idx, "emergence_result"] = data
                    if payload is not None:
                        result.at[idx, "emergence_call_inputs"] = payload
                    if isinstance(data, dict):
                        result.at[idx, "emergence_date"] = data.get("EmergenceDate")
                        result.at[idx, "emergence_status"] = data.get("EmergenceStatus")
                        result.at[idx, "emergence_confirmation_status"] = data.get("ConfirmationStatus")
                    result.at[idx, "emergence_signature"] = signature
                    result.at[idx, "emergence_error"] = None
                    success += 1
                else:
                    failed += 1
                    result.at[idx, "emergence_error"] = err
                    if payload is not None:
                        result.at[idx, "emergence_call_inputs"] = payload
                    result.at[idx, "emergence_result"] = None
                    result.at[idx, "emergence_date"] = None
                    result.at[idx, "emergence_status"] = None
                    result.at[idx, "emergence_confirmation_status"] = None
                    if err and len(errors_sample) < 5:
                        errors_sample.append(err)
                    if err:
                        logger.debug("Emergence row failed idx=%s error=%s", idx, err)
                checkpoint(1, snapshot=result.loc[[idx]])

        stats = TaskStats(
            total=len(df),
            success=success,
            failed=failed,
            api_calls=api_calls,
            cache_hits=cache_hits,
            errors_sample=errors_sample,
        )
        logger.info(
            "Emergence task done rows=%s success=%s failed=%s api_calls=%s cache_hits=%s",
            len(df),
            success,
            failed,
            api_calls,
            cache_hits,
        )
        return result, stats


def default_emergence_bindings() -> Mapping[str, Any]:
    """Default dataframe mapping for emergence enrichment."""
    mapping = {
        "id": "spatial_unit_id",
        "geometry": "geometry",
        "crop": "crop_code",
        "year": "year",
        "region": "n_county",
    }
    defaults = {"crop": "CORN"}
    return {"mapping": mapping, "defaults": defaults}


__all__ = ["EmergenceTask", "default_emergence_bindings"]

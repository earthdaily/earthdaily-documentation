"""Crop mask history task aligned with scaffolder-style orchestration."""

from __future__ import annotations

import logging
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any, ClassVar

import pandas as pd

from ...clients.crop_mask import (
    _entry_for_year,
    _filter_history_by_crop,
    _history_years_str,
    CropMaskClient,
    RateLimiter,
)
from ...utils.geometry import to_wkt
from ..base import AnalyticsTask, TaskStats


logger = logging.getLogger("analytics.crop_mask")


@dataclass
class CropMaskTask(AnalyticsTask):
    """Fetch crop history for each geometry and optionally filter on a target crop."""
    # Let the task drive progress/checkpoints (scaffolder style).
    use_internal_progress: ClassVar[bool] = False
    auto_context_update: ClassVar[bool] = False
    start_year: int = 2020
    end_year: int = 2024
    min_percent: int = 50
    limit_nb_crop: int = 1
    products: Iterable[str] = ("EndSeason",)
    max_workers: int = 32
    max_qps: int = 0
    max_concurrency_cap: int = 64
    target_crop: str | None = None
    checkpoint_path: str | None = None
    checkpoint_frequency: int = 0
    progress: bool = True
    progress_desc: str = "Crop history"

    def run(self, df, **kwargs):  # type: ignore[override]
        """Apply filtering semantics: when target_crop is set, drop non-matching rows."""
        merge_back = False if self.target_crop else kwargs.pop("merge_back", True)
        kwargs["_merge_back"] = merge_back
        return super().run(df, merge_back=merge_back, **kwargs)

    def execute(self, df: pd.DataFrame, **kwargs: Any) -> tuple[pd.DataFrame, TaskStats]:
        """
        Enrich each row with crop history/current crop.

        Expected normalized columns:
        - id
        - geometry (WKT or shapely)
        - optional crop filter
        - optional start_year/end_year overrides (per-row)
        """
        if df.empty:
            return df.copy(), TaskStats(total=0, success=0, failed=0)

        client = CropMaskClient.from_env()
        start_year = df["start_year"].iloc[0] if "start_year" in df.columns else self.start_year
        end_year = df["end_year"].iloc[0] if "end_year" in df.columns else self.end_year
        checkpoint = kwargs.get("_checkpoint") or (lambda *a, **k: None)
        trace = kwargs.get("trace", False)

        result = df.reset_index(drop=True).copy()
        original_df = kwargs.get("_original_df")
        original_cols = list(original_df.columns) if isinstance(original_df, pd.DataFrame) else list(result.columns)
        for col in ("crop_history", "crop_history_years", "current_crop", "current_crop_year"):
            if col not in result.columns:
                result[col] = None

        # Preserve passthrough columns when execute() is called directement (sans run()).
        if isinstance(original_df, pd.DataFrame) and len(original_df) == len(result):
            for col in original_df.columns:
                if col not in result.columns:
                    result[col] = original_df[col].values
        helper_id_column = "id" not in (original_df.columns if isinstance(original_df, pd.DataFrame) else [])
        merge_back = bool(kwargs.get("_merge_back", True))

        errors_sample: list[str] = []
        failed = 0
        api_calls = 0
        target_crop = self.target_crop
        target_upper = target_crop.upper() if target_crop else None
        rl = RateLimiter(max_calls=self.max_qps, per_seconds=1.0) if self.max_qps and self.max_qps > 0 else None
        logger.info(
            "Crop mask task start rows=%s years=%s-%s target_crop=%s max_workers=%s",
            len(result),
            start_year,
            end_year,
            target_crop,
            self.max_workers,
        )

        def _process(idx: int, row: pd.Series):
            if rl:
                rl.acquire()
            geometry_wkt = to_wkt(row.get("geometry"))
            history = client.fetch_history(
                geometry_wkt,
                start_year=start_year,
                end_year=end_year,
                min_percent=self.min_percent,
                limit_nb_crop=self.limit_nb_crop,
                products=self.products,
                trace=trace,
            )
            filtered_history = _filter_history_by_crop(history, target_crop) if target_crop else history
            history_years = _history_years_str(filtered_history)
            if target_crop:
                season_entry = _entry_for_year(filtered_history, end_year)
                current_entry = season_entry
            else:
                season_entry = _entry_for_year(history, end_year)
                current_entry = season_entry or (history[-1] if history else None)
            return (
                "ok",
                idx,
                {
                    "history": filtered_history if target_crop else history,
                    "history_years": history_years,
                    "current_entry": current_entry,
                },
            )

        from concurrent.futures import as_completed, ThreadPoolExecutor

        workers = min(max(1, self.max_workers), len(result), self.max_concurrency_cap)
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(_process, idx, row): idx for idx, row in result.iterrows()}
            for future in as_completed(future_map):
                idx = future_map[future]
                try:
                    status, idx_res, payload = future.result()
                except Exception as exc:
                    failed += 1
                    if len(errors_sample) < 5:
                        errors_sample.append(str(exc))
                    logger.debug("Crop mask row failed idx=%s error=%s", idx, exc)
                    # Preserve row with empty values to match legacy behavior.
                    result.at[idx, "crop_history"] = []
                    result.at[idx, "crop_history_years"] = ""
                    result.at[idx, "current_crop"] = None
                    result.at[idx, "current_crop_year"] = None
                    checkpoint(1, snapshot=result.loc[[idx]])
                    continue

                if status == "ok":
                    api_calls += 1
                    history = payload["history"]
                    current_entry = payload["current_entry"]
                    result.at[idx_res, "crop_history"] = history
                    result.at[idx_res, "crop_history_years"] = payload["history_years"]
                    if current_entry:
                        result.at[idx_res, "current_crop"] = current_entry.get("crop_code")
                        result.at[idx_res, "current_crop_year"] = current_entry.get("year")
                    else:
                        result.at[idx_res, "current_crop"] = None
                        result.at[idx_res, "current_crop_year"] = None
                checkpoint(1, snapshot=result.loc[[idx_res]])

        filtered_out = 0
        if target_upper:
            mask_non_empty = result["crop_history"].apply(lambda v: isinstance(v, list) and len(v) > 0)
            mask_year = result["current_crop_year"] == end_year
            mask_crop = result["current_crop"].fillna("").str.upper() == target_upper
            filtered = result.loc[mask_non_empty & mask_year & mask_crop].reset_index(drop=True)
            filtered_out = len(result) - len(filtered)
            result = filtered

        # Drop helper id column if it was only introduced by normalization.
        if helper_id_column and not merge_back and "id" in result.columns:
            result = result.drop(columns=["id"])

        # Drop normalized crop column if it was not part of the input and is empty.
        if "crop" in result.columns and "crop" not in original_cols and result["crop"].isna().all():
            result = result.drop(columns=["crop"])

        # Reorder columns to keep original order, append new ones at the end.
        known_cols = set(original_cols)
        ordered = [c for c in original_cols if c in result.columns]
        for col in result.columns:
            if col not in known_cols:
                ordered.append(col)
        result = result[ordered]

        success = max(0, len(result) - failed) if not target_upper else len(result)
        stats = TaskStats(
            total=len(df),
            success=success,
            failed=failed,
            api_calls=api_calls,
            cache_hits=0,
            errors_sample=errors_sample,
            kept=len(result),
            filtered_out=filtered_out,
        )
        logger.info(
            "Crop mask task done rows=%s success=%s failed=%s api_calls=%s filtered_out=%s",
            len(df),
            success,
            failed,
            api_calls,
            filtered_out,
        )
        return result, stats


def default_crop_mask_bindings() -> Mapping[str, Any]:
    """Default dataframe mapping for crop mask enrichment (notebook-friendly names)."""
    mapping = {
        "id": "spatial_unit_id",
        "geometry": "geometry",
        "crop": "crop_code",
    }
    defaults = {"crop": None}
    return {"mapping": mapping, "defaults": defaults}


__all__ = ["CropMaskTask", "default_crop_mask_bindings"]

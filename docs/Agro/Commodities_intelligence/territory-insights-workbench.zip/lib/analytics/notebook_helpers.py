"""Notebook-facing helpers for analytics runs (summaries, reporting)."""

from __future__ import annotations

from typing import Any

from IPython.display import HTML, Markdown, display

from .registry import run_task


def apply_notebook_style() -> None:
    """Inject a CSS theme for headings, separators, and callouts."""
    css = """
    <style>
    /* =========================
       Notebook visual styling
       ========================= */

    :root {
      --accent: #2563eb;
      --accent-soft: #eef2ff;
      --accent-strong: #1d4ed8;
      --text: #0f172a;
      --muted: #64748b;
    }

    body {
      color: var(--text);
    }

    /* =========================
       Headings
       ========================= */

    /* H1 — major section */
    h1 {
      font-weight: 900;
      font-size: 1.9em;
      margin-top: 32px;
      margin-bottom: 16px;
      padding-bottom: 6px;
      border-bottom: 3px solid var(--accent);
    }

    /* H2 — focus title */
    h2 {
      font-weight: 800;
      font-size: 1.4em;
      margin-top: 26px;
      margin-bottom: 12px;
      padding: 8px 12px;
      background: linear-gradient(90deg, var(--accent-soft), transparent);
      border-left: 6px solid var(--accent);
      border-radius: 8px;
    }

    /* H3 — sub-section */
    h3 {
      font-weight: 700;
      font-size: 1.15em;
      margin-top: 20px;
      margin-bottom: 8px;
      color: var(--accent-strong);
      padding-left: 6px;
      border-left: 3px solid #93c5fd;
    }

    /* =========================
       Horizontal separators
       ========================= */

    hr {
      border: 0;
      height: 1px;
      background: linear-gradient(90deg, transparent, #cbd5e1, transparent);
      margin: 18px 0;
    }

    /* =========================
       Callouts
       ========================= */

    .callout {
      border: 1px solid #dbeafe;
      background: #eff6ff;
      border-radius: 10px;
      padding: 10px 12px;
      margin: 14px 0;
    }

    .callout strong {
      color: var(--accent-strong);
    }
    </style>
    """
    display(HTML(css))


def _format_metric(name: str, value: Any) -> str:
    """Format metrics to avoid noisy floats (ints except for duration)."""
    if name == "duration_seconds":
        try:
            return f"{float(value):.2f}"
        except Exception:
            return str(value)
    try:
        # Treat near-integers as ints (helps when pandas/numpy keeps floats)
        if isinstance(value, (int, float)) and abs(value - round(value)) < 1e-9:
            return str(int(round(value)))
    except Exception:
        pass
    return str(value)


def show_task_summary(stats: Any) -> None:
    """Display a compact metrics table and error samples for a TaskStats-like object."""
    if stats is None:
        display(Markdown("No stats returned."))
        return
    rows = []
    for name in ("total", "success", "failed", "filtered_out", "kept", "api_calls", "cache_hits", "duration_seconds"):
        val = getattr(stats, name, None)
        if val is not None:
            rows.append((name, _format_metric(name, val)))
    if rows:
        lines = ["| metric | value |", "| --- | --- |"]
        lines.extend([f"| `{name}` | {val} |" for name, val in rows])
        display(Markdown("\n".join(lines)))
    errors = getattr(stats, "errors_sample", None) or []
    if errors:
        display(Markdown("**Errors sample:**\n" + "\n".join(f"- {err}" for err in errors)))


def run_task_with_reporting(df, *, binding_key, reporter=None, summary_title: str | None = None, **kwargs: Any):
    """Wrapper around run_task that auto-displays TaskStats and keeps reporter wiring centralized."""
    df_out, stats = run_task(df, binding_key=binding_key, reporter=reporter, **kwargs)
    if summary_title:
        display(Markdown(f"### {summary_title}"))
    show_task_summary(stats)
    return df_out, stats


def render_final_report(reporter, *, show_inline: bool = True):
    """
    Render the final HTML report once per notebook run.
    Returns the HTML string; writes to reporter.html_path if set.
    """
    if not reporter or not getattr(reporter, "enabled", False):
        display(Markdown("Reporter disabled or not configured."))
        return None
    html = reporter.render_html()
    html_path = reporter.html_path or "tmp/analytics_run_report.html"
    display(Markdown(f"Report HTML written to `{html_path}`"))
    if show_inline:
        display(HTML(html))
    return html

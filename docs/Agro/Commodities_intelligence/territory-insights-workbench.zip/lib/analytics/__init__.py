"""Analytics tasks and registry."""

from .base import AnalyticsTask, apply_field_mapping, TaskStats
from .kpi import compute_kpi
from .params import (
    CropMaskParams,
    EmergenceParams,
    GreennessDetectionParams,  # scaffold import
    InseasonPotentialScoreParams,  # scaffold import
    LriParams,
    WeatherParams,
)
from .reporting import AnalyticsRunReporter
from .registry import (
    BindingKey,
    describe_bindings,
    format_bindings_catalog_html,
    format_bindings_html,
    format_bindings_markdown,
    format_bindings_summary,
    get_binding,
    list_bindings,
    register_binding,
    REGISTRY,
    run_task,
    TaskBinding,
)
from .notebook_helpers import apply_notebook_style, render_final_report, run_task_with_reporting, show_task_summary
from .tasks import (  # scaffold import  # scaffold import
    CropMaskTask,
    default_crop_mask_bindings,
    default_emergence_bindings,
    default_greenness_detection_bindings,
    default_inseason_potential_score_bindings,
    default_lri_bindings,
    default_weather_bindings,
    EmergenceTask,
    GreennessDetectionTask,
    InseasonPotentialScoreTask,
    LriNdviTask,
    WeatherTask,
)
from .utils import apply_input_rules, coerce_datetime_columns, mask_dates_by_status


__all__ = [
    "AnalyticsTask",
    "TaskStats",
    "apply_field_mapping",
    "TaskBinding",
    "REGISTRY",
    "register_binding",
    "get_binding",
    "run_task",
    "BindingKey",
    "apply_input_rules",
    "coerce_datetime_columns",
    "mask_dates_by_status",
    "list_bindings",
    "compute_kpi",
    "WeatherTask",
    "default_weather_bindings",
    "CropMaskTask",
    "default_crop_mask_bindings",
    "EmergenceTask",
    "default_emergence_bindings",
    "LriNdviTask",
    "default_lri_bindings",
    "describe_bindings",
    "format_bindings_summary",
    "format_bindings_markdown",
    "format_bindings_html",
    "format_bindings_catalog_html",
    "run_task_with_reporting",
    "show_task_summary",
    "render_final_report",
    "apply_notebook_style",
    "CropMaskParams",
    "WeatherParams",
    "EmergenceParams",
    "LriParams",
    "InseasonPotentialScoreTask",
    "default_inseason_potential_score_bindings",
    "InseasonPotentialScoreParams",
    "GreennessDetectionTask",
    "default_greenness_detection_bindings",
    "GreennessDetectionParams",
    "AnalyticsRunReporter",
]

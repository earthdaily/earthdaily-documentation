"""Generic KPI helpers for time series (date + value)."""

from __future__ import annotations

import logging
from collections.abc import Iterable
from datetime import datetime
from typing import Any

import pandas as pd


logger = logging.getLogger(__name__)


def compute_kpi(
    timeseries_df: pd.DataFrame,
    *,
    start_date: str,
    end_date: str,
    aggregation: str,
    kpi_name: str | None = None,
    threshold: float | tuple[float, float] | None = None,
    years: Iterable[int] | str | None = None,
    date_column: str = "date",
    value_column: str = "value",
) -> dict[str, Any]:
    """
    Compute a KPI on a time series with optional historical baseline.

    Supported aggregations: accumulation, average, max, min, std, count_gt, count_lt, count_between.
    """
    if date_column not in timeseries_df.columns or value_column not in timeseries_df.columns:
        raise ValueError(f"DataFrame must contain '{date_column}' and '{value_column}' columns")

    def _parse_date(raw: str) -> datetime.date:
        return datetime.strptime(raw, "%Y-%m-%d").date()

    start_dt = _parse_date(start_date)
    end_dt = _parse_date(end_date)
    ts = timeseries_df.copy()
    ts[date_column] = pd.to_datetime(ts[date_column]).dt.date

    def _compute(values: list[float], agg: str) -> float | None:
        if not values:
            return None
        if agg == "accumulation":
            return round(sum(values), 2)
        if agg == "average":
            return round(sum(values) / len(values), 2)
        if agg == "max":
            return round(max(values), 2)
        if agg == "min":
            return round(min(values), 2)
        if agg == "std":
            if len(values) < 2:
                return 0.0
            mean = sum(values) / len(values)
            variance = sum((x - mean) ** 2 for x in values) / len(values)
            return round(variance**0.5, 2)
        if agg == "count_gt":
            if threshold is None:
                raise ValueError("threshold required for count_gt")
            return sum(1 for v in values if v > threshold)
        if agg == "count_lt":
            if threshold is None:
                raise ValueError("threshold required for count_lt")
            return sum(1 for v in values if v < threshold)
        if agg == "count_between":
            if not isinstance(threshold, (tuple, list)) or len(threshold) != 2:
                raise ValueError("threshold must be (min, max) for count_between")
            lo, hi = threshold
            return sum(1 for v in values if lo <= v <= hi)
        raise ValueError(f"Unsupported aggregation '{agg}'")

    current_mask = (ts[date_column] >= start_dt) & (ts[date_column] <= end_dt)
    current_values = ts.loc[current_mask, value_column].dropna().tolist()
    kpi_current = _compute(current_values, aggregation)

    # Historical baseline
    past_kpis: list[float] = []
    if years:
        year_list = ts[date_column].apply(lambda d: d.year).unique().tolist()
        candidate_years = year_list if years == "ALL" else list(years)
        for y in candidate_years:
            shifted_start = start_dt.replace(year=y)
            shifted_end = end_dt.replace(year=y)
            hist_mask = (ts[date_column] >= shifted_start) & (ts[date_column] <= shifted_end)
            hist_values = ts.loc[hist_mask, value_column].dropna().tolist()
            hist_kpi = _compute(hist_values, aggregation)
            if hist_kpi is not None:
                past_kpis.append(hist_kpi)
    kpi_past_avg = round(sum(past_kpis) / len(past_kpis), 2) if past_kpis else None

    difference = None
    percent_change = None
    if kpi_current is not None and kpi_past_avg not in (None, 0):
        difference = round(kpi_current - kpi_past_avg, 2)
        percent_change = round(((kpi_current - kpi_past_avg) / kpi_past_avg) * 100, 2)

    name = kpi_name or f"KPI ({aggregation})"
    return {
        "kpi_name": name,
        "aggregation": aggregation,
        "current_period": {
            "start_date": start_date,
            "end_date": end_date,
            "value": kpi_current,
            "num_records": len(current_values),
        },
        "historical_avg": {
            "value": kpi_past_avg,
            "num_years": len(past_kpis),
        },
        "comparison": {
            "difference": difference,
            "percent_change": percent_change,
        },
    }


__all__ = ["compute_kpi"]

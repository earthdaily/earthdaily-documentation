"""Simple registry for analytics tasks (native or adapted)."""

from __future__ import annotations

import html
import json
import logging
import time
from pathlib import Path
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel

from .base import AnalyticsTask
from .params import CropMaskParams, EmergenceParams, LriParams, WeatherParams
from .reporting import AnalyticsRunReporter
from .tasks import (
    CropMaskTask,
    default_crop_mask_bindings,
    default_emergence_bindings,
    default_lri_bindings,
    default_weather_bindings,
    EmergenceTask,
    LriNdviTask,
    WeatherTask,
)


@dataclass
class TaskBinding:
    key: str
    task_cls: type[AnalyticsTask]
    field_mapping: Mapping[str, str | None]
    defaults: Mapping[str, Any] = field(default_factory=dict)
    params: Mapping[str, Any] = field(default_factory=dict)
    passthrough_columns: Iterable[str] = field(default_factory=tuple)
    param_schema: type[BaseModel] | None = None
    description: str = ""

    def instantiate(self, **overrides: Any) -> AnalyticsTask:
        kwargs = dict(self.params)
        kwargs.update(overrides)
        # Filter out unexpected kwargs to be tolerant when parameter schemas evolve.
        allowed: set[str] = set()
        try:
            if hasattr(self.task_cls, "__dataclass_fields__"):
                allowed = set(getattr(self.task_cls, "__dataclass_fields__", {}).keys())
            else:
                import inspect

                sig = inspect.signature(self.task_cls)  # type: ignore[arg-type]
                allowed = {name for name, p in sig.parameters.items() if p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY)}
        except Exception:
            allowed = set()

        if allowed:
            filtered = {k: v for k, v in kwargs.items() if k in allowed}
            if len(filtered) != len(kwargs):
                logger.debug("Ignoring extra task params for %s: %s", self.task_cls.__name__, sorted(set(kwargs) - set(filtered)))
            kwargs = filtered

        return self.task_cls(**kwargs)  # type: ignore[call-arg]


class BindingKey(StrEnum):
    WEATHER = "weather"
    CROP_MASK = "crop_mask"
    EMERGENCE = "emergence"
    LRI_NDVI = "lri_ndvi"
    INSEASON_POTENTIAL_SCORE = "inseason_potential_score"
    GREENNESS_DETECTION = "greenness_detection"


REGISTRY: dict[str, TaskBinding] = {}


def register_binding(binding: TaskBinding) -> None:
    REGISTRY[binding.key] = binding


def get_binding(key: str) -> TaskBinding:
    try:
        return REGISTRY[key]
    except KeyError as exc:
        raise KeyError(f"Task binding '{key}' not found") from exc


def list_bindings() -> list[str]:
    return sorted(REGISTRY.keys())


def describe_bindings() -> list[dict[str, Any]]:
    details: list[dict[str, Any]] = []
    for key, binding in REGISTRY.items():
        schema = binding.param_schema.model_json_schema() if binding.param_schema else None
        schema_cls = binding.param_schema.__name__ if binding.param_schema else None
        details.append(
            {
                "binding_key": key,
                "task_class": binding.task_cls.__name__,
                "description": binding.description,
                "defaults": dict(binding.defaults),
                "params": dict(binding.params),
                "param_schema": schema,
                "param_schema_class": schema_cls,
            }
        )
    return details


def format_bindings_summary(binding_key: str | BindingKey | None = None) -> str:
    details = describe_bindings()
    if binding_key:
        key_str = binding_key.value if isinstance(binding_key, StrEnum) else str(binding_key)
        details = [d for d in details if d.get("binding_key") == key_str]
    lines: list[str] = []
    lines.append("Available analytics bindings:\n")
    for entry in details:
        schema_cls = entry.get("param_schema_class") or "<unspecified>"
        lines.append(f"- {entry['binding_key']} ({entry['task_class']}) params={schema_cls}: {entry.get('description', '')}")
    for entry in details:
        lines.append(f"\nParameters for {entry['binding_key']}:")
        schema = entry.get("param_schema") or {}
        props = (schema.get("properties") or {}) if isinstance(schema, dict) else {}
        if not props:
            lines.append("  (no explicit schema)")
            continue
        for name, field in props.items():
            default = field.get("default", "<required>")
            ftype = field.get("type", "any")
            desc = field.get("description", "")
            lines.append(f"  - {name} ({ftype}), default={default}: {desc}")
    return "\n".join(lines)


def format_bindings_markdown(binding_key: str | BindingKey | None = None) -> str:
    details = describe_bindings()
    if binding_key:
        key_str = binding_key.value if isinstance(binding_key, StrEnum) else str(binding_key)
        details = [d for d in details if d.get("binding_key") == key_str]
    base_params = {
        "max_workers",
        "max_concurrency_cap",
        "max_qps",
        "checkpoint_path",
        "checkpoint_frequency",
        "progress",
        "progress_desc",
    }
    parts: list[str] = ["## Available analytics", ""]
    for entry in details:
        schema_cls = entry.get("param_schema_class") or "<unspecified>"
        parts.append(f"### {entry['binding_key']} ({entry['task_class']}), params={schema_cls}")
        desc = entry.get("description", "")
        if desc:
            parts.append(f"*{desc}*")
        schema = entry.get("param_schema") or {}
        props = (schema.get("properties") or {}) if isinstance(schema, dict) else {}
        if props:
            parts.append("")
            parts.append("Parameters:")
            for name, field in props.items():
                default = field.get("default", "<required>")
                ftype = field.get("type", "any")
                desc = field.get("description", "")
                is_base = name in base_params
                display_name = f"`{name}`" if is_base else f"<span style='color:red'>`{name}`</span>"
                parts.append(f"- **{display_name}** *(type: {ftype}, default: {default})* — {desc}")
        else:
            parts.append("- (no explicit schema)")
        parts.append("")
    parts.append(
        "_Tip: pass `error_csv_path=\"tmp/errors/<binding>_errors.csv\"` to `run_task` to export rows with error columns when failures occur (file is overwritten each call)._"
    )
    return "\n".join(parts)


def format_bindings_html(binding_key: str | BindingKey | None = None) -> str:
    """HTML rendition (no markdown escaping) with colored custom params."""
    details = describe_bindings()
    if binding_key:
        key_str = binding_key.value if isinstance(binding_key, StrEnum) else str(binding_key)
        details = [d for d in details if d.get("binding_key") == key_str]
    base_params = {
        "max_workers",
        "max_concurrency_cap",
        "max_qps",
        "checkpoint_path",
        "checkpoint_frequency",
        "progress",
        "progress_desc",
    }
    style = """
    <style>
      .binding-card {border:1px solid #e5e7eb;border-radius:12px;margin:12px 0;background:#f9fafb;}
      .binding-header {display:flex;justify-content:space-between;align-items:center;gap:8px;padding:10px 12px;}
      .binding-header h3 {margin:0;font-size:16px;}
      .binding-badge {padding:3px 8px;border-radius:999px;background:#e0f2fe;color:#075985;font-size:12px;font-weight:700;}
      .binding-body {padding:0 12px 12px 12px;}
      .param-list {list-style:none;padding-left:0;margin:6px 0 0 0;}
      .param-list li {padding:4px 0;border-bottom:1px solid #f0f2f5;}
      .param-meta {color:#6b7280;font-size:12px;margin-left:6px;}
      .param-custom {color:#b91c1c;font-weight:700;}
      .legend {color:#374151;font-size:12px;margin-bottom:4px;}
      .legend span {margin-right:10px;}
      .legend .base {color:#111827;font-weight:600;}
      .legend .custom {color:#b91c1c;font-weight:700;}
      details.binding-card summary {list-style:none;}
      details.binding-card summary::-webkit-details-marker {display:none;}
      details.binding-card[open] .binding-header {border-bottom:1px solid #e5e7eb;}
    </style>
    """
    legend = "<div class='legend'><span class='base'>Black = base params</span><span class='custom'>Red = analytics-specific</span></div>"
    parts: list[str] = [style, "<h2>Available analytics</h2>", legend]
    for entry in details:
        schema_cls = entry.get("param_schema_class") or "&lt;unspecified&gt;"
        desc = entry.get("description", "")
        title = html.escape(f"{entry['binding_key']} ({entry['task_class']})")
        desc_html = f"<p><em>{html.escape(desc)}</em></p>" if desc else ""
        parts.append("<details class='binding-card' open>")
        parts.append(
            f"<summary class='binding-header'><h3 style='margin:0;'>{title}</h3>"
            f"<span class='binding-badge'>params={html.escape(schema_cls)}</span></summary>"
        )
        parts.append("<div class='binding-body'>")
        if desc_html:
            parts.append(desc_html)
        schema = entry.get("param_schema") or {}
        props = (schema.get("properties") or {}) if isinstance(schema, dict) else {}
        if props:
            parts.append("<ul class='param-list'>")
            for name, field in props.items():
                default = field.get("default", "&lt;required&gt;")
                ftype = field.get("type", "any")
                pdesc = field.get("description", "")
                is_base = name in base_params
                safe_name = html.escape(name)
                display_name = safe_name if is_base else f"<span class='param-custom'>{safe_name}</span>"
                parts.append(
                    f"<li><strong>{display_name}</strong> "
                    f"<span class='param-meta'>(type: {html.escape(str(ftype))}, default: {html.escape(str(default))})</span>"
                    f"{' — ' + html.escape(str(pdesc)) if pdesc else ''}</li>"
                )
            parts.append("</ul>")
        else:
            parts.append("<p><em>No explicit schema.</em></p>")
        parts.append("</div>")  # body
        parts.append("</details>")
    parts.append(
        "<p><em>Tip: pass <code>error_csv_path=\"tmp/errors/&lt;binding&gt;_errors.csv\"</code> to <code>run_task</code> "
        "to export rows with error columns when failures occur (file is overwritten each call).</em></p>"
    )
    return "\n".join(parts)


def format_bindings_catalog_html(binding_key: str | BindingKey | None = None) -> str:
    """HTML cards with required columns, defaults, and parameter schemas (auto-updates with the registry)."""
    keys = list(REGISTRY.keys())
    if binding_key:
        key_str = binding_key.value if isinstance(binding_key, StrEnum) else str(binding_key)
        keys = [k for k in keys if k == key_str]
    base_params = {
        "max_workers",
        "max_concurrency_cap",
        "max_qps",
        "checkpoint_path",
        "checkpoint_frequency",
        "progress",
        "progress_desc",
    }
    style = """
    <style>
      .catalog {display:flex;flex-direction:column;gap:12px;}
      .card {border:1px solid #e5e7eb;border-radius:12px;padding:12px;background:#fff;}
      .card h3 {margin:0 0 4px 0;font-size:16px;}
      .card .desc {color:#374151;margin:0 0 8px 0;}
      .badge {display:inline-block;background:#e0f2fe;color:#075985;padding:3px 8px;border-radius:999px;font-size:11px;font-weight:700;}
      .section-title {font-weight:700;font-size:13px;margin:8px 0 4px 0;color:#111827;}
      .pill {display:inline-block;padding:4px 8px;border-radius:999px;background:#f3f4f6;margin:2px;font-size:12px;color:#111827;}
      .pill-optional {background:#ede9fe;color:#5b21b6;}
      .mapping-table {width:100%;border-collapse:collapse;font-size:12px;margin-top:4px;}
      .mapping-table th, .mapping-table td {border:1px solid #e5e7eb;padding:6px;text-align:left;}
      .param-list {list-style:none;padding-left:0;margin:0;}
      .param-list li {padding:4px 0;border-bottom:1px solid #f3f4f6;}
      .param-name {font-weight:700;color:#111827;}
      .param-custom {color:#b91c1c;}
      .param-meta {color:#6b7280;font-size:12px;margin-left:6px;}
      .legend {color:#374151;font-size:12px;margin-bottom:6px;}
      .legend span {margin-right:10px;}
      details.card summary {list-style:none;}
      details.card summary::-webkit-details-marker {display:none;}
      details.card[open] summary {border-bottom:1px solid #e5e7eb;padding-bottom:6px;margin-bottom:6px;}
    </style>
    """
    legend = "<div class='legend'><span>Base params = black</span><span>Custom params = red</span></div>"
    parts: list[str] = [style, "<div class='catalog'>", legend]
    for key in keys:
        try:
            binding = get_binding(key)
        except KeyError:
            continue
        schema = binding.param_schema.model_json_schema() if binding.param_schema else {}
        props = (schema.get("properties") or {}) if isinstance(schema, dict) else {}
        required_cols = sorted(
            {src for tgt, src in (binding.field_mapping or {}).items() if src and tgt not in (binding.defaults or {})}
        )
        optional_defaults = {tgt: val for tgt, val in (binding.defaults or {}).items()}
        mapping_rows = []
        for tgt, src in (binding.field_mapping or {}).items():
            src_display = html.escape(str(src)) if src else "<em>None</em>"
            default_val = optional_defaults.get(tgt)
            mapping_rows.append(
                f"<tr><td><code>{html.escape(str(tgt))}</code></td><td><code>{src_display}</code></td>"
                f"<td>{html.escape(str(default_val)) if default_val is not None else ''}</td></tr>"
            )
        parts.append("<details class='card' open>")
        parts.append(
            f"<summary><h3>{html.escape(key)}</h3><span class='badge'>{html.escape(binding.task_cls.__name__)}</span></summary>"
        )
        if binding.description:
            parts.append(f"<p class='desc'>{html.escape(binding.description)}</p>")
        if required_cols:
            pills = "".join(f"<span class='pill'>{html.escape(col)}</span>" for col in required_cols)
            parts.append("<div class='section-title'>Required input columns</div>")
            parts.append(f"<div>{pills}</div>")
        else:
            parts.append("<div class='section-title'>Required input columns</div><div class='pill'>None</div>")
        if optional_defaults:
            pills = "".join(
                f"<span class='pill pill-optional'>{html.escape(tgt)} = {html.escape(str(val))}</span>"
                for tgt, val in optional_defaults.items()
            )
            parts.append("<div class='section-title'>Defaults applied</div>")
            parts.append(f"<div>{pills}</div>")
        if mapping_rows:
            parts.append("<div class='section-title'>Field mapping (target <- source)</div>")
            parts.append("<table class='mapping-table'><thead><tr><th>Target</th><th>Source</th><th>Default</th></tr></thead><tbody>")
            parts.extend(mapping_rows)
            parts.append("</tbody></table>")
        if props:
            parts.append("<div class='section-title'>Parameters</div><ul class='param-list'>")
            for name, field in props.items():
                default = field.get("default", "<required>")
                ftype = field.get("type", "any")
                desc = field.get("description", "")
                is_base = name in base_params
                display_name = html.escape(name) if is_base else f"<span class='param-custom'>{html.escape(name)}</span>"
                parts.append(
                    f"<li><span class='param-name'>{display_name}</span>"
                    f"<span class='param-meta'>(type: {html.escape(str(ftype))}, default: {html.escape(str(default))})</span> "
                    f"{html.escape(str(desc)) if desc else ''}</li>"
                )
            parts.append("</ul>")
        else:
            parts.append("<div class='section-title'>Parameters</div><p><em>No explicit schema.</em></p>")
        parts.append("</details>")
    parts.append("</div>")
    return "\n".join(parts)

def run_task(
    df,
    *,
    binding_key: str | BindingKey,
    field_mapping_override: Mapping[str, str | None] | None = None,
    defaults_override: Mapping[str, Any] | None = None,
    task_params: Mapping[str, Any] | None = None,
    passthrough_override: Iterable[str] | None = None,
    input_rules: Iterable[Mapping[str, Any]] | None = None,
    reporter: AnalyticsRunReporter | bool | None = None,
    error_csv_path: str | None = None,
    **run_kwargs: Any,
):
    """Instantiate the task, apply the field mapping, and execute with sensible defaults."""
    binding_key_str = binding_key.value if isinstance(binding_key, StrEnum) else str(binding_key)

    binding = get_binding(binding_key_str)
    if binding.param_schema:
        model = binding.param_schema(**(task_params or {}))
        validated_params = model.model_dump(exclude_none=False)
    else:
        validated_params = dict(task_params or {})
    # Preserve extra task_params that are not part of the param_schema (e.g., crop_cycles objects).
    extras = {k: v for k, v in (task_params or {}).items() if k not in validated_params}
    if extras:
        validated_params.update(extras)

    task = binding.instantiate(**validated_params)
    reporter_obj: AnalyticsRunReporter | None
    if isinstance(reporter, bool):
        reporter_obj = AnalyticsRunReporter(enabled=reporter)
    else:
        reporter_obj = reporter if isinstance(reporter, AnalyticsRunReporter) else None

    mapping = binding.field_mapping
    if field_mapping_override:
        mapping = {**mapping, **field_mapping_override}
    defaults = {**binding.defaults, **(defaults_override or {})}
    passthrough = tuple(passthrough_override) if passthrough_override is not None else tuple(binding.passthrough_columns)
    started_at = datetime.utcnow()
    start = time.perf_counter()
    result_df, stats = task.run(
        df,
        field_mapping=mapping,
        defaults=defaults,
        passthrough_columns=passthrough,
        input_rules=input_rules,
        **run_kwargs,
    )
    added_columns = sorted(set(result_df.columns) - set(df.columns)) if hasattr(result_df, "columns") and hasattr(df, "columns") else []
    finished_at = datetime.utcnow()
    duration = time.perf_counter() - start
    try:
        if getattr(stats, "duration_seconds", None) is None:
            stats.duration_seconds = duration
    except Exception:
        pass
    if reporter_obj and getattr(reporter_obj, "enabled", False):
        try:
            stats_dict = stats.as_dict() if hasattr(stats, "as_dict") else {}
            reporter_obj.add_task_run(
                binding_key=binding_key_str,
                task_name=task.__class__.__name__,
                params=validated_params,
                field_mapping=mapping,
                defaults=defaults,
                stats=stats_dict,
                input_rows=len(df) if df is not None else 0,
                output_rows=len(result_df) if result_df is not None else 0,
                added_columns=added_columns,
                input_rules=list(input_rules or []),
                started_at=started_at,
                finished_at=finished_at,
            )
        except Exception:
            logger.exception("Reporter failed to record task %s", binding_key_str)

    # Optional error export: dump rows with non-null *error* columns when failures occurred.
    if error_csv_path and getattr(stats, "failed", 0) > 0:
        try:
            err_cols = [
                c
                for c in result_df.columns
                if "error" in c.lower()
                and (
                    binding_key_str.lower() in c.lower()
                    or c in set(added_columns)
                    or c in set(passthrough)
                )
            ]
            # Fallback: if none matched the current binding, consider all error-like columns.
            if not err_cols:
                err_cols = [c for c in result_df.columns if "error" in c.lower()]
            if err_cols:
                err_rows = result_df.loc[result_df[err_cols].notna().any(axis=1)]
                if not err_rows.empty:
                    id_candidates = ("spatial_unit_id", "id")
                    selected_cols: list[str] = []
                    for cand in id_candidates:
                        if cand in result_df.columns:
                            selected_cols.append(cand)
                            break
                    err_rows = err_rows.copy()
                    call_input_cols = [c for c in err_rows.columns if c.endswith("call_inputs")]
                    response_cols = [c for c in err_rows.columns if c.endswith("api_response")]
                    export_cols = [*selected_cols, *call_input_cols, *response_cols, *err_cols]
                    export_cols = [c for c in export_cols if c in err_rows.columns]
                    # JSON-encode dict-like inputs/responses for readability.
                    for col in [*call_input_cols, *response_cols]:
                        err_rows[col] = err_rows[col].apply(
                            lambda v: json.dumps(v, ensure_ascii=False, default=str) if isinstance(v, (dict, list)) else v
                        )
                    path = Path(error_csv_path).expanduser()
                    path.parent.mkdir(parents=True, exist_ok=True)
                    err_rows.to_csv(path, index=False, columns=export_cols, sep=";")
                    logger.warning("Saved error rows to %s (%s rows)", path, len(err_rows))
        except Exception:
            logger.exception("Failed to export error rows to CSV")
    # Avoid bloating outputs: drop call_inputs helper columns from the returned dataframe.
    call_input_cols = [c for c in result_df.columns if c.endswith("call_inputs")]
    if call_input_cols:
        result_df = result_df.drop(columns=call_input_cols, errors="ignore")
    return result_df, stats


__all__ = [
    "TaskBinding",
    "REGISTRY",
    "register_binding",
    "get_binding",
    "run_task",
    "BindingKey",
    "list_bindings",
    "describe_bindings",
    "format_bindings_summary",
    "format_bindings_markdown",
    "format_bindings_html",
    "format_bindings_catalog_html",
]

# Register built-in tasks
try:  # pragma: no cover
    _w = default_weather_bindings()
    register_binding(
        TaskBinding(
            key="weather",
            task_cls=WeatherTask,
            field_mapping=_w["mapping"],
            defaults=_w["defaults"],
            param_schema=WeatherParams,
            description="Weather metrics and planting date derivation",
        ),
    )
except Exception:
    pass

try:  # pragma: no cover
    _c = default_crop_mask_bindings()
    register_binding(
        TaskBinding(
            key="crop_mask",
            task_cls=CropMaskTask,
            field_mapping=_c["mapping"],
            defaults=_c["defaults"],
            param_schema=CropMaskParams,
            description="Crop history enrichment (current crop, history)",
        ),
    )
except Exception:
    pass

try:  # pragma: no cover
    _lri = default_lri_bindings()
    register_binding(
        TaskBinding(
            key="lri_ndvi",
            task_cls=LriNdviTask,
            field_mapping=_lri["mapping"],
            defaults=_lri["defaults"],
            param_schema=LriParams,
            description="NDVI accumulation from LRI over sliding windows",
        ),
    )
except Exception:
    pass

try:  # pragma: no cover
    _e = default_emergence_bindings()
    register_binding(
        TaskBinding(
            key="emergence",
            task_cls=EmergenceTask,
            field_mapping=_e["mapping"],
            defaults=_e["defaults"],
            passthrough_columns=(
                "emergence_result",
                "emergence_date",
                "emergence_status",
                "emergence_confirmation_status",
                "emergence_error",
                "emergence_signature",
            ),
            param_schema=EmergenceParams,
            description="Emergence enrichment and confirmation status",
        ),
    )
except Exception:
    pass
logger = logging.getLogger(__name__)

# Auto-generated scaffold for inseason_potential_score
try:  # pragma: no cover
    from .params import InseasonPotentialScoreParams
    from .tasks import default_inseason_potential_score_bindings, InseasonPotentialScoreTask

    _inseason_potential_score = default_inseason_potential_score_bindings()
    register_binding(
        TaskBinding(
            key="inseason_potential_score",
            task_cls=InseasonPotentialScoreTask,
            field_mapping=_inseason_potential_score["mapping"],
            defaults=_inseason_potential_score["defaults"],
            param_schema=InseasonPotentialScoreParams,
            description="InSeason Risk Score Computation",
        ),
    )
except Exception:
    logger.exception("Failed to register binding inseason_potential_score")

# Auto-generated scaffold for greenness_detection
try:  # pragma: no cover
    from .params import GreennessDetectionParams
    from .tasks import default_greenness_detection_bindings, GreennessDetectionTask

    _greenness_detection = default_greenness_detection_bindings()
    register_binding(
        TaskBinding(
            key="greenness_detection",
            task_cls=GreennessDetectionTask,
            field_mapping=_greenness_detection["mapping"],
            defaults=_greenness_detection["defaults"],
            param_schema=GreennessDetectionParams,
            description="BrazilFintechGreennessDetection",
        ),
    )
except Exception:
    logger.exception("Failed to register binding greenness_detection")

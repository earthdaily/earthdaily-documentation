"""Small shared helpers to normalize inputs before running analytics tasks."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

import pandas as pd
from pandas.api.types import is_datetime64_any_dtype


def coerce_datetime_columns(
    df: pd.DataFrame,
    columns: Iterable[str] | Mapping[str, Mapping[str, Any]],
    *,
    default_min_year: int = 1900,
) -> pd.DataFrame:
    """
    Return a copy with the given columns converted to pandas datetime and clamped.

    - ``columns`` can be an iterable of column names or a mapping of ``name -> options``.
    - ``default_min_year`` drops unrealistic timestamps (anything older becomes NaT).
    """
    normalized = df.copy()
    if isinstance(columns, Mapping):
        col_items = columns.items()
    else:
        col_items = ((name, {}) for name in columns)

    for name, opts in col_items:
        if name not in normalized.columns:
            continue
        min_year = opts.get("min_year", default_min_year) if isinstance(opts, Mapping) else default_min_year
        coerced = pd.to_datetime(normalized[name], errors="coerce")
        if min_year:
            try:
                coerced = coerced.mask(coerced.dt.year < int(min_year))
            except Exception:
                pass
        normalized[name] = coerced
    return normalized


def mask_dates_by_status(
    df: pd.DataFrame,
    *,
    date_column: str,
    status_columns: Iterable[str] = (),
    false_status_values: Iterable[str] | None = None,
) -> tuple[pd.DataFrame, pd.Series]:
    """
    Clear date values when status columns signal that the event did not happen.

    Returns (updated_df, mask_of_rows_cleared).
    """
    updated = df.copy()
    mask = pd.Series(False, index=updated.index)
    false_status_values = {str(v).strip().lower() for v in (false_status_values or {"false", "no", "no_emergence", "0"})}
    for col in status_columns:
        if col not in updated.columns:
            continue
        series = updated[col]
        if pd.api.types.is_bool_dtype(series):
            mask = mask | series.eq(False)
        else:
            normalized = series.astype(str).str.strip().str.lower()
            mask = mask | normalized.isin(false_status_values)
    if date_column in updated.columns:
        updated.loc[mask, date_column] = pd.NaT
    return updated, mask


def apply_input_rules(
    df: pd.DataFrame,
    rules: Iterable[Mapping[str, Any]] | None,
    *,
    default_min_year: int = 1900,
) -> tuple[pd.DataFrame, pd.Series]:
    """
    Apply a list of cleansing rules and return (clean_df, skipped_mask).

    Each rule supports:
    - column: str (required)
    - coerce: "datetime" | None
    - min_year: int (used with coerce=datetime)
    - invalid_values: iterable of values to blank
    - clear_value: bool (default True): blank invalid values
    - skip_row: bool (default True): mark row as skipped when invalid
    """
    if not rules:
        return df.copy(), pd.Series(False, index=df.index)

    cleaned = df.copy()
    skipped = pd.Series(False, index=df.index)

    # Normalize/flatten rules (accept nested iterables, skip non-mappings).
    normalized_rules: list[Mapping[str, Any]] = []
    for rule in rules:
        if isinstance(rule, Mapping):
            normalized_rules.append(rule)
        elif isinstance(rule, Iterable) and not isinstance(rule, (str, bytes)):
            for inner in rule:
                if isinstance(inner, Mapping):
                    normalized_rules.append(inner)
        # else: ignore

    for rule in normalized_rules:
        column = rule.get("column")
        if not column or column not in cleaned.columns:
            continue
        coerce_kind = (rule.get("coerce") or "").lower()
        min_year = rule.get("min_year", default_min_year)
        clear_value = rule.get("clear_value", True)
        skip_row = rule.get("skip_row", True)

        if coerce_kind == "datetime":
            cleaned = coerce_datetime_columns(
                cleaned,
                columns={column: {"min_year": min_year}},
                default_min_year=default_min_year,
            )

        series = cleaned[column]
        is_dt = is_datetime64_any_dtype(series)

        invalid_values = rule.get("invalid_values") or []
        invalid_norm = {str(v).strip().lower() for v in invalid_values if v is not None}
        invalid_mask = pd.Series(False, index=cleaned.index)
        if invalid_norm:
            normalized = series.astype(str).str.strip().str.lower()
            invalid_mask = normalized.isin(invalid_norm)
            if clear_value:
                cleaned.loc[invalid_mask, column] = pd.NaT if is_dt else pd.NA

        if skip_row:
            skipped = skipped | invalid_mask

    return cleaned, skipped


__all__ = ["coerce_datetime_columns", "mask_dates_by_status", "apply_input_rules"]

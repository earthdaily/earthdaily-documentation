"""Shared analytics task primitives (mapping, safeguards, stats)."""

from __future__ import annotations

import logging
import warnings
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from threading import Lock
from typing import Any

import pandas as pd

from .utils import apply_input_rules


logger = logging.getLogger(__name__)


def _make_progress(total: int, desc: str, enabled: bool = True):
    if not enabled:
        return None
    try:
        try:
            import ipywidgets  # noqa: F401
            from tqdm.notebook import tqdm as _tqdm
        except Exception:
            from tqdm import tqdm as _tqdm
        return _tqdm(total=total, desc=desc, dynamic_ncols=True)
    except Exception:
        return None


def merge_new_columns(
    original_df: pd.DataFrame,
    result_df: pd.DataFrame,
    *,
    base_columns: set[str],
    field_mapping: Mapping[str, str | None],
    preserve_base_columns: set[str] | None = None,
    override_base_columns: set[str] | None = None,
) -> pd.DataFrame:
    """Merge task-added columns back onto the original dataframe to preserve user data."""
    id_column = "id"
    source_id_column = field_mapping.get("id") or id_column
    original_columns = set(original_df.columns)
    # Ensure result has an id column to join on; if missing, derive from index.
    if id_column not in result_df.columns:
        result_df = result_df.copy()
        result_df[id_column] = result_df.index
    # Merge columns produced by the task (everything outside the normalized base),
    # overwriting any existing columns of the same name to keep refreshed values.
    preserve_base_columns = preserve_base_columns or set()
    override_base_columns = override_base_columns or set()
    new_columns = [
        col
        for col in result_df.columns
        if col not in (id_column, source_id_column)
        and (
            col in override_base_columns
            or col not in base_columns
            or (col in preserve_base_columns and col not in original_columns)
        )
    ]
    if not new_columns:
        return original_df

    subset_cols = [id_column] + new_columns
    result_subset = result_df[subset_cols].copy()
    target_join_column = source_id_column if source_id_column in original_df.columns else id_column
    if target_join_column != id_column:
        result_subset = result_subset.rename(columns={id_column: target_join_column})

    merged_base = original_df.drop(columns=[col for col in new_columns if col in original_df.columns], errors="ignore")
    # If the original DF lacks the join column (common when id is defaulted), synthesize it from the result.
    if target_join_column not in merged_base.columns:
        # Fall back to index alignment and avoid injecting a synthetic id column in the output.
        result_no_join = result_subset.drop(columns=[target_join_column], errors="ignore")
        merged = merged_base.merge(result_no_join, how="left", left_index=True, right_index=True)
    else:
        merged = merged_base.merge(result_subset, how="left", on=target_join_column)

    # Preserve existing values for rows that were skipped (e.g., filtered out before execute),
    # except when the row has an error flag (we want to clear stale outputs in that case).
    error_mask = None
    try:
        error_cols = [c for c in merged.columns if "error" in c.lower()]
        if error_cols:
            error_mask = merged[error_cols].notna().any(axis=1)
    except Exception:
        error_mask = None

    for col in new_columns:
        if col in original_df.columns:
            # override_base_columns: never restore old values even if NaN in result.
            if col in override_base_columns:
                continue
            try:
                restore_mask = merged[col].isna()
                if error_mask is not None and len(error_mask) == len(merged[col]):
                    restore_mask = restore_mask & ~error_mask
                merged[col] = merged[col].where(~restore_mask, original_df[col].reindex(merged.index))
            except Exception:
                merged[col] = merged[col].fillna(original_df[col].reindex(merged.index))
    return merged


class TaskContext:
    """Unified progress/checkpoint helper for analytics tasks."""

    def __init__(
        self,
        *,
        total: int,
        desc: str,
        progress_enabled: bool,
        checkpoint_path: str | None,
        checkpoint_frequency: int,
        original_df: pd.DataFrame | None,
        field_mapping: Mapping[str, str | None] | None,
        base_columns: set[str] | None,
        override_base_columns: set[str] | None = None,
    ) -> None:
        self.pbar = _make_progress(total, desc, enabled=progress_enabled)
        self.checkpoint_file: Path | None = None
        self.checkpoint_frame: pd.DataFrame | None = None
        self.checkpoint_frequency = max(0, checkpoint_frequency or 0)
        self._since_last = 0
        self._processed_total = 0
        self._pending_snapshot: pd.DataFrame | None = None
        self._can_checkpoint = bool(checkpoint_path and isinstance(original_df, pd.DataFrame))
        self._field_mapping = field_mapping or {}
        self._base_columns = base_columns or set()
        self._override_base_columns = override_base_columns or set()
        if self._can_checkpoint:
            path = Path(checkpoint_path).expanduser()
            if not path.suffix:
                path = path.with_suffix(".parquet")
            path.parent.mkdir(parents=True, exist_ok=True)
            self.checkpoint_file = path
            self.checkpoint_frame = original_df.copy() if isinstance(original_df, pd.DataFrame) else None
            logger.info("Checkpoint enabled: path=%s freq=%s", self.checkpoint_file, self.checkpoint_frequency)

    def update(self, n: int = 1, snapshot: pd.DataFrame | None = None) -> None:
        if self.pbar:
            self.pbar.update(n)
        if not self._can_checkpoint or self.checkpoint_file is None or self.checkpoint_frame is None:
            return
        if self.checkpoint_frequency <= 0:
            return
        self._since_last += n
        self._processed_total += n
        if snapshot is not None:
            self._pending_snapshot = snapshot.copy()
        if self._since_last < self.checkpoint_frequency:
            return
        self._since_last = 0
        if self._pending_snapshot is not None:
            self._write_snapshot(self._pending_snapshot)
            self._pending_snapshot = None

    def _write_snapshot(self, snapshot: pd.DataFrame) -> None:
        if self.checkpoint_frame is None or self.checkpoint_file is None:
            return
        try:
            merged = merge_new_columns(
                self.checkpoint_frame,
                snapshot,
                base_columns=self._base_columns,
                field_mapping=self._field_mapping,
                override_base_columns=self._override_base_columns,
            )
            # Ensure geometry is serializable
            if "geometry" in merged.columns:
                try:
                    import geopandas as gpd

                    geom_series = merged["geometry"]
                    with warnings.catch_warnings():
                        warnings.filterwarnings(
                            "ignore",
                            message=".*Geometry column does not contain geometry.*",
                            category=UserWarning,
                        )
                        if pd.api.types.is_string_dtype(geom_series):
                            geom_series = gpd.GeoSeries.from_wkt(geom_series, errors="ignore")
                        elif geom_series.apply(lambda v: isinstance(v, (bytes, bytearray))).all():
                            geom_series = gpd.GeoSeries.from_wkb(geom_series, errors="ignore")
                        else:
                            geom_series = gpd.GeoSeries(geom_series)
                        merged["geometry"] = geom_series.to_wkb()
                except Exception:
                    try:
                        merged["geometry"] = merged["geometry"].astype(str)
                    except Exception:
                        pass
            tmp_path = self.checkpoint_file.with_suffix(self.checkpoint_file.suffix + ".tmp")
            merged.to_parquet(tmp_path, index=False)
            tmp_path.replace(self.checkpoint_file)
            self.checkpoint_frame = merged
            rows_saved = min(self._processed_total, len(self.checkpoint_frame) if self.checkpoint_frame is not None else len(merged))
            logger.info("Checkpoint saved: path=%s rows=%s", self.checkpoint_file, rows_saved)
        except Exception as exc:  # pragma: no cover - best effort
            logger.warning("Checkpoint write failed: %s", exc)

    def close(self) -> None:
        if self.pbar:
            try:
                self.pbar.close()
            except Exception:
                pass
        # Flush pending snapshot if any
        if self._pending_snapshot is not None:
            self._write_snapshot(self._pending_snapshot)
            self._pending_snapshot = None

    def reset_total(self, total: int, *, reset_n: bool = True) -> None:
        """Adjust progress bar total (e.g., after filtering rows)."""
        if not self.pbar:
            return
        try:
            self.pbar.total = max(0, int(total))
            if reset_n:
                self.pbar.n = 0
            self.pbar.refresh()
        except Exception:
            pass


def build_task_context(
    *,
    total: int,
    desc: str,
    progress: bool,
    progress_desc: str | None,
    checkpoint_path: str | None,
    checkpoint_frequency: int,
    original_df: pd.DataFrame | None,
    field_mapping: Mapping[str, str | None] | None,
    base_columns: set[str] | None,
    override_base_columns: set[str] | None = None,
) -> TaskContext:
    return TaskContext(
        total=total,
        desc=progress_desc or desc,
        progress_enabled=progress,
        checkpoint_path=checkpoint_path,
        checkpoint_frequency=checkpoint_frequency,
        original_df=original_df,
        field_mapping=field_mapping,
        base_columns=base_columns,
        override_base_columns=override_base_columns,
    )


def _validate_mapping(df: pd.DataFrame, mapping: Mapping[str, str | None], defaults: Mapping[str, Any]) -> None:
    """Ensure all target fields are provided either via mapping columns or defaults."""
    missing: list[str] = []
    for target, source in mapping.items():
        if source is None and target in defaults:
            continue
        if source and source in df.columns:
            continue
        if target in defaults:
            continue
        missing.append(source or target)
    if missing:
        raise ValueError(f"Missing required columns for task: {', '.join(sorted(set(missing)))}")


def apply_field_mapping(
    df: pd.DataFrame,
    mapping: Mapping[str, str | None],
    defaults: Mapping[str, Any] | None = None,
) -> pd.DataFrame:
    """
    Return a copy of `df` with normalized column names based on `mapping`.

    - `mapping`: target -> source column name (or None to use defaults).
    - `defaults`: fallback values when source is missing/None.
    """
    defaults = defaults or {}
    _validate_mapping(df, mapping, defaults)
    normalized = {}
    row_count = len(df)

    for target, source in mapping.items():
        if source and source in df.columns:
            normalized[target] = df[source]
        elif target in defaults:
            normalized[target] = pd.Series([defaults[target]] * row_count, index=df.index)
        else:
            raise ValueError(f"Missing required column '{source or target}' for mapping.")

    return pd.DataFrame(normalized, index=df.index).reset_index(drop=True)


@dataclass
class TaskStats:
    total: int = 0
    success: int = 0
    failed: int = 0
    api_calls: int = 0
    cache_hits: int = 0
    errors_sample: list[str] = field(default_factory=list)
    kept: int = 0  # specific tasks can set how many rows remain after filtering
    filtered_out: int = 0  # specific tasks can expose how many rows were dropped
    duration_seconds: float | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "total": self.total,
            "success": self.success,
            "failed": self.failed,
            "api_calls": self.api_calls,
            "cache_hits": self.cache_hits,
            "errors_sample": self.errors_sample,
            "kept": self.kept,
            "filtered_out": self.filtered_out,
            "duration_seconds": self.duration_seconds,
            "meta": self.meta,
        }


class AnalyticsTask:
    """
    Base class for analytics tasks.

    Subclasses should override:
    - `execute(self, df: pd.DataFrame, **kwargs) -> tuple[pd.DataFrame, TaskStats]`
    """

    # Toggle whether progress bar should be handled inside the task itself.
    # When True, the base class disables its own progress bar but still provides checkpointing.
    use_internal_progress: bool = False
    # Toggle whether the base class should automatically update/close the context after execute.
    auto_context_update: bool = True
    _column_lock: Lock | None = None

    def _ensure_column(self, df: pd.DataFrame, column: str) -> None:
        """Create a column if missing (thread-safe) and track as override runtime."""
        if column in df.columns:
            return
        if self._column_lock is None:
            self._column_lock = Lock()
        with self._column_lock:
            if column not in df.columns:
                df[column] = pd.NA
                runtime = getattr(self, "_override_base_columns_runtime", None)
                if isinstance(runtime, set):
                    runtime.add(column)

    def execute(self, df: pd.DataFrame, **kwargs: Any) -> tuple[pd.DataFrame, TaskStats]:  # pragma: no cover - abstract
        raise NotImplementedError

    def run(
        self,
        df: pd.DataFrame,
        *,
        field_mapping: Mapping[str, str | None],
        passthrough_columns: Iterable[str] | None = None,
        defaults: Mapping[str, Any] | None = None,
        prepare: Callable[[pd.DataFrame], pd.DataFrame] | None = None,
        merge_back: bool = True,
        input_rules: Iterable[Mapping[str, Any]] | None = None,
        override_base_columns: set[str] | None = None,
        **kwargs: Any,
    ) -> tuple[pd.DataFrame, TaskStats]:
        """
        Normalize the dataframe, optionally transform it, execute the task, and return enriched df + stats.

        When ``merge_back=True`` (default) the task result columns are merged back
        onto the original dataframe using the ``id`` mapping so that we don't
        drop user-provided columns. Set ``merge_back=False`` to get the normalized
        dataframe produced by the task (raw behavior).
        """
        if df is None:
            raise ValueError("Input dataframe is None")
        field_mapping = dict(field_mapping or {})
        original_df_full = df.copy()

        # Establish a stable join column before any filtering to avoid positional merges.
        join_source = field_mapping.get("id")
        join_candidates = [cand for cand in (join_source, "spatial_unit_id", "id") if cand]
        join_column = next((cand for cand in join_candidates if cand in original_df_full.columns), None)
        if not join_column:
            join_column = join_candidates[0] if join_candidates else "id"
        stable_index = pd.Series(original_df_full.index, index=original_df_full.index)
        if join_column not in original_df_full.columns:
            original_df_full = original_df_full.copy()
            original_df_full[join_column] = stable_index
        elif original_df_full[join_column].isna().any():
            original_df_full = original_df_full.copy()
            na_mask = original_df_full[join_column].isna()
            original_df_full.loc[na_mask, join_column] = stable_index[na_mask]
        mapping_id_column = join_source or "id"
        if mapping_id_column not in original_df_full.columns and join_column in original_df_full.columns:
            original_df_full[mapping_id_column] = original_df_full[join_column]
        # If the chosen id column exists but is not unique, switch to a synthetic stable column for merging.
        if mapping_id_column in original_df_full.columns and original_df_full[mapping_id_column].duplicated().any():
            synth_col = "_merge_row_id"
            while synth_col in original_df_full.columns:
                synth_col = f"{synth_col}_"
            original_df_full = original_df_full.copy()
            original_df_full[synth_col] = stable_index
            field_mapping["id"] = synth_col
            join_column = synth_col
        elif "id" not in field_mapping:
            field_mapping["id"] = join_column
        original_df_processed = original_df_full

        # Optional cleansing rules BEFORE mapping (rules expressed in caller column names).
        rules = input_rules if input_rules is not None else getattr(self, "input_rules", None)
        skipped_mask = None
        filtered_out_count = 0
        if rules:
            filtered_df, skipped_mask = apply_input_rules(original_df_full, rules)
            filtered_out_count = int(skipped_mask.sum()) if hasattr(skipped_mask, "sum") else 0
            if filtered_out_count:
                filtered_df = filtered_df.loc[~skipped_mask].reset_index(drop=True)
                try:
                    logger.info(
                        "%s: input_rules skipped %d/%d rows",
                        self.__class__.__name__,
                        filtered_out_count,
                        len(df),
                    )
                except Exception:
                    pass
            original_df_processed = filtered_df

        normalized = apply_field_mapping(original_df_processed, field_mapping, defaults)
        base_columns = set(normalized.columns)

        # Optional cleansing rules AFTER mapping (if caller rules reference normalized columns).
        if rules:
            normalized, skipped_mask_post = apply_input_rules(normalized, rules)
            skipped_mask_post = skipped_mask_post if isinstance(skipped_mask_post, pd.Series) else None
            filtered_out_post = int(skipped_mask_post.sum()) if getattr(skipped_mask_post, "sum", None) else 0
            if filtered_out_post:
                filtered_out_count += filtered_out_post
                # Keep original_df_processed aligned with normalized length when we drop rows post-mapping.
                if skipped_mask_post is not None and len(skipped_mask_post) == len(original_df_processed):
                    original_df_processed = original_df_processed.loc[~skipped_mask_post].reset_index(drop=True)
                normalized = normalized.loc[~skipped_mask_post].reset_index(drop=True) if skipped_mask_post is not None else normalized
                try:
                    logger.info(
                        "%s: input_rules skipped %d/%d rows (post-mapping)",
                        self.__class__.__name__,
                        filtered_out_post,
                        len(df),
                    )
                except Exception:
                    pass

        passthrough_columns = tuple(passthrough_columns or ())
        if passthrough_columns:
            for column in passthrough_columns:
                if column in normalized.columns or column not in original_df_full.columns:
                    continue
                normalized[column] = original_df_full[column].reset_index(drop=True)
            base_columns |= set(normalized.columns)

        # Progress + checkpoint context (optional).
        context_progress = kwargs.get("progress", True) and not self.use_internal_progress
        ctx: TaskContext | None = None
        try:
            ctx = build_task_context(
                total=len(normalized),
                desc=kwargs.get("progress_desc", getattr(self, "progress_desc", "Task")),
                progress=context_progress,
                progress_desc=kwargs.get("progress_desc", getattr(self, "progress_desc", "Task")),
                checkpoint_path=kwargs.get("checkpoint_path", getattr(self, "checkpoint_path", None)),
                checkpoint_frequency=kwargs.get("checkpoint_frequency", getattr(self, "checkpoint_frequency", 0)),
                original_df=original_df_full,
                field_mapping=field_mapping,
                base_columns=set(normalized.columns),
                override_base_columns=override_base_columns,
            )
        except Exception:
            ctx = None

        def _checkpoint(n: int = 1, snapshot: pd.DataFrame | None = None) -> None:
            if ctx is None:
                return
            try:
                ctx.update(n, snapshot=snapshot)
            except Exception:
                pass

        if prepare:
            normalized = prepare(normalized)
        result_df, stats = self.execute(
            normalized,
            _original_df=original_df_processed,
            _field_mapping=field_mapping,
            _base_columns=base_columns,
            _context=ctx,
            _checkpoint=_checkpoint,
            **kwargs,
        )

        if ctx and self.auto_context_update:
            try:
                ctx.update(len(result_df), snapshot=result_df)
            except Exception:
                pass

        # Ensure stats accounts for filtered/skipped rows.
        try:
            stats.total += filtered_out_count
            stats.filtered_out += filtered_out_count
            meta = getattr(stats, "meta", None)
            if isinstance(meta, dict):
                meta.setdefault("filtered_by_input_rules", filtered_out_count)
        except Exception:
            pass

        override_cols_runtime = getattr(self, "_override_base_columns_runtime", None)
        override_cols = override_base_columns or override_cols_runtime or getattr(self, "override_base_columns", None)

        if not merge_back:
            merged = result_df
        else:
            merged = merge_new_columns(
                original_df_full,
                result_df,
                base_columns=base_columns,
                field_mapping=field_mapping,
                preserve_base_columns=getattr(self, "preserve_base_columns", None),
                override_base_columns=set(override_cols or []),
            )

        if ctx:
            try:
                ctx.close()
            except Exception:
                pass
        return merged, stats


__all__ = [
    "AnalyticsTask",
    "TaskStats",
    "apply_field_mapping",
]

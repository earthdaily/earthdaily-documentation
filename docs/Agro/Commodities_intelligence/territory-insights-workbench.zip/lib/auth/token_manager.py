"""Token management utilities leveraging the project auth helpers (thread-safe)."""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass


try:  # httpx is preferred but optional; fall back to requests when unavailable.
    import httpx  # type: ignore

    _HTTPX_AVAILABLE = True
except ImportError:  # pragma: no cover - only hit when httpx missing in envs
    httpx = None  # type: ignore[assignment]
    _HTTPX_AVAILABLE = False

import requests


logger = logging.getLogger(__name__)


class TokenRetrievalError(RuntimeError):
    """Raised when the IdentityServer token endpoint cannot be reached or parsed."""


@dataclass
class IdentityTokenManager:
    """
    Simple password-grant token cache with proactive refresh logic.

    Thread-safe: only one refresh can be in flight; other threads wait.
    """

    username: str
    password: str
    refresh_margin_seconds: int = 300  # proactively refresh 5 minutes before expiry
    validity_window_seconds: int = 3600  # IdentityServer issues ~60-minute tokens

    def __post_init__(self) -> None:
        self._cached_token: str | None = None
        self._issued_at: float = 0.0

        # Concurrency primitives
        self._lock = threading.Lock()
        self._refresh_inflight = False
        self._cv = threading.Condition(self._lock)

    @classmethod
    def from_env(cls) -> IdentityTokenManager:
        """Instantiate the manager from IDENTITY_USERNAME / IDENTITY_PASSWORD."""
        username = os.environ.get("IDENTITY_USERNAME")
        password = os.environ.get("IDENTITY_PASSWORD")
        missing = [
            key
            for key, val in {
                "IDENTITY_USERNAME": username,
                "IDENTITY_PASSWORD": password,
            }.items()
            if not val
        ]
        if missing:
            raise RuntimeError(f"Missing environment variables for token generation: {', '.join(missing)}")
        return cls(username=username, password=password)  # type: ignore[arg-type]

    # ---------- Public API ----------

    def get_token(self) -> str:
        """
        Return a cached token, refreshing it when needed.

        - Single-flight refresh: at most one thread refreshes; others wait.
        - Most calls return immediately from cache.
        """
        with self._lock:
            if not self._needs_refresh():
                return self._cached_token  # type: ignore[return-value]

            # Another refresh already running? Wait for it to complete.
            if self._refresh_inflight:
                while self._refresh_inflight:
                    self._cv.wait(timeout=1.0)
                # After wait, check cache again
                if self._cached_token:
                    return self._cached_token
                # Fall through and perform refresh ourselves.

            # Mark refresh in flight
            self._refresh_inflight = True

        # Perform the network call *outside* the lock
        token = self.get_token_from_identity_server(self.username, self.password)
        if not token:
            # Wake up waiters before raising
            with self._lock:
                self._refresh_inflight = False
                self._cv.notify_all()
            raise TokenRetrievalError("IdentityServer did not return an access token")

        now = time.time()
        with self._lock:
            self._cached_token = token
            self._issued_at = now
            self._refresh_inflight = False
            self._cv.notify_all()
            return token

    def invalidate(self) -> None:
        """Force the next call to fetch a fresh token."""
        with self._lock:
            self._cached_token = None
            self._issued_at = 0.0

    # ---------- Internals ----------

    def _needs_refresh(self) -> bool:
        """Return True if the cached token is missing or close to expiry."""
        if not self._cached_token:
            return True
        elapsed = time.time() - self._issued_at
        threshold = self.validity_window_seconds - self.refresh_margin_seconds
        return elapsed >= threshold

    def get_token_from_identity_server(
        self,
        username: str,
        password: str,
        *,
        client_id: str = "swagger",
        client_secret: str = "swagger.secret",
        scope: str = "openid",
        timeout_seconds: float = 30.0,
    ) -> str | None:
        """Password grant for service scenarios (shared across API and notebooks)."""
        token_url = self.derive_identity_token_url()
        try:
            if _HTTPX_AVAILABLE:
                with httpx.Client(timeout=timeout_seconds) as client:  # type: ignore[union-attr]
                    resp = client.post(
                        token_url,
                        data={
                            "grant_type": "password",
                            "scope": scope,
                            "username": username,
                            "password": password,
                            "client_id": client_id,
                            "client_secret": client_secret,
                        },
                    )
            else:
                resp = requests.post(
                    token_url,
                    data={
                        "grant_type": "password",
                        "scope": scope,
                        "username": username,
                        "password": password,
                        "client_id": client_id,
                        "client_secret": client_secret,
                    },
                    timeout=timeout_seconds,
                )
            if resp.status_code == 200:
                data = resp.json()
                token = data.get("access_token")
                return token if isinstance(token, str) else None
            logger.error("IdentityServer token error: %s %s", resp.status_code, resp.text)
            return None
        except Exception as exc:
            logger.error("IdentityServer token exception: %s", exc)
            return None

    def derive_identity_token_url(self) -> str:
        """Derive the IdentityServer token endpoint from environment variables."""
        base = (os.getenv("IDENTITY_SERVER_BASE_URL") or "").rstrip("/")
        legacy = (os.getenv("IDENTITY_SERVER_URL") or "").strip()
        if legacy:
            return legacy
        if base:
            return f"{base}/connect/token"
        raise RuntimeError("Missing IDENTITY_SERVER_BASE_URL (or legacy IDENTITY_SERVER_URL).")

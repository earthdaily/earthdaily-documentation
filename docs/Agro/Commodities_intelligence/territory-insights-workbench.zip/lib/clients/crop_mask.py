"""Crop mask API integration helpers (HTTP client and small utilities)."""

from __future__ import annotations

import logging
import os
import threading
import time
from collections import deque
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..auth.token_manager import IdentityTokenManager
from ..utils.geometry import to_wkt


logger = logging.getLogger("analytics.crop_mask")


# ---------- Timing helpers ----------
def _now_perf() -> float:
    return time.perf_counter()


def _ms(delta: float) -> float:
    return round(delta * 1000.0, 2)


def _p95(values: list[float]) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    idx = max(0, min(len(s) - 1, int(0.95 * (len(s) - 1))))
    return s[idx]


# ---------- Rate limiter (sliding window) ----------
class RateLimiter:
    """Allow at most `max_calls` per `per_seconds` (thread-safe)."""

    def __init__(self, max_calls: int, per_seconds: float = 1.0) -> None:
        self.max_calls = max_calls
        self.per = per_seconds
        self._lock = threading.Lock()
        self._hits: deque[float] = deque()

    def acquire(self) -> None:
        while True:
            with self._lock:
                now = time.monotonic()
                cutoff = now - self.per
                while self._hits and self._hits[0] < cutoff:
                    self._hits.popleft()
                if len(self._hits) < self.max_calls:
                    self._hits.append(now)
                    return
                sleep_for = self._hits[0] + self.per - now
            if sleep_for > 0:
                time.sleep(sleep_for)


# ---------- HTTP session builder ----------
def _build_session(pool_size: int = 256) -> requests.Session:
    s = requests.Session()
    adapter = HTTPAdapter(
        pool_connections=pool_size,
        pool_maxsize=pool_size,
        max_retries=Retry(
            total=2,
            backoff_factor=0.2,
            status_forcelist=(502, 503, 504),
            allowed_methods=frozenset(["GET", "POST", "HEAD", "OPTIONS"]),
            raise_on_status=False,
        ),
        pool_block=True,
    )
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    return s


@dataclass
class CropMaskClient:
    """Lightweight client to call the crop mask / crop id API."""

    api_url: str
    token_manager: IdentityTokenManager
    timeout_seconds: int = 200
    _session: requests.Session | None = None
    _hdr_lock: threading.Lock = threading.Lock()
    _cached_headers: dict[str, str] | None = None
    _hdr_cache_until: float = 0.0

    @classmethod
    def from_env(cls) -> CropMaskClient:
        api_url = os.environ.get("CROP_MASK_API_URL")
        if not api_url:
            raise RuntimeError("Missing environment variable: CROP_MASK_API_URL")
        return cls(api_url=api_url, token_manager=IdentityTokenManager.from_env())

    def _http(self) -> requests.Session:
        if self._session is None:
            self._session = _build_session(pool_size=256)
        return self._session

    def _auth_headers(self) -> dict[str, str]:
        now = time.monotonic()
        with self._hdr_lock:
            if self._cached_headers and now < self._hdr_cache_until:
                return self._cached_headers
            token = self.token_manager.get_token()
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
            self._cached_headers = headers
            self._hdr_cache_until = now + 30.0
            return headers

    def _post(self, json_payload: dict[str, Any], trace: bool = False) -> dict[str, Any]:
        timeouts: tuple[float, float] = (5.0, float(self.timeout_seconds))
        t_send0 = _now_perf()
        headers = self._auth_headers()
        if trace:
            print(f"[CropMaskClient] -> sending POST at {time.time():.2f}")
        logger.debug("CropMask POST url=%s payload=%s", self.api_url, json_payload)
        resp = self._http().post(
            self.api_url,
            headers=headers,
            json=json_payload,
            timeout=timeouts,
        )
        t_send1 = _now_perf()
        try:
            resp.raise_for_status()
        except Exception:
            logger.debug(
                "CropMask POST failed status=%s url=%s payload=%s body=%s",
                resp.status_code,
                self.api_url,
                json_payload,
                resp.text,
            )
            raise
        t_json0 = _now_perf()
        data = resp.json()
        t_json1 = _now_perf()
        logger.debug(
            "CropMask POST done status=%s post_ms=%s json_ms=%s body=%s",
            resp.status_code,
            _ms(t_send1 - t_send0),
            _ms(t_json1 - t_json0),
            data,
        )
        if trace:
            print(f"[CropMaskClient] <- response post={_ms(t_send1 - t_send0)} ms, json={_ms(t_json1 - t_json0)} ms")
        return data

    def fetch_history(
        self,
        geometry_wkt: Any,
        start_year: int,
        end_year: int,
        *,
        target_crop: str | None = None,
        min_percent: int = 50,
        limit_nb_crop: int = 1,
        products: Iterable[str] = ("EndSeason",),
        trace: bool = False,
    ) -> list[dict[str, Any]]:
        """Query the crop mask API and return a filtered chronological list of crops."""
        geometry_wkt = to_wkt(geometry_wkt)
        logger.debug(
            "Fetching crop history start_year=%s end_year=%s min_percent=%s limit=%s products=%s trace=%s",
            start_year,
            end_year,
            min_percent,
            limit_nb_crop,
            products,
            trace,
        )
        payload = {
            "geometryWkt": geometry_wkt,
            "filters": {
                "BeginYear": start_year,
                "EndYear": end_year,
                "Products": list(products),
                "LimitNbCrop": limit_nb_crop,
                "CropMaskPercentMin": min_percent,
            },
        }
        data = self._post(payload, trace=trace)
        parsed = _parse_history_response(data)
        if target_crop:
            parsed = _filter_history_by_crop(parsed, target_crop)
        return parsed


def _parse_history_response(data: dict[str, Any]) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    results_by_year = data.get("resultsByYear") or {}

    for year_str, info in results_by_year.items():
        try:
            year = int(year_str)
        except (TypeError, ValueError):
            continue
        for crop_data in info.get("crops", []):
            results.append(
                {
                    "year": year,
                    "crop_code": crop_data.get("edaCropCode"),
                    "crop_name": crop_data.get("edaCropName"),
                    "percent": crop_data.get("percent"),
                }
            )
    return sorted(results, key=lambda item: item["year"])


def _filter_history_by_crop(history: list[dict[str, Any]], target_crop: str | None) -> list[dict[str, Any]]:
    if not target_crop:
        return list(history)
    target_upper = target_crop.upper()
    return [entry for entry in history if (entry.get("crop_code") or "").upper() == target_upper]


def _history_years_str(history: list[dict[str, Any]]) -> str:
    return "-".join(str(entry["year"]) for entry in history)


def _entry_for_year(history: list[dict[str, Any]], year: int) -> dict[str, Any] | None:
    for entry in history:
        if entry.get("year") == year:
            return entry
    return None


def filter_crop_history_columns(
    df,
    target_crop: str,
    *,
    history_column: str = "crop_history",
    years_column: str = "crop_history_years",
    output_history_column: str | None = "filtered_crop_history",
    output_years_column: str | None = "filtered_crop_history_years",
    inplace: bool = False,
):
    """Return a DataFrame where crop history columns keep only `target_crop` entries."""
    import pandas as pd

    if not target_crop:
        raise ValueError("target_crop must be a non-empty string")
    if not isinstance(df, pd.DataFrame):
        raise TypeError("df must be a pandas DataFrame")
    if history_column not in df.columns:
        raise KeyError(f"Missing history column '{history_column}'")
    if years_column not in df.columns:
        raise KeyError(f"Missing years column '{years_column}'")

    output_history_column = output_history_column or history_column
    output_years_column = output_years_column or years_column
    result = df if inplace else df.copy()

    def _normalize(value: Any) -> list[dict[str, Any]]:
        return value if isinstance(value, list) else []

    filtered = result[history_column].apply(lambda value: _filter_history_by_crop(_normalize(value), target_crop))
    result[output_history_column] = filtered
    result[output_years_column] = filtered.apply(_history_years_str)
    return result


__all__ = ["CropMaskClient", "RateLimiter", "filter_crop_history_columns", "_filter_history_by_crop", "_history_years_str", "_entry_for_year"]

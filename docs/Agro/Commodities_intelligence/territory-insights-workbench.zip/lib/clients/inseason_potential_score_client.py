import logging
import os

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..auth.token_manager import IdentityTokenManager


logger = logging.getLogger("analytics.inseason_potential_score")


class InseasonPotentialScoreClient:
    def __init__(
        self,
        base_url: str,
        timeout: int = 200,
        token_manager: IdentityTokenManager | None = None,
        max_retries: int = 3,
        pool_size: int = 64,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.token_manager = token_manager or IdentityTokenManager.from_env()
        self.max_retries = max_retries
        self.pool_size = pool_size
        self._session: requests.Session | None = None

    @classmethod
    def from_env(cls):
        base_url = os.environ.get("INSEASON_POTENTIAL_SCORE_BASE_URL") or "https://inseason-potential-score.aws-dev.geosys.com/v1"
        pool_size = int(os.environ.get("INSEASON_POTENTIAL_SCORE_POOL_SIZE") or 64)
        return cls(base_url=base_url, pool_size=pool_size)

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token_manager.get_token()}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _http(self) -> requests.Session:
        if self._session is None:
            session = requests.Session()
            adapter = HTTPAdapter(
                max_retries=Retry(
                    total=self.max_retries,
                    backoff_factor=1,
                    status_forcelist=(429, 500, 502, 503, 504),
                    allowed_methods=frozenset(["GET", "POST", "PUT", "PATCH", "DELETE"]),
                    raise_on_status=False,
                ),
                pool_connections=self.pool_size,
                pool_maxsize=self.pool_size,
                pool_block=True,
            )
            session.mount("https://", adapter)
            session.mount("http://", adapter)
            self._session = session
        return self._session

    def call(self, payload: dict, query: dict | None = None):
        url = f"{self.base_url}/launch"
        clean_body = {k: v for k, v in (payload or {}).items() if v is not None}
        clean_query = {k: v for k, v in (query or {}).items() if v is not None}
        logger.debug("InseasonPotentialScore request url=%s payload=%s query=%s", url, clean_body, clean_query)
        resp = self._http().post(url, json=clean_body, params=clean_query, headers=self._headers(), timeout=self.timeout)
        try:
            body_preview = resp.json()
        except Exception:
            body_preview = resp.text
        logger.debug("InseasonPotentialScore response status=%s body=%s", resp.status_code, body_preview)
        try:
            resp.raise_for_status()
        except requests.HTTPError:
            logger.debug(
                "InseasonPotentialScore error status=%s body=%s payload=%s query=%s",
                resp.status_code,
                resp.text,
                clean_body,
                clean_query,
            )
            raise
        return resp.json()

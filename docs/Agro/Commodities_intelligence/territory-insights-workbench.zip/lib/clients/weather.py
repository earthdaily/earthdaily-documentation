"""Weather analytics helpers used in the weekly analytics notebook.

The goal of this module is to provide a high-level helper similar to the
``emergence`` helpers: the notebook passes a dataframe of spatial units, the
client batches calls to the Weather API (deduplicated per geohash / planting
date) and writes results back into the dataframe, checkpointing progress to a
temporary parquet file when requested.
"""

from __future__ import annotations

import json
import logging
import os
import re
import runpy
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from functools import lru_cache
from pathlib import Path
from typing import Any

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from shapely import wkt as shapely_wkt
from shapely.geometry import shape
from urllib3.util.retry import Retry

from ..auth.token_manager import IdentityTokenManager
from ..domain.crop_cycle import parse_state_county


logger = logging.getLogger("analytics.weather")

# Legacy config produced by the notebook embedded in tmp/03-Analytic_computation.
_LEGACY_CONFIG_PATH = Path(__file__).resolve().parents[2] / "config/weather_file_config.py"


class WeatherApiError(RuntimeError):
    """Raised when the Weather API responds with an error."""


def _ensure_datetime(value: date | datetime) -> datetime:
    """Return a ``datetime`` (UTC) for ``value``."""
    if isinstance(value, datetime):
        return value
    return datetime.combine(value, datetime.min.time())


def _format_instant(value: date | datetime) -> str:
    """Format a date/datetime into the string expected by the Weather API."""
    instant = _ensure_datetime(value)
    return instant.strftime("%Y-%m-%dT%H:%M:%S.0000000Z")


def _parse_iso_date(raw: str | None) -> date | None:
    """Parse an ISO 8601 date (or datetime) into a ``date``."""
    if not raw:
        return None
    text = raw.replace("Z", "")
    try:
        return datetime.fromisoformat(text).date()
    except ValueError:
        try:
            return datetime.strptime(text[:10], "%Y-%m-%d").date()
        except ValueError:
            logger.debug("Unable to parse weather date %s", raw)
            return None


def _geometry_to_point_wkt(value: Any) -> str:
    """Convert various geometry representations to a Point WKT string."""
    geometry = None
    if isinstance(value, str):
        value = value.strip()
        if value.startswith("{"):
            try:
                geometry = shape(json.loads(value))
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid GeoJSON geometry: {value}") from exc
        else:
            try:
                geometry = shapely_wkt.loads(value)
            except Exception as exc:  # pragma: no cover - defensive parsing
                raise ValueError(f"Invalid WKT geometry: {value}") from exc
    elif hasattr(value, "__geo_interface__"):
        geometry = shape(value.__geo_interface__)  # type: ignore[arg-type]
    if geometry is None:
        raise ValueError("Unsupported geometry value")
    if geometry.is_empty:
        raise ValueError("Empty geometry")
    if geometry.geom_type != "Point":
        geometry = geometry.centroid
    if geometry.is_empty or geometry.geom_type != "Point":
        raise ValueError("Unable to derive centroid point")
    return geometry.wkt


_REGION_NORMALIZER = re.compile(r"[^a-z0-9_]")
MAX_FORECAST_LOOKAHEAD_DAYS = 10  # API limitation: forecast includes today + 9 days


@lru_cache
def load_legacy_weather_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load the historic ``file_config.py`` structure from ``tmp`` and cache it.

    The file contains agronomist-provided knobs (planting delays, phenological
    stage offsets, etc.) used by previous notebooks. Keeping it in Python form
    allows users to continue editing it without migrating to JSON yet.
    """
    config_path = Path(path or _LEGACY_CONFIG_PATH)
    if not config_path.exists():
        raise FileNotFoundError(f"Weather legacy config not found: {config_path}")
    data = runpy.run_path(str(config_path))
    return {
        "planting_delay_day_counties": data.get("planting_delay_day_counties", {}),
        "phenological_stages_counties": data.get("phenological_stages_counties", {}),
    }


def get_stage_offsets_for_region(region: str, *, config_path: str | Path | None = None) -> Mapping[str, Sequence[int]]:
    """Return tasseling/R3/... offsets for ``region`` using the legacy config."""
    config = load_legacy_weather_config(config_path)
    stage_config = config["phenological_stages_counties"]
    if region not in stage_config:
        available = ", ".join(sorted(stage_config.keys()))
        raise KeyError(f"No stage offsets for '{region}'. Available: {available}")
    return stage_config[region]


def get_planting_delay_for_region(
    region: str,
    year: int,
    *,
    config_path: str | Path | None = None,
) -> int | None:
    """Return the emergence→planting lag (in days) defined for ``region``."""
    config = load_legacy_weather_config(config_path)
    delays = config["planting_delay_day_counties"].get(region)
    if not delays:
        return None
    return delays.get(int(year))


def normalize_weather_region_label(value: str | None) -> str:
    """Return a canonical version of a county/state label for lookup purposes."""
    if not value:
        return ""
    return _REGION_NORMALIZER.sub("", str(value).strip().lower().replace(" ", "_"))


def _build_region_registry(stage_config: Mapping[str, Any]) -> dict[str, str]:
    """Return a normalization map to match manual inputs to config keys."""
    return {normalize_weather_region_label(key): key for key in stage_config.keys()}


def resolve_weather_region_label(
    label: str | None,
    *,
    default_region: str,
    stage_config: Mapping[str, Any] | None = None,
    registry: Mapping[str, str] | None = None,
) -> str:
    """Resolve a free-form county/state label to the canonical config key."""
    if not stage_config:
        stage_config = load_legacy_weather_config()["phenological_stages_counties"]
    registry = registry or _build_region_registry(stage_config)
    if not isinstance(label, str) or not label.strip():
        return default_region
    try:
        state_code, county_name = parse_state_county(label)
    except Exception:
        state_code, county_name = None, None
    candidates = [label]
    if county_name:
        candidates.extend(
            [
                county_name,
                county_name.replace(" ", "_"),
            ]
        )
    if county_name and state_code:
        candidates.extend(
            [
                f"{county_name}_{state_code}",
                f"{county_name.replace(' ', '_')}_{state_code}",
            ]
        )
    for candidate in candidates:
        normalized = normalize_weather_region_label(candidate)
        if normalized in registry:
            return registry[normalized]
    return default_region


def assign_weather_regions(
    df: pd.DataFrame,
    *,
    label_column: str = "n_county",
    default_region: str = "Dodge",
    config_path: str | Path | None = None,
) -> pd.Series:
    """Return a Series containing the resolved weather region per row."""
    config = load_legacy_weather_config(config_path)
    stage_config = config["phenological_stages_counties"]
    registry = _build_region_registry(stage_config)

    def _resolver(value: Any) -> str:
        return resolve_weather_region_label(
            str(value) if value is not None else None,
            default_region=default_region,
            stage_config=stage_config,
            registry=registry,
        )

    if label_column not in df.columns:
        return pd.Series(default_region, index=df.index, dtype="object")
    return df[label_column].apply(_resolver)


def derive_planting_dates(
    df: pd.DataFrame,
    *,
    planting_column: str = "planting_date",
    emergence_column: str = "emergence_date",
    region_column: str = "weather_region",
    default_region: str = "Dodge",
    config_path: str | Path | None = None,
    override_existing: bool = False,
) -> pd.Series:
    """Fill or recompute planting dates using emergence + legacy delays.

    When ``override_existing`` is True, planting dates are recomputed from emergence
    when available; otherwise existing planting values are preserved.
    """
    config = load_legacy_weather_config(config_path)

    def _compute(row: pd.Series) -> pd.Timestamp | pd.NaT:
        planting_value = row.get(planting_column)
        if pd.notna(planting_value) and not override_existing:
            planting_ts = pd.to_datetime(planting_value, errors="coerce")
            return planting_ts
        emergence_value = row.get(emergence_column)
        if pd.isna(emergence_value):
            # When overriding, do NOT retain legacy planting dates if emergence is absent.
            return pd.NaT
        emergence_ts = pd.to_datetime(emergence_value, errors="coerce")
        if pd.isna(emergence_ts):
            return pd.NaT
        region_key = row.get(region_column) or default_region
        delay_days = get_planting_delay_for_region(region_key, emergence_ts.year, config_path=config_path)
        if not delay_days:
            return pd.NaT
        return emergence_ts - pd.to_timedelta(delay_days, unit="D")

    return df.apply(_compute, axis=1)


@dataclass
class WeatherApiClient:
    """Thin wrapper around the Weather API with IdentityServer auth."""

    base_url: str
    token_manager: IdentityTokenManager
    timeout_seconds: int = 500
    max_retries: int = 3
    pool_size: int = 64
    _session: requests.Session = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")
        self._session = requests.Session()
        retry = Retry(total=self.max_retries, backoff_factor=1.5, status_forcelist=[429, 500, 502, 503, 504])
        adapter = HTTPAdapter(
            max_retries=retry,
            pool_connections=self.pool_size,
            pool_maxsize=self.pool_size,
            pool_block=True,
        )
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

    @classmethod
    def from_env(
        cls,
        *,
        token_manager: IdentityTokenManager | None = None,
        base_url_env: str = "WEATHER_API_BASE_URL",
    ) -> WeatherApiClient:
        """Instantiate the client from env vars."""
        base_url = os.environ.get(base_url_env) or "https://api.geosys-na.net/weather/v1"
        manager = token_manager or IdentityTokenManager.from_env()
        return cls(base_url=base_url, token_manager=manager)

    def _authorized_headers(self) -> dict[str, str]:
        token = self.token_manager.get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }

    def _request(self, path: str, params: Sequence[tuple[str, Any]] | Mapping[str, Any]) -> Any:
        url = path if path.startswith("http") else f"{self.base_url}/{path.lstrip('/')}"
        if isinstance(params, Mapping):
            query = list(params.items())
        else:
            query = list(params)
        attempt = 0
        while True:
            attempt += 1
            logger.debug("Weather API GET %s attempt=%s params=%s", url, attempt, query)
            response = self._session.get(
                url,
                params=query,
                headers=self._authorized_headers(),
                timeout=self.timeout_seconds,
            )
            if response.status_code == 401 and attempt <= self.max_retries:
                logger.debug("Weather API 401; refreshing token and retrying")
                self.token_manager.invalidate()
                time.sleep(0.5)
                continue
            try:
                response.raise_for_status()
                return response.json()
            except requests.HTTPError as exc:
                logger.debug(
                    "Weather API request failed status=%s url=%s body=%s params=%s attempt=%s/%s",
                    response.status_code,
                    response.url,
                    response.text[:250],
                    query,
                    attempt,
                    self.max_retries,
                )
                if attempt >= self.max_retries:
                    raise WeatherApiError(f"Weather API error ({response.status_code}): {response.text}") from exc
                backoff = min(4.0, 0.5 * attempt)
                time.sleep(backoff)

    def get_stage_offsets(
        self,
        *,
        location_wkt: str,
        planting_date: date,
        provider: str,
        lower_threshold: float,
        upper_threshold: float,
        stage_offsets: Mapping[str, Sequence[int]],
    ) -> dict[str, list[date]]:
        """Fetch phenological stage predictions."""
        if not stage_offsets:
            return {}
        params: list[tuple[str, Any]] = [
            ("Date", planting_date.isoformat()),
            ("Provider", provider),
            ("Location", location_wkt),
            ("LowerThreshold", lower_threshold),
            ("UpperThreshold", upper_threshold),
        ]
        unique_offsets: list[int] = []
        for stage, offsets in stage_offsets.items():
            for offset in offsets:
                value = int(offset)
                if value not in unique_offsets:
                    unique_offsets.append(value)
                    params.append(("Offsets", value))
        payload = self._request("analytics/gdd-offset", params)
        offset_dates: dict[int, date] = {}
        for entry in payload or []:
            offset = entry.get("offset")
            parsed_date = _parse_iso_date(entry.get("date"))
            if offset is None or parsed_date is None:
                continue
            offset_dates[int(offset)] = parsed_date
        stage_dates: dict[str, list[date]] = {}
        for stage, offsets in stage_offsets.items():
            ordered_dates: list[date] = []
            for offset in offsets:
                date_value = offset_dates.get(int(offset))
                if date_value:
                    ordered_dates.append(date_value)
            stage_dates[stage] = ordered_dates
        return stage_dates

    def get_gdd_accumulation(
        self,
        *,
        location_wkt: str,
        provider: str,
        lower_threshold: float,
        upper_threshold: float,
        start_date: date,
        end_date: date,
    ) -> float | None:
        """Return the cumulated GDD between ``start_date`` and ``end_date``."""
        params = [
            ("StartDate", start_date.isoformat()),
            ("LastDate", end_date.isoformat()),
            ("Provider", provider),
            ("Location", location_wkt),
            ("LowerThreshold", lower_threshold),
            ("UpperThreshold", upper_threshold),
            ("$count", "false"),
            ("$limit", 5000),
        ]
        data = self._request("analytics/gdd", params)
        elements = (data or {}).get("elements") or []
        if not elements:
            return None
        last = elements[-1]
        value = last.get("cumulatedGrowingDegreeDay")
        return round(float(value), 2) if value is not None else None

    def get_avg_gdd_accumulation(
        self,
        *,
        location_wkt: str,
        provider: str,
        lower_threshold: float,
        upper_threshold: float,
        start_date: date,
        end_date: date,
        average_years: int,
    ) -> float | None:
        """Return the average GDD accumulation across preceding years."""
        historical_start = start_date - timedelta(days=average_years * 365)
        params = [
            ("StartDate", historical_start.isoformat()),
            ("LastDate", end_date.isoformat()),
            ("Provider", provider),
            ("Location", location_wkt),
            ("LowerThreshold", lower_threshold),
            ("UpperThreshold", upper_threshold),
            ("$count", "false"),
            ("$limit", 5000),
        ]
        data = self._request("analytics/gdd", params)
        elements = (data or {}).get("elements") or []
        yearly: dict[int, float] = {}
        for entry in elements:
            parsed_date = _parse_iso_date(entry.get("date"))
            if not parsed_date:
                continue
            year = parsed_date.year
            shifted_start = start_date.replace(year=year)
            shifted_end = end_date.replace(year=year)
            if shifted_start <= parsed_date <= shifted_end:
                yearly.setdefault(year, 0.0)
                try:
                    yearly[year] += float(entry.get("dailyGrowingDegreeDay") or 0.0)
                except (TypeError, ValueError):
                    continue
        if not yearly:
            return None
        values = list(yearly.values())
        return round(sum(values) / len(values), 2)

    def get_rainfall_accumulation(
        self,
        *,
        location_wkt: str,
        provider: str,
        weather_type: str,
        start_date: date,
        end_date: date,
    ) -> float | None:
        """Return rainfall accumulation between two dates."""
        between = f"$between:{_format_instant(start_date)}|{_format_instant(end_date)}"
        params = [
            ("$offset", 0),
            ("$count", "false"),
            ("$limit", 5000),
            ("$fields", "precipitation.cumulative,date"),
            ("Provider", provider),
            ("WeatherType", weather_type),
            ("Location", location_wkt),
            ("Date", between),
        ]
        data = self._request("weather", params)
        if not data:
            return None
        total = 0.0
        for entry in data:
            parsed_date = _parse_iso_date(entry.get("date"))
            if parsed_date and start_date <= parsed_date <= end_date:
                try:
                    total += float(entry.get("precipitation", {}).get("cumulative") or 0.0)
                except (TypeError, ValueError):
                    continue
        return round(total, 2)

    def get_avg_rainfall_accumulation(
        self,
        *,
        location_wkt: str,
        provider: str,
        start_date: date,
        end_date: date,
        average_years: int,
    ) -> float | None:
        """Return the mean rainfall accumulation for the historic window."""
        historical_start = start_date - timedelta(days=average_years * 365)
        between = f"$between:{_format_instant(historical_start)}|{_format_instant(end_date)}"
        params = [
            ("$offset", 0),
            ("$count", "false"),
            ("$limit", 10000),
            ("$fields", "precipitation.cumulative,date"),
            ("Provider", provider),
            ("WeatherType", "HISTORICAL_DAILY"),
            ("Location", location_wkt),
            ("Date", between),
        ]
        data = self._request("weather", params)
        yearly: dict[int, float] = {}
        for entry in data or []:
            parsed_date = _parse_iso_date(entry.get("date"))
            if not parsed_date:
                continue
            year = parsed_date.year
            year_start = start_date.replace(year=year)
            year_end = end_date.replace(year=year)
            if year_start <= parsed_date <= year_end:
                yearly.setdefault(year, 0.0)
                try:
                    yearly[year] += float(entry.get("precipitation", {}).get("cumulative") or 0.0)
                except (TypeError, ValueError):
                    continue
        if not yearly:
            return None
        values = list(yearly.values())
        return round(sum(values) / len(values), 2)


__all__ = [
    "WeatherApiClient",
    "WeatherApiError",
    "load_legacy_weather_config",
    "get_stage_offsets_for_region",
    "get_planting_delay_for_region",
    "normalize_weather_region_label",
    "resolve_weather_region_label",
    "assign_weather_regions",
    "derive_planting_dates",
    "_geometry_to_point_wkt",
]

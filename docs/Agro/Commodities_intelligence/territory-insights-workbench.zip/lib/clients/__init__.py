"""Convenience re-exports for client modules (HTTP/API helpers)."""

from .api_client import ApiError, ApiSession
from .crop_mask import CropMaskClient, filter_crop_history_columns
from .emergence import EmergenceProcessor
from .lri import LriClient
from .weather import (
    assign_weather_regions,
    derive_planting_dates,
    get_planting_delay_for_region,
    get_stage_offsets_for_region,
    WeatherApiClient,
    WeatherApiError,
)


__all__ = [
    "ApiSession",
    "ApiError",
    "CropMaskClient",
    "filter_crop_history_columns",
    "LriClient",
    "EmergenceProcessor",
    "WeatherApiClient",
    "WeatherApiError",
    "assign_weather_regions",
    "derive_planting_dates",
    "get_stage_offsets_for_region",
    "get_planting_delay_for_region",
]

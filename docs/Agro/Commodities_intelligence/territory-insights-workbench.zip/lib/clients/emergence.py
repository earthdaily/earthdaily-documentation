"""Emergence HTTP client (minimal)."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..auth.token_manager import IdentityTokenManager
from ..utils.geometry import to_wkt


logger = logging.getLogger("analytics.emergence")


def _snake_to_camel(value: str) -> str:
    parts = value.split("_")
    return parts[0] + "".join(part.capitalize() for part in parts[1:])


def _camelize_dict(data: dict[str, Any]) -> dict[str, Any]:
    return {_snake_to_camel(k): v for k, v in data.items()}


@dataclass
class EmergenceProcessor:
    """Small client dedicated to the Emergence processors (geometry mode)."""

    base_url: str
    token_manager: IdentityTokenManager
    timeout_seconds: int = 300
    max_retries: int = 3
    pool_size: int = 64

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")
        self._session = requests.Session()
        retry = Retry(total=self.max_retries, backoff_factor=1.5, status_forcelist=[429, 500, 502, 503, 504])
        adapter = HTTPAdapter(
            max_retries=retry,
            pool_connections=self.pool_size,
            pool_maxsize=self.pool_size,
            pool_block=True,
        )
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

    @classmethod
    def from_env(cls) -> EmergenceProcessor:
        base_url = os.environ.get("EMERGENCE_BASE_URL") or os.environ.get("EMERGENCE_API_URL")
        if not base_url:
            raise RuntimeError("Missing EMERGENCE_BASE_URL environment variable")
        return cls(base_url=base_url, token_manager=IdentityTokenManager.from_env())

    def _authorized_headers(self) -> dict[str, str]:
        token = self.token_manager.get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _post(self, path: str, params: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = self._authorized_headers()
        clean_params = {k: v for k, v in params.items() if v is not None}
        clean_payload = {k: v for k, v in payload.items() if v is not None}
        logger.debug("Emergence request url=%s params=%s payload=%s", url, clean_params, clean_payload)
        response = self._session.post(
            url,
            params=_camelize_dict(clean_params),
            json=_camelize_dict(clean_payload),
            headers=headers,
            timeout=self.timeout_seconds,
        )
        try:
            response.raise_for_status()
            data = response.json()
            logger.debug("Emergence response status=%s body=%s", response.status_code, data)
            return data
        except requests.HTTPError as exc:
            logger.debug(
                "Emergence POST %s failed status=%s body=%s payload=%s query=%s",
                path,
                response.status_code,
                response.text,
                clean_payload,
                clean_params,
            )
            raise RuntimeError(f"Emergence API failed ({response.status_code}): {response.text}") from exc

    def compute_inseason(
        self,
        *,
        geometry_wkt: Any,
        crop: str,
        season_duration: int,
        season_start_day: int,
        season_start_month: int,
        year: int,
        data_source: str | None = None,
        force_lri_cache: bool = False,
        emergence_type: str = "INSEASON",
    ) -> dict[str, Any]:
        """Call the emergence processor in INSEASON mode and return the raw JSON."""
        params = {
            "emergence_type": emergence_type,
            "crop": crop,
            "season_duration": season_duration,
            "season_start_day": season_start_day,
            "season_start_month": season_start_month,
            "year": year,
            "data_source": data_source,
            "force_lri_cache": force_lri_cache,
        }
        geometry_wkt = to_wkt(geometry_wkt)
        payload = {
            "geometry": str(geometry_wkt),
            "id": "",
        }
        return self._post("/launch", params=params, payload=payload)


__all__ = ["EmergenceProcessor"]

"""LRI API client (NDVI time series)."""

from __future__ import annotations

import logging
import os
import threading
from datetime import date, datetime
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..utils.geometry import to_wkt


logger = logging.getLogger("analytics.lri")


def _build_session(pool_size: int = 64) -> requests.Session:
    session = requests.Session()
    adapter = HTTPAdapter(
        pool_connections=pool_size,
        pool_maxsize=pool_size,
        max_retries=Retry(
            total=2,
            backoff_factor=0.2,
            status_forcelist=(502, 503, 504),
            allowed_methods=frozenset(["GET", "POST", "HEAD", "OPTIONS"]),
            raise_on_status=False,
        ),
        pool_block=True,
    )
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


def _to_date_str(value: date | datetime | str) -> str:
    if isinstance(value, (date, datetime)):
        return value.date().isoformat() if isinstance(value, datetime) else value.isoformat()
    return str(value)


class LriClient:
    """Lightweight client to call the LRI filtered geometry endpoint."""

    def __init__(self, api_url: str, api_key: str, timeout_seconds: int = 300) -> None:
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self._session: requests.Session | None = None
        self._token_lock = threading.Lock()

    @classmethod
    def from_env(cls) -> LriClient:
        api_url = os.environ.get("LRI_API_URL")
        api_key = os.environ.get("LRI_KEY")
        if not api_url:
            raise RuntimeError("Missing environment variable: LRI_API_URL")
        if not api_key:
            raise RuntimeError("Missing environment variable: LRI_KEY")
        return cls(api_url=api_url, api_key=api_key)

    def _http(self) -> requests.Session:
        if self._session is None:
            self._session = _build_session(pool_size=128)
        return self._session

    def fetch_ndvi(
        self,
        geometry_wkt: Any,
        start_date: date | datetime | str,
        end_date: date | datetime | str,
        *,
        indicator: str = "ndvi",
        smoother: str = "WEIGHTED_WHITTAKER",
        is_coverage_extended: bool = False,
        use_pixel_cold_db: bool = True,
        geometry_wkt_param: bool = False,
        trace: bool = False,
    ) -> list[dict[str, Any]]:
        """Query NDVI time series for a single geometry."""
        payload = [{"identifier": 0, "wkt": to_wkt(geometry_wkt)}]
        params = self._build_params(
            start_date=start_date,
            end_date=end_date,
            indicator=indicator,
            smoother=smoother,
            is_coverage_extended=is_coverage_extended,
            use_pixel_cold_db=use_pixel_cold_db,
            geometry_wkt_param=geometry_wkt_param,
        )
        data = self._post(payload, params=params, trace=trace)
        return self._parse_response(data, indicator=indicator).get(0, [])

    def fetch_ndvi_batch(
        self,
        items: list[dict[str, Any]] | Any,
        start_date: date | datetime | str,
        end_date: date | datetime | str,
        *,
        indicator: str = "ndvi",
        smoother: str = "WEIGHTED_WHITTAKER",
        is_coverage_extended: bool = False,
        use_pixel_cold_db: bool = True,
        geometry_wkt_param: bool = False,
        trace: bool = False,
    ) -> dict[Any, list[dict[str, Any]]]:
        """Batch NDVI query for multiple geometries (identifier -> rows)."""
        payload: list[dict[str, Any]] = []
        for item in items:
            ident = item.get("identifier") if isinstance(item, dict) else None
            geom_val = item.get("wkt") if isinstance(item, dict) else None
            if ident is None or geom_val is None:
                continue
            try:
                ident_int = int(ident)
            except Exception:
                continue
            payload.append({"identifier": ident_int, "wkt": to_wkt(geom_val)})
        if not payload:
            return {}
        params = self._build_params(
            start_date=start_date,
            end_date=end_date,
            indicator=indicator,
            smoother=smoother,
            is_coverage_extended=is_coverage_extended,
            use_pixel_cold_db=use_pixel_cold_db,
            geometry_wkt_param=geometry_wkt_param,
        )
        data = self._post(payload, params=params, trace=trace)
        return self._parse_response(data, indicator=indicator)

    def _build_params(
        self,
        *,
        start_date: date | datetime | str,
        end_date: date | datetime | str,
        indicator: str,
        smoother: str,
        is_coverage_extended: bool,
        use_pixel_cold_db: bool,
        geometry_wkt_param: bool,
    ) -> dict[str, Any]:
        return {
            "isCoverageExtended": str(is_coverage_extended).lower(),
            "indicators": indicator,
            "start": _to_date_str(start_date),
            "end": _to_date_str(end_date),
            "geometryWkt": str(bool(geometry_wkt_param)).lower(),
            "smoother": smoother,
            "usePixelColdDB": str(use_pixel_cold_db).lower(),
            "key": self.api_key,
        }

    def _post(self, payload: list[dict[str, Any]], params: dict[str, Any], trace: bool = False) -> Any:
        logger.debug(
            "[LRI] POST url=%s params=%s payload_size=%d indicator=%s",
            self.api_url,
            params,
            len(payload),
            params.get("indicators"),
        )
        resp = self._http().post(
            self.api_url,
            params=params,
            json=payload,
            timeout=self.timeout_seconds,
        )
        try:
            resp.raise_for_status()
        except Exception:
            logger.debug(
                "[LRI] POST failed status=%s url=%s payload_size=%d body=%s",
                resp.status_code,
                self.api_url,
                len(payload),
                resp.text,
            )
            raise
        logger.debug("[LRI] response status=%s", resp.status_code)
        try:
            body_preview = resp.json()
        except Exception:
            body_preview = resp.text
        logger.debug("[LRI] response body=%s", body_preview if trace else str(body_preview)[:300])
        return body_preview or []

    def _parse_response(self, data: Any, *, indicator: str) -> dict[Any, list[dict[str, Any]]]:
        if not isinstance(data, list):
            return {}
        parsed: dict[Any, list[dict[str, Any]]] = {}
        for item in data:
            geom_meta = item.get("geometry", {}) or {}
            ident = geom_meta.get("identifier")
            rows: list[dict[str, Any]] = []
            for row in item.get("data", []) or []:
                value = row.get("value") or {}
                rows.append(
                    {
                        "date": row.get("date"),
                        "ndvi": value.get(indicator),
                        "observed": row.get("observed"),
                        "nrPixel": row.get("nrPixel"),
                        "nrClearPixel": row.get("nrClearPixel"),
                    }
                )
            parsed[ident] = rows
        return parsed


__all__ = ["LriClient"]

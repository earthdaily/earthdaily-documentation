"""Minimal API client reused in the notebooks.

The helpers here intentionally avoid depending on the rest of the repository so that the
notebooks can be shipped independently.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

import requests

from ..auth.token_manager import IdentityTokenManager


class ApiError(RuntimeError):
    """Raised when the backend API responds with a non-success status."""


@dataclass
class ApiSession:
    """Thin wrapper around ``requests`` with automatic IdentityServer authentication."""

    base_url: str
    token_manager: IdentityTokenManager
    timeout: int = 60

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")

    @classmethod
    def from_env(cls) -> ApiSession:
        """Build a session using the environment variables declared in ``.env``."""
        base_url = os.environ.get("API_BASE_URL")
        if not base_url:
            raise RuntimeError("Missing environment variable: API_BASE_URL")
        token_manager = IdentityTokenManager.from_env()
        return cls(base_url=base_url, token_manager=token_manager)

    def _authorized_headers(self) -> dict[str, str]:
        """Return the Authorization headers populated with the cached token."""
        token = self.token_manager.get_token()
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "accept": "application/json"}

    def request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Call the API relative ``path`` and return the decoded JSON payload."""
        url = f"{self.base_url}{path}"
        resp = requests.request(
            method=method,
            url=url,
            headers=self._authorized_headers(),
            json=json,
            params=params,
            timeout=self.timeout,
        )
        if resp.status_code >= 400:
            raise ApiError(f"{method} {url} failed: {resp.status_code} {resp.text}")
        if resp.content:
            return resp.json()
        return None

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Shortcut for ``request('GET', ...)`` with optional query params."""
        return self.request("GET", path, params=params)

    def post(self, path: str, *, json: dict[str, Any] | None = None, params: dict[str, Any] | None = None) -> Any:
        """Shortcut for `request('POST', ...)` with optional query params and JSON body."""
        return self.request("POST", path, json=json, params=params)

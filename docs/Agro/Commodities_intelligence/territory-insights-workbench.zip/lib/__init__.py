"""Helper modules shared across notebooks."""

# Structured namespaces for easier discovery
from . import analytics, auth, clients, domain, utils
from .auth.token_manager import IdentityTokenManager
from .clients.api_client import ApiSession
from .clients.crop_mask import CropMaskClient, filter_crop_history_columns
from .clients.emergence import EmergenceProcessor
from .clients.lri import LriClient
from .clients.weather import (
    assign_weather_regions,
    derive_planting_dates,
    get_planting_delay_for_region,
    get_stage_offsets_for_region,
    load_legacy_weather_config,
    normalize_weather_region_label,
    resolve_weather_region_label,
    WeatherApiClient,
    WeatherApiError,
)
from .domain.crop_cycle import CropCycleCatalog, CropCycleConfig, parse_state_county
from .utils.jobs import wait_for_job
from .utils.map_preview import items_to_geoms, preview_geometries_map

# Backward-compatible re-exports
from .utils.storage import download_parquet_to_df, load_local_parquet, publish_group_artifact, write_geo_parquet


__all__ = [
    "ApiSession",
    "CropCycleCatalog",
    "CropCycleConfig",
    "parse_state_county",
    "CropMaskClient",
    "EmergenceProcessor",
    "filter_crop_history_columns",
    "preview_geometries_map",
    "items_to_geoms",
    "wait_for_job",
    "download_parquet_to_df",
    "write_geo_parquet",
    "load_local_parquet",
    "publish_group_artifact",
    "IdentityTokenManager",
    "WeatherApiClient",
    "WeatherApiError",
    "load_legacy_weather_config",
    "get_stage_offsets_for_region",
    "get_planting_delay_for_region",
    "assign_weather_regions",
    "derive_planting_dates",
    "normalize_weather_region_label",
    "resolve_weather_region_label",
    "LriClient",
]

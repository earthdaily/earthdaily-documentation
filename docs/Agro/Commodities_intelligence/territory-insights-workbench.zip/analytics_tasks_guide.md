# Analytics Tasks Guide

This guide explains how to add a new analytics task and plug it into the registry so that notebooks and generic callers get consistent behavior (field mapping, progress, checkpoints). A fast-path checklist for non-devs is included below.

**Model in use:** tasks orchestrate everything (mapping, pre/post processing, parallelism, signatures/caches, stats); clients are minimal HTTP wrappers. Legacy helpers (`compute_weather_metrics`, `enrich_with_emergence`, etc.) have been removed from v2 clients.

## Fast path (10 minutes, copy/paste)
1) Duplicate a task: copy `lib/analytics/tasks/weather_task.py` to `lib/analytics/tasks/my_task.py` and keep the skeleton (class + bindings function).
2) Rename class/binding key: change `WeatherTask` → `MyTask`, binding key to `"my_task"`, and adjust required columns in `default_my_task_bindings`.
3) Registry: import `MyTask`/`default_my_task_bindings` in `lib/analytics/registry.py` and add a `register_binding(...)` entry (copy an existing block).
4) Export: add the imports to `lib/analytics/tasks/__init__.py` and `lib/analytics/__init__.py` so notebooks can `from lib.analytics import ...`.
5) Run: in a notebook, call `run_task(df, binding_key="my_task", task_params={...})` and check that columns appear. Use `field_mapping_override` if your dataframe columns differ. To export failing rows per run, set `error_csv_path="tmp/errors/my_task_errors.csv"` (overwritten each call).
6) Optional: add a Pydantic params model in `lib/analytics/params.py` for validation, then set `param_schema=MyParams` in the registry entry.

### Input cleansing (generic)
- Use `apply_input_rules` (lib/analytics/utils.py) to coerce dates (`coerce="datetime"` + `min_year`) and skip rows when a column hits a sentinel (`invalid_values`).
- The helper returns `(clean_df, skipped_mask)`; set `skip_row=True` (default) to count skipped rows in stats (`filtered_out`). Skipped rows are not dropped from the merged output.
- Example rules: `{"column": "sowingDate", "coerce": "datetime", "min_year": 1900, "invalid_values": ["0001-01-01"], "skip_row": True}` or `{"column": "status", "invalid_values": ["no_emergence"], "skip_row": True}`.

## 1) Base class expectations
- Inherit from `AnalyticsTask` (in `base.py`).
- Implement `execute(self, df: pd.DataFrame, **kwargs) -> tuple[pd.DataFrame, TaskStats]`.
- `run(...)` is already provided: it handles field mapping, passthrough columns, default values, merging back to the original dataframe, progress bar, and checkpoints.
- You receive in `execute`:
  - `_original_df`: copy of the caller’s dataframe (pre-normalization).
  - `_field_mapping`: the mapping applied.
  - `_base_columns`: the normalized base columns.
  - `_context`: the `TaskContext` (handles progress/checkpoints if you do not override progress).
  - `_checkpoint`: function to call with `n` and an optional `snapshot` to trigger checkpoint writes respecting `checkpoint_frequency`.

### Progress/checkpoints defaults
- By default, the base class shows a progress bar (`tqdm`) and will write one checkpoint at the end if `checkpoint_path` is provided.
- To get periodic checkpoints, call `_checkpoint(n, snapshot=df_slice)` as you process rows. The `TaskContext` keeps count and writes every `checkpoint_frequency` rows.
- If your task/client already manages its own progress bar, set `use_internal_progress = True` on the class. Progress remains internal, but checkpoints still work via `_checkpoint`.
- If your task pushes its own `_checkpoint` updates, set `auto_context_update = False` to avoid a duplicate final update.

## 2) Task skeleton (copy/paste)
Create `lib/analytics/tasks/my_task.py`:
```python
from dataclasses import dataclass
import pandas as pd
from ..base import AnalyticsTask, TaskStats

@dataclass
class MyTask(AnalyticsTask):
    progress_desc: str = "My analytics"
    checkpoint_path: str | None = None
    checkpoint_frequency: int = 200  # adjust as needed

    def execute(self, df: pd.DataFrame, **kwargs) -> tuple[pd.DataFrame, TaskStats]:
        # df columns are already normalized per field mapping
        if df.empty:
            return df.copy(), TaskStats(total=0, success=0, failed=0)

        checkpoint = kwargs.get("_checkpoint") or (lambda *a, **k: None)
        result = df.copy()

        # Minimal example loop
        for idx, row in result.iterrows():
            # TODO: your enrichment here
            # result.at[idx, "new_column"] = ...
            checkpoint(1, snapshot=result.loc[[idx]])  # periodic checkpoint

        stats = TaskStats(total=len(df), success=len(result), failed=0)
        return result, stats
```

Export it in `lib/analytics/tasks/__init__.py`:
```python
from .my_task import MyTask, default_my_task_bindings  # noqa: F401
```

Define bindings in the same file (`my_task.py`) or next to it:
```python
def default_my_task_bindings():
    mapping = {"id": "spatial_unit_id", "geometry": "geometry"}  # adapt required inputs
    defaults = {}
    return {"mapping": mapping, "defaults": defaults}
```

Register in `lib/analytics/registry.py`:
```python
from .tasks import MyTask, default_my_task_bindings
...
try:
    _m = default_my_task_bindings()
register_binding(
    TaskBinding(
        key="my_task",
        task_cls=MyTask,
        field_mapping=_m["mapping"],
        defaults=_m["defaults"],
        param_schema=None,  # or a Pydantic model if you add one
        description="What this task does",
    ),
)
except Exception:
    pass
```

## 3) Field mapping and bindings
- Define one default mapping for your task (most common dataframe shape) and defaults. Example:
```python
def default_my_task_bindings():
    mapping = {"id": "spatial_unit_id", "geometry": "geometry"}
    defaults = {}
    return {"mapping": mapping, "defaults": defaults}
```
- Register in `registry.py` with `field_mapping=_m["mapping"]`.

## 4) Calling the task
- Preferred entry point: `run_task(...)` in `registry.py`:
```python
from lib.analytics.registry import run_task, BindingKey
df_enriched, stats = run_task(
    df,
    binding_key=BindingKey("my_task"),
    task_params={...},  # validated if you provide a param schema
    input_rules=[{"column": "my_date", "coerce": "datetime", "invalid_values": ["0001-01-01"], "skip_row": True}],  # optional
    checkpoint_path="tmp/my_task_checkpoint.parquet",
    checkpoint_frequency=200,
    progress=True,
    progress_desc="My analytics",
)
```
- To opt into periodic checkpoints, pass both `checkpoint_path` and `checkpoint_frequency`. The task should call `_checkpoint` during processing.

## 5) `run_task` options (cheat sheet)
- `binding_key`: which task to run (`BindingKey.EMERGENCE`, `"weather"`, etc.).
- `task_params`: goes to the task constructor (validated if a Pydantic schema exists). Use it for task-level knobs (e.g., `{'crop_cycles': crop_cycles, 'season_duration': 151}`).
- `field_mapping_override`: remap columns when your dataframe names differ. Example: `{"geometry": "geom_wkt", "crop": "crop_code"}` merges over the default mapping.
- `defaults_override`: inject constants when a mapped column is missing/NA. Example: `{"dataSource": "LR", "region": "n_county"}`.
- `passthrough_override`: columns to keep as-is in the output even if not used by the task.
- `input_rules`: per-column coercion/skip rules (dates, sentinels). Skipped rows remain in the final dataframe and count in `filtered_out`.
- `checkpoint_path` + `checkpoint_frequency`: write snapshots while running; useful to resume long runs.
- `progress` / `progress_desc`: toggle the progress bar and label.
- `error_csv_path`: optional CSV dump of rows that contain an `*error*` column when failures occur (file is overwritten per call; parent dirs auto-created).

Example putting it together:
```python
df_out, stats = run_task(
    df,
    binding_key=BindingKey.EMERGENCE,
    task_params={"crop_cycles": crop_cycles, "season_duration": 151},
    field_mapping_override={"geometry": "geom_wkt", "crop": "crop_code"},
    defaults_override={"data_source": "LR", "region": "n_county"},
    input_rules=[{"column": "sowingDate", "coerce": "datetime", "min_year": 1900, "skip_row": True}],
    checkpoint_path="tmp/emergence_checkpoint.parquet",
    checkpoint_frequency=500,
    progress=True,
    progress_desc="Emergence",
)
```
Signatures/caching: if a task uses a signature column (e.g., `emergence_signature`), changing a mapped value or a task param that feeds the signature will trigger a rerun; identical signatures are treated as cache hits.

## 6) Execution reporting (HTML + markdown)
- Use `AnalyticsRunReporter` to capture per-task stats (rows in/out, skipped, durations, errors, added columns) and render an HTML recap plus a short markdown summary.
- Pass `reporter=reporter` to each `run_task(...)` call; tasks remain unchanged.
- The summary is handy for artifact descriptions; the HTML can be saved locally (set `html_path`).
- Optional folium map: set `include_map=True` and `map_geometry_column="geometry"` (best-effort; gracefully skipped if dependencies are missing).

Example:
```python
from lib.analytics import AnalyticsRunReporter, run_task, BindingKey

reporter = AnalyticsRunReporter(
    enabled=True,
    html_path="tmp/analytics_run_report.html",
    include_map=True,
    map_geometry_column="geometry",
)
reporter.set_run_context(group_id="abc", parquet_version="v12", manifest=manifest)

df, stats = run_task(df, binding_key=BindingKey.WEATHER, task_params=params, reporter=reporter)
df, stats = run_task(df, binding_key=BindingKey.EMERGENCE, task_params=params2, reporter=reporter)

reporter.capture_dataset(df, use_for_map=True)
html = reporter.render_html()
print(reporter.render_summary_markdown())
```

## 7) For tasks with internal clients
- If the client already has a progress bar, set `use_internal_progress = True` so the base does not create a second bar.
- Expose a callback hook in the client (e.g., `progress_callback`) and call `_checkpoint` within that callback. This is how `CropMaskTask` and `EmergenceTask` keep checkpoints aligned with internal progress.

### Client stub (optional, copy/paste)
If your analytics needs an HTTP client, add `lib/clients/my_client.py`:
```python
import requests

class MyClient:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    @classmethod
    def from_env(cls):
        # TODO: read env/config
        return cls(base_url="https://api.example.com")

    def fetch_something(self, payload: dict):
        resp = requests.post(f"{self.base_url}/endpoint", json=payload, timeout=30)
        resp.raise_for_status()
        return resp.json()
```
Use it inside `MyTask.execute`:
```python
client = MyClient.from_env()
# inside the loop:
# data = client.fetch_something({...})
```

## 8) Testing checklist
- Minimal dataframe with required mapped columns runs without errors.
- Checkpoint write: pass `checkpoint_path` and `checkpoint_frequency=1` to force an early write and validate the parquet.
- Progress: run with `progress=True` to confirm a single bar (or set `use_internal_progress=True` if the client owns progress).

With these conventions, new analytics tasks get mapping, progress, and checkpoint behavior “for free” and only need to focus on the task-specific logic.

## 9) Scaffold a new analytics task (CLI)
- Script location: `tools/analytics_scaffolder.py` (users get it with the notebooks package).
- Dependency: `PyYAML` (already in `requirements.txt`) is needed for `--mode yaml`.
- OpenAPI mode: generates client + task + registry wiring from a spec path/method (or operationId):
  ```bash
  python tools/analytics_scaffolder.py --mode openapi --source openapi.json --task-name my_task --path /v1/predict --method post
  ```
- YAML mode: provide inputs/outputs and metadata in a YAML file:
  ```bash
  python tools/analytics_scaffolder.py --mode yaml --source config.yaml --task-name my_task
  ```
  Example `config.yaml`:
  ```yaml
  base_url: https://api.example.com
  endpoint: /v1/predict
  method: post
  description: My task scaffolded from YAML
  query:
    api_key:
      field: api_key
      type: str
  body:
    id:
      field: id
      type: str
    geometry:
      field: geometry
      type: wkt
  outputs:
    score: score
    status: status
  ```
- Options: `--binding-key` to override the registry key, `--target-root` to point to another analytics package (default is `lib/analytics`), `--force` to overwrite existing files.
- Extra toggles:
  - `--use-crop-cycle` to preload `crop_cycle.csv` (global) and derive season duration/start like Emergence (ignores county/state timewindows).
  - `--signature-cache` to compute a `<binding>_signature` hash (inputs + geometry) and skip rows already processed with the same signature.
- Generated tasks expose `input_rules` and call `apply_input_rules` at the start of `execute` to clean date/sentinel columns (tweak the rules as needed).
- Callers can pass `input_rules` directly to `run_task(...)`; filtered rows remain in the final dataframe and are counted in `TaskStats.filtered_out`.
- Generated files (review TODOs):
  - Client: `lib/clients/<task>_client.py`
  - Task: `lib/analytics/tasks/<task>_task.py`
  - Params stub in `lib/analytics/params.py` (extends `AnalyticsParams`)
  - Registry wiring: appended to `lib/analytics/registry.py` and imports added to `__init__.py`.
  - Notebook helpers: reuse `run_task_with_reporting` / `render_final_report` from `lib.analytics.notebook_helpers` to show TaskStats tables and generate the HTML report once per run (avoid duplicating helper code inside notebooks).
  - Reminder: `run_task` signature is `run_task(df, *, binding_key=..., ...)` so the dataframe is the first positional argument. Passing keywords before `df` will raise a syntax error.

## Notebook helper example (report + stats)
```python
from lib.analytics import (
    BindingKey,
    AnalyticsRunReporter,
    run_task_with_reporting,
    render_final_report,
)

reporter = AnalyticsRunReporter(
    enabled=True,
    html_path="tmp/analytics_run_report.html",
    include_map=True,
    map_geometry_column="geometry",
)

df_out, stats = run_task_with_reporting(
    df, binding_key=BindingKey.WEATHER, reporter=reporter, error_csv_path="tmp/errors/weather_errors.csv"
)
report_html = render_final_report(reporter, show_inline=True)
summary_md = reporter.render_summary_markdown()
```
